extends Node2D
## Дух косы из готовых PNG-кадров. Тот же интерфейс, что у hero_visual.gd, поэтому hero.gd и боёвка не меняются.
## Файлы: res://art/spirit/{idle,fly,attack,heavy,hit,skill,death}.png — горизонтальные ленты кадров.
## Параметры (размер ячейки, точка опоры, число кадров, fps, кадр удара) — res://art/spirit/spirit.json, см. art/spirit/README.md.

signal strike(kind: int)

const DIR := "res://art/spirit/"
const ANIMS: Array = ["idle", "fly", "attack", "heavy", "hit", "skill", "death"]
const DEF_FRAMES: Dictionary = {"idle": 4, "fly": 9, "attack": 8, "heavy": 9, "hit": 4, "skill": 10, "death": 9}
const DEF_FPS: Dictionary = {"idle": 6.0, "fly": 12.0, "attack": 0.0, "heavy": 0.0, "hit": 0.0, "skill": 0.0, "death": 0.0}

var on_ground: bool = true
var vy: float = 0.0
var rage: bool = false
var shadow_dy: float = 0.0
var hero_dy_px: float = 0.0
var sprint: bool = false
var sword_lv: int = 0
var blade_tip_local: Vector2 = Vector2(150, -70)
var blade_mid_local: Vector2 = Vector2(120, -55)
var dead: bool = false

## Значения по умолчанию = art/spirit/spirit.json (на случай, если json не попал в сборку).
var cell: Vector2i = Vector2i(256, 176)
var pivot: Vector2 = Vector2(103, 178)
var strike_frame: Dictionary = {"attack": 5, "heavy": 5, "skill": 7}
var art_scale: float = 0.7
var _tex: Dictionary = {}
var _frames: Dictionary = {}
var _fps: Dictionary = {}
var _t: float = 0.0
var _stand_k: float = 0.0
var _atk_kind: int = -1
var _atk_t: float = 0.0
var _atk_dur: float = 0.36
var _atk_struck: bool = false
var _hit_t: float = -1.0
var _death_t: float = -1.0
var _cast_t: float = 0.0
var _flip_t: float = -1.0
var _land_t: float = 0.0
var _anim: String = "idle"
var _idx: int = 0
var _bob: float = 0.0


## Есть ли все 7 файлов — иначе hero.gd оставит нарисованного кодом духа.
static func available() -> bool:
	for a in ANIMS:
		if not ResourceLoader.exists(DIR + String(a) + ".png"):
			return false
	return true


func _ready() -> void:
	texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	var cfg: Dictionary = {}
	if FileAccess.file_exists(DIR + "spirit.json"):
		var j: Variant = JSON.parse_string(FileAccess.get_file_as_string(DIR + "spirit.json"))
		if j is Dictionary:
			cfg = j
	if cfg.has("cell"):
		cell = Vector2i(int(cfg["cell"][0]), int(cfg["cell"][1]))
	if cfg.has("pivot"):
		pivot = Vector2(float(cfg["pivot"][0]), float(cfg["pivot"][1]))
	if cfg.has("strike_frame"):
		for k in (cfg["strike_frame"] as Dictionary):
			strike_frame[k] = int(cfg["strike_frame"][k])
	if cfg.has("scale"):
		art_scale = float(cfg["scale"])
	if cfg.has("tip"):
		blade_tip_local = Vector2(float(cfg["tip"][0]), float(cfg["tip"][1]))
	if cfg.has("mid"):
		blade_mid_local = Vector2(float(cfg["mid"][0]), float(cfg["mid"][1]))
	for a in ANIMS:
		var t: Texture2D = load(DIR + String(a) + ".png") as Texture2D
		_tex[a] = t
		var n: int = int(DEF_FRAMES[a])
		if cfg.has("frames") and (cfg["frames"] as Dictionary).has(a):
			n = int(cfg["frames"][a])
		elif t != null:
			n = maxi(1, t.get_width() / cell.x)
		_frames[a] = n
		_fps[a] = float((cfg["fps"] as Dictionary).get(a, DEF_FPS[a])) if cfg.has("fps") else float(DEF_FPS[a])


# ----------------------------------------------------------------- управление (как у hero_visual)

func jumped() -> void:
	_land_t = 0.0
	_flip_t = -1.0


func double_jumped() -> void:
	_flip_t = 0.0


func landed() -> void:
	_land_t = 0.14
	_flip_t = -1.0


func cast() -> void:
	_cast_t = 0.3


func attacking() -> bool:
	return _atk_kind >= 0


func cast_point() -> Vector2:
	return Vector2(40.0, -80.0)


func hit() -> void:
	if dead or _atk_kind >= 0:
		return
	_hit_t = 0.0


func die() -> void:
	if not dead:
		dead = true
		_death_t = 0.0
		_atk_kind = -1


func revive() -> void:
	dead = false
	_death_t = -1.0
	_hit_t = -1.0


func start_attack(kind: int, speed: float = 1.0) -> void:
	if dead:
		return
	_hit_t = -1.0
	_atk_kind = kind
	_atk_t = 0.0
	_atk_struck = false
	_atk_dur = (0.52 if kind == 2 else (0.5 if kind == 3 else 0.36)) / speed


func _atk_name() -> String:
	return ["attack", "attack", "heavy", "skill"][clampi(_atk_kind, 0, 3)]


## Кадр удара: момент попадания совпадает с кадром, где коса проходит через цель.
func _strike_frac() -> float:
	var a: String = _atk_name()
	return float(int(strike_frame.get(a, 4))) / float(int(_frames.get(a, 8)))


func advance(delta: float, world_speed: float) -> void:
	_t += delta
	_stand_k = move_toward(_stand_k, 1.0 if world_speed < 25.0 else 0.0, delta * 6.0)
	_cast_t = maxf(0.0, _cast_t - delta)
	_land_t = maxf(0.0, _land_t - delta)
	if _flip_t >= 0.0:
		_flip_t += delta
		if _flip_t > 0.46:
			_flip_t = -1.0
	if _hit_t >= 0.0:
		_hit_t += delta
		if _hit_t >= 0.32:
			_hit_t = -1.0
	if _death_t >= 0.0:
		_death_t = minf(_death_t + delta, 1.4)
	if _atk_kind >= 0:
		_atk_t += delta
		var f: float = _atk_t / _atk_dur
		if not _atk_struck and f >= _strike_frac():
			_atk_struck = true
			strike.emit(_atk_kind)
		if _atk_t >= _atk_dur:
			_atk_kind = -1
	_pick()
	queue_redraw()


func _pick() -> void:
	if _death_t >= 0.0:
		_anim = "death"
		_idx = clampi(int(_death_t / 1.4 * float(_frames["death"])), 0, int(_frames["death"]) - 1)
	elif _hit_t >= 0.0:
		_anim = "hit"
		_idx = clampi(int(_hit_t / 0.32 * float(_frames["hit"])), 0, int(_frames["hit"]) - 1)
	elif _atk_kind >= 0:
		_anim = _atk_name()
		_idx = clampi(int(_atk_t / _atk_dur * float(_frames[_anim])), 0, int(_frames[_anim]) - 1)
	else:
		var flying: bool = _stand_k < 0.5 or not on_ground
		_anim = "fly" if flying else "idle"
		var mult: float = 1.35 if (sprint or rage) else 1.0
		_idx = int(_t * float(_fps[_anim]) * mult) % int(_frames[_anim])
	_bob = 0.0


# ----------------------------------------------------------------- отрисовка

func _draw() -> void:
	var tex: Texture2D = _tex.get(_anim) as Texture2D
	if tex == null:
		return
	var px: float = float(Game.PIXEL)
	var src := Rect2(float(_idx * cell.x), 0.0, float(cell.x), float(cell.y))
	var k: float = px * art_scale
	var dst := Rect2(-pivot.x * k, -pivot.y * k, float(cell.x) * k, float(cell.y) * k)
	var col: Color = Color(1.0, 0.72, 0.72) if rage else Color.WHITE
	if _flip_t >= 0.0:
		var pr: float = clampf(_flip_t / 0.46, 0.0, 1.0)
		var c: Vector2 = Vector2(0.0, -70.0 * px / 2.0)
		draw_set_transform(c, pr * pr * (3.0 - 2.0 * pr) * TAU, Vector2.ONE)
		dst.position -= c
	draw_texture_rect_region(tex, dst, src, col)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
