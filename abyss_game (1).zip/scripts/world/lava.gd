extends Node2D
## Лавовая река под дорогой. Рисуется одним прямоугольником, всю работу делает шейдер.

const SHADER := preload("res://shaders/lava.gdshader")
const TOP_Y: float = 600.0

var _mat: ShaderMaterial


func _ready() -> void:
	_mat = ShaderMaterial.new()
	_mat.shader = SHADER
	material = _mat


func _process(_delta: float) -> void:
	var p: Dictionary = Game.palette
	var lava: Color = p["lava"]
	var crust: Color = (p["tint_near"] as Color) * 0.5
	crust.a = 1.0
	_mat.set_shader_parameter("lava_color", lava)
	_mat.set_shader_parameter("crust_color", crust)
	_mat.set_shader_parameter("scroll", Game.distance * 0.9)
	var vs: Vector2 = Game.view_size
	_mat.set_shader_parameter("rect_size", Vector2(vs.x, vs.y - TOP_Y + 40.0))
	queue_redraw()


func _draw() -> void:
	var vs: Vector2 = Game.view_size
	draw_rect(Rect2(0.0, TOP_Y, vs.x, vs.y - TOP_Y + 40.0), Color.WHITE)
