extends RefCounted
## Палитры зон. Мир плавно перетекает от одной зоны к другой по мере дистанции.

const ZONE_LENGTH: float = 25000.0   ## длина зоны, px
const BLEND_LENGTH: float = 6000.0  ## длина плавного перехода в конце зоны, px

static var _zones: Array = []


static func zones() -> Array:
	if _zones.is_empty():
		_zones = [
			{
				"name": "Багровое затмение",
				"sky_top": Color(0.03, 0.0, 0.02), "sky_mid": Color(0.34, 0.04, 0.06), "sky_low": Color(0.80, 0.20, 0.08),
				"glow": Color(1.0, 0.26, 0.10), "lava": Color(1.0, 0.42, 0.12), "fog": Color(0.55, 0.06, 0.04),
				"tint_far": Color(0.62, 0.30, 0.52), "tint_castle": Color(0.62, 0.28, 0.40), "tint_isl": Color(0.74, 0.34, 0.40),
				"tint_mid": Color(0.84, 0.40, 0.30), "tint_ruins": Color(0.50, 0.26, 0.26), "tint_road": Color(0.85, 0.44, 0.44), "tint_near": Color(0.34, 0.20, 0.20),
				"ash": 0.55, "sparks": 0.6, "cloud": 0.55, "eclipse_r": 0.075, "eclipse_x": 0.70, "eclipse_y": 0.30, "vignette": 0.32,
			},
			{
				"name": "Пепельные пустоши",
				"sky_top": Color(0.04, 0.03, 0.04), "sky_mid": Color(0.26, 0.12, 0.14), "sky_low": Color(0.58, 0.36, 0.30),
				"glow": Color(0.95, 0.52, 0.40), "lava": Color(0.95, 0.46, 0.22), "fog": Color(0.40, 0.28, 0.26),
				"tint_far": Color(0.78, 0.60, 0.60), "tint_castle": Color(0.62, 0.48, 0.50), "tint_isl": Color(0.64, 0.50, 0.50),
				"tint_mid": Color(0.56, 0.44, 0.44), "tint_ruins": Color(0.42, 0.34, 0.34), "tint_road": Color(0.71, 0.58, 0.58), "tint_near": Color(0.28, 0.22, 0.22),
				"ash": 1.0, "sparks": 0.3, "cloud": 0.9, "eclipse_r": 0.062, "eclipse_x": 0.62, "eclipse_y": 0.26, "vignette": 0.32,
			},
			{
				"name": "Расплавленная бездна",
				"sky_top": Color(0.06, 0.0, 0.0), "sky_mid": Color(0.58, 0.09, 0.02), "sky_low": Color(1.0, 0.52, 0.08),
				"glow": Color(1.0, 0.62, 0.16), "lava": Color(1.0, 0.66, 0.20), "fog": Color(0.70, 0.18, 0.02),
				"tint_far": Color(1.0, 0.46, 0.28), "tint_castle": Color(0.90, 0.38, 0.24), "tint_isl": Color(0.92, 0.42, 0.24),
				"tint_mid": Color(0.80, 0.36, 0.22), "tint_ruins": Color(0.56, 0.28, 0.20), "tint_road": Color(0.95, 0.48, 0.34), "tint_near": Color(0.36, 0.18, 0.12),
				"ash": 0.4, "sparks": 1.0, "cloud": 0.5, "eclipse_r": 0.090, "eclipse_x": 0.74, "eclipse_y": 0.34, "vignette": 0.32,
			},
			{
				"name": "Фиолетовый разлом",
				"sky_top": Color(0.02, 0.0, 0.06), "sky_mid": Color(0.22, 0.05, 0.32), "sky_low": Color(0.62, 0.16, 0.38),
				"glow": Color(0.82, 0.30, 0.92), "lava": Color(0.90, 0.34, 0.74), "fog": Color(0.34, 0.08, 0.40),
				"tint_far": Color(0.66, 0.46, 0.84), "tint_castle": Color(0.54, 0.36, 0.70), "tint_isl": Color(0.58, 0.40, 0.74),
				"tint_mid": Color(0.50, 0.36, 0.64), "tint_ruins": Color(0.38, 0.28, 0.46), "tint_road": Color(0.65, 0.48, 0.78), "tint_near": Color(0.24, 0.16, 0.32),
				"ash": 0.6, "sparks": 0.8, "cloud": 0.7, "eclipse_r": 0.070, "eclipse_x": 0.66, "eclipse_y": 0.28, "vignette": 0.32,
			},
		]
	return _zones


## Палитра для заданной дистанции (с плавным переходом между зонами).
static func blend(d: float) -> Dictionary:
	var zs: Array = zones()
	var n: int = zs.size()
	var zi: int = int(floor(d / ZONE_LENGTH))
	var a: Dictionary = zs[zi % n]
	var b: Dictionary = zs[(zi + 1) % n]
	var local: float = d - float(zi) * ZONE_LENGTH
	var t: float = clampf((local - (ZONE_LENGTH - BLEND_LENGTH)) / BLEND_LENGTH, 0.0, 1.0)
	t = t * t * (3.0 - 2.0 * t)
	var out: Dictionary = {}
	for k in a.keys():
		var va: Variant = a[k]
		var vb: Variant = b[k]
		if va is Color:
			out[k] = (va as Color).lerp(vb as Color, t)
		elif va is float:
			out[k] = lerpf(va as float, vb as float, t)
		else:
			out[k] = va if t < 0.5 else vb
	return out
