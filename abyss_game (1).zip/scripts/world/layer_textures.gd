extends RefCounted
## Процедурные текстуры слоёв параллакса.
## Все текстуры — серые силуэты: яркость лежит в RGB, форма — в альфе. Цвет им даёт шейдер
## по палитре текущей зоны. ВРЕМЕННЫЙ арт: позже заменяется нарисованными слоями без правок кода
## (достаточно подменить текстуру в ScrollLayer).

static var _cache: Dictionary = {}


static func get_texture(kind: StringName) -> Texture2D:
	if not _cache.has(kind):
		_build(kind)
	if not _cache.has(kind):
		push_error("LayerTextures: неизвестный тип слоя '%s'" % String(kind))
		return null
	return _cache[kind] as Texture2D


static func _build(kind: StringName) -> void:
	match kind:
		&"mountains":
			_cache[&"mountains"] = _tex(_gen_mountains())
		&"castle", &"castle_glow":
			var pair: Array = _gen_castle()
			_cache[&"castle"] = _tex(pair[0] as Image)
			_cache[&"castle_glow"] = _tex(pair[1] as Image)
		&"islands", &"islands_glow":
			var pair2: Array = _gen_islands()
			_cache[&"islands"] = _tex(pair2[0] as Image)
			_cache[&"islands_glow"] = _tex(pair2[1] as Image)
		&"cliffs", &"cliffs_glow":
			var pair3: Array = _gen_cliffs()
			_cache[&"cliffs"] = _tex(pair3[0] as Image)
			_cache[&"cliffs_glow"] = _tex(pair3[1] as Image)
		&"ruins":
			_cache[&"ruins"] = _tex(_gen_ruins())
		&"road", &"road_glow":
			var pair4: Array = _gen_road()
			_cache[&"road"] = _tex(pair4[0] as Image)
			_cache[&"road_glow"] = _tex(pair4[1] as Image)
		&"fore_bottom":
			_cache[&"fore_bottom"] = _tex(_gen_fore_bottom())
		&"fore_top":
			_cache[&"fore_top"] = _tex(_gen_fore_top())
		&"clouds":
			_cache[&"clouds"] = _gen_clouds()


# --------------------------------------------------------------------------- helpers

static func _img(w: int, h: int) -> Image:
	return Image.create_empty(w, h, false, Image.FORMAT_RGBA8)


## Пиксель-арт: сжимаем в Game.PIXEL раз без сглаживания; в слое рисуется обратно ×PIXEL.
static func _tex(img: Image) -> ImageTexture:
	img.resize(maxi(1, img.get_width() / Game.PIXEL), maxi(1, img.get_height() / Game.PIXEL), Image.INTERPOLATE_NEAREST)
	return ImageTexture.create_from_image(img)


static func _col(v: float, a: float = 1.0) -> Color:
	return Color(v, v, v, a)


const CLEAR := Color(0.0, 0.0, 0.0, 0.0)


## Прямоугольник с «заворотом» по горизонтали — текстуры бесшовные.
static func _fill(img: Image, x: int, y: int, w: int, h: int, c: Color) -> void:
	if w <= 0 or h <= 0:
		return
	var iw: int = img.get_width()
	var xx: int = posmod(x, iw)
	img.fill_rect(Rect2i(xx, y, w, h), c)
	if xx + w > iw:
		img.fill_rect(Rect2i(xx - iw, y, w, h), c)


## Треугольник вершиной вверх.
static func _tri_up(img: Image, cx: int, tip_y: int, base_y: int, half_w: int, c: Color) -> void:
	var hgt: int = base_y - tip_y
	if hgt <= 0:
		return
	for r in range(hgt):
		var hw: int = int(float(half_w) * float(r) / float(hgt))
		_fill(img, cx - hw, tip_y + r, hw * 2 + 1, 1, c)


## Треугольник вершиной вниз (сталактит).
static func _tri_down(img: Image, cx: int, top_y: int, tip_y: int, half_w: int, c: Color) -> void:
	var hgt: int = tip_y - top_y
	if hgt <= 0:
		return
	for r in range(hgt):
		var hw: int = int(float(half_w) * (1.0 - float(r) / float(hgt)))
		_fill(img, cx - hw, top_y + r, hw * 2 + 1, 1, c)


## Готическая стрельчатая арка (заполненная).
static func _arch(img: Image, cx: int, y: int, w: int, h: int, c: Color) -> void:
	var spring: int = int(w * 0.9)
	_tri_up(img, cx, y, y + spring, int(w * 0.5), c)
	_fill(img, cx - int(w * 0.5), y + spring, w, h - spring, c)


## Толстая ломаная линия из квадратиков.
static func _line(img: Image, x0: int, y0: int, x1: int, y1: int, t: int, c: Color) -> void:
	var steps: int = maxi(absi(x1 - x0), absi(y1 - y0))
	var o: int = int(t * 0.5)
	if steps == 0:
		_fill(img, x0 - o, y0 - o, t, t, c)
		return
	for i in range(steps + 1):
		var f: float = float(i) / float(steps)
		_fill(img, int(lerpf(float(x0), float(x1), f)) - o, int(lerpf(float(y0), float(y1), f)) - o, t, t, c)


## Гребень горной гряды: сумма синусов с целыми частотами → бесшовно.
static func _ridge(x: float, w: float, base: float, a: float, ph: float) -> float:
	var t: float = x / w * TAU
	var v: float = base
	v += a * sin(t * 2.0 + ph)
	v += a * 0.6 * sin(t * 5.0 + ph * 1.7)
	v += a * 0.55 * (1.0 - absf(sin(t * 7.0 + ph * 0.6)))
	v += a * 0.25 * (1.0 - absf(sin(t * 17.0 + ph * 2.3)))
	v += a * 0.12 * sin(t * 41.0 + ph)
	return v


## Светящаяся извилистая трещина/ручей лавы.
static func _streak(glow: Image, rng: RandomNumberGenerator, x: int, y0: int, length: int, width: int, peak: float) -> void:
	var cx: float = float(x)
	var drift: float = rng.randf_range(-0.6, 0.6)
	for i in range(length):
		cx += drift + rng.randf_range(-0.9, 0.9)
		var f: float = float(i) / float(length)
		var a: float = peak * (1.0 - f * f)
		_fill(glow, int(cx), y0 + i, width, 1, _col(1.0, a))


# --------------------------------------------------------------------------- mountains

static func _gen_mountains() -> Image:
	var w: int = 2050
	var h: int = 340
	var img: Image = _img(w, h)
	for x in range(w):
		var fx: float = float(x)
		var h1: float = _ridge(fx, float(w), 150.0, 34.0, 1.0)
		var h2: float = _ridge(fx, float(w), 92.0, 36.0, 3.1)
		_fill(img, x, h - int(h1), 1, int(h1), _col(0.50))
		var s: float = _ridge(fx - 4.0, float(w), 92.0, 36.0, 3.1) - _ridge(fx + 4.0, float(w), 92.0, 36.0, 3.1)
		var v: float = clampf(0.40 + s * 0.05, 0.18, 0.9)
		_fill(img, x, h - int(h2), 1, int(h2), _col(v))
	return img


# --------------------------------------------------------------------------- castle

static func _tower(img: Image, glow: Image, rng: RandomNumberGenerator, cx: int, base_y: int, w: int,
		top_y: int, spire_h: int, v: float, broken: bool = false) -> void:
	var hw: int = int(w * 0.5)
	var body: Color = _col(v)
	var rim: Color = _col(minf(v + 0.34, 1.0))
	_fill(img, cx - hw, top_y, w, base_y - top_y, body)
	_fill(img, cx + hw - 3, top_y, 3, base_y - top_y, rim)
	_fill(img, cx - hw - 4, top_y - 2, w + 8, 8, body)
	_fill(img, cx + hw + 1, top_y - 2, 3, 8, rim)
	if broken:
		var x: int = cx - hw - 4
		while x < cx + hw + 4:
			_fill(img, x, top_y - 2, 3, rng.randi_range(2, 36), CLEAR)
			x += 3
	else:
		_tri_up(img, cx, top_y - 2 - spire_h, top_y - 2, hw + 4, body)
		# световая грань шпиля справа
		for r in range(spire_h):
			var sw: int = int(float(hw + 4) * float(r) / float(spire_h))
			_fill(img, cx + sw - 1, top_y - 2 - spire_h + r, 2, 1, rim)
		_fill(img, cx - 1, top_y - 2 - spire_h - 16, 2, 18, body)
	var y: int = top_y + 26
	while y < base_y - 56:
		if rng.randf() < 0.8:
			if w > 46 and rng.randf() < 0.6:
				_arch(glow, cx - int(w * 0.2), y, 6, 16, _col(rng.randf_range(0.5, 1.0)))
				_arch(glow, cx + int(w * 0.2), y, 6, 16, _col(rng.randf_range(0.5, 1.0)))
			else:
				_arch(glow, cx, y, 6, 16, _col(rng.randf_range(0.5, 1.0)))
		y += 38


static func _gen_castle() -> Array:
	var w: int = 3072
	var h: int = 640
	var img: Image = _img(w, h)
	var glow: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	var base: int = 570

	# дальние зубцы по краям тайла (заполняют промежутки между замками)
	for cx in [140, 330, 520, 640, 2560, 2690, 2830, 2960]:
		var tw: int = rng.randi_range(18, 30)
		_tower(img, glow, rng, cx, base, tw, rng.randi_range(400, 470), rng.randi_range(40, 66), 0.34)

	# крепостная стена
	_fill(img, 760, 440, 1570, base - 440, _col(0.38))
	_fill(img, 760, 440, 1570, 3, _col(0.62))
	var cx2: int = 760
	while cx2 < 2330:
		_fill(img, cx2, 428, 12, 14, _col(0.38))
		_fill(img, cx2 + 9, 428, 3, 14, _col(0.60))
		cx2 += 24

	# боковые башни
	_tower(img, glow, rng, 880, base, 44, 340, 62, 0.42)
	_tower(img, glow, rng, 1030, base, 52, 270, 80, 0.44)
	_tower(img, glow, rng, 1130, base, 36, 300, 60, 0.44)
	_tower(img, glow, rng, 1950, base, 36, 290, 64, 0.44)
	_tower(img, glow, rng, 2050, base, 52, 250, 84, 0.44)
	_tower(img, glow, rng, 2200, base, 44, 330, 70, 0.42)
	_tower(img, glow, rng, 2400, base, 58, 330, 0, 0.40, true)

	# главный неф-собор
	_fill(img, 1250, 300, 580, base - 300, _col(0.46))
	_fill(img, 1827, 300, 3, base - 300, _col(0.80))
	_tri_up(img, 1540, 190, 300, 300, _col(0.44))
	for r in range(110):
		var gw: int = int(300.0 * float(r) / 110.0)
		_fill(img, 1540 + gw - 2, 190 + r, 3, 1, _col(0.78))
	# контрфорсы
	for bx in [1290, 1400, 1520, 1650, 1770]:
		_fill(img, bx, 320, 14, base - 320, _col(0.40))
		_fill(img, bx + 11, 320, 3, base - 320, _col(0.74))
		_tri_up(img, bx + 7, 270, 320, 9, _col(0.40))
	# арочные окна нефа и роза
	for wx in range(1310, 1790, 70):
		_arch(glow, wx, 400, 14, 52, _col(rng.randf_range(0.55, 1.0)))
	_arch(glow, 1540, 318, 30, 80, _col(0.95))
	_fill(glow, 1539, 336, 2, 62, CLEAR)
	_fill(glow, 1527, 366, 26, 2, CLEAR)
	# башни собора
	_tower(img, glow, rng, 1230, base, 64, 170, 100, 0.46)
	_tower(img, glow, rng, 1850, base, 64, 190, 96, 0.46)
	_tower(img, glow, rng, 1400, base, 34, 235, 70, 0.44)
	_tower(img, glow, rng, 1690, base, 34, 215, 76, 0.44)
	_tower(img, glow, rng, 1540, base, 76, 125, 112, 0.48)
	# арбалеты-подпорки между башнями
	_line(img, 1262, 215, 1252, 300, 6, _col(0.42))
	_line(img, 1818, 235, 1830, 300, 6, _col(0.42))

	# скальное основание
	for x in range(w):
		var t: float = float(x) / float(w) * TAU
		var gy: float = 505.0 + 22.0 * sin(t * 3.0) + 11.0 * sin(t * 9.0 + 1.0) + 6.0 * sin(t * 23.0)
		var raise: float = 38.0 * exp(-pow((float(x) - 1550.0) / 760.0, 2.0))
		var top: int = int(gy - raise)
		var s: float = (sin((float(x) - 4.0) / float(w) * TAU * 9.0 + 1.0) - sin((float(x) + 4.0) / float(w) * TAU * 9.0 + 1.0)) * 6.0
		_fill(img, x, top, 1, h - top, _col(clampf(0.26 + s * 0.02, 0.15, 0.5)))
		_fill(img, x, top, 1, 2, _col(0.5))
	return [img, glow]


# --------------------------------------------------------------------------- floating islands

static func _gen_islands() -> Array:
	var w: int = 2560
	var h: int = 440
	var img: Image = _img(w, h)
	var glow: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 311
	for i in range(7):
		var cx: int = 180 + i * 360 + rng.randi_range(-40, 40)
		var hw: int = rng.randi_range(80, 165)
		var ty: int = rng.randi_range(110, 270)
		var thick: int = rng.randi_range(70, 150)
		var bottoms: Dictionary = {}
		for dx in range(-hw, hw + 1):
			var u: float = float(dx) / float(hw)
			var top: int = ty + int(11.0 * u * u + 2.0 * sin(float(dx) * 0.4))
			var tri: float = absf(fposmod(float(dx) / (11.0 + float(i % 3) * 3.0), 1.0) - 0.5) * 2.0
			var bot: int = ty + int(float(thick) * pow(maxf(0.0, 1.0 - u * u), 0.8) * (0.55 + 0.45 * tri))
			bot = maxi(bot, top + 3)
			bottoms[dx] = bot
			var v: float = clampf(0.40 + 0.16 * u, 0.2, 0.7)
			_fill(img, cx + dx, top, 1, bot - top, _col(v))
			_fill(img, cx + dx, top, 1, 3, _col(0.82))
			_fill(glow, cx + dx, bot - 3, 1, 4, _col(1.0, 0.22))
		# постройки и мёртвые деревья на острове
		var kind: int = rng.randi_range(0, 2)
		var px: int = cx + rng.randi_range(-int(hw * 0.4), int(hw * 0.4))
		if kind == 0:
			var th: int = rng.randi_range(36, 74)
			var tw: int = rng.randi_range(14, 24)
			_fill(img, px - int(tw * 0.5), ty - th, tw, th + 4, _col(0.34))
			_fill(img, px + int(tw * 0.5) - 3, ty - th, 3, th + 4, _col(0.7))
			_tri_up(img, px, ty - th - 26, ty - th, int(tw * 0.6), _col(0.34))
			_arch(glow, px, ty - th + 10, 5, 12, _col(0.9))
		elif kind == 1:
			var ah: int = rng.randi_range(40, 70)
			_fill(img, px - 26, ty - ah, 9, ah + 4, _col(0.36))
			_fill(img, px + 17, ty - ah, 9, ah + 4, _col(0.36))
			_tri_up(img, px, ty - ah - 14, ty - ah + 26, 26, _col(0.36))
			_tri_up(img, px, ty - ah + 4, ty - ah + 26, 15, CLEAR)
		else:
			var tt: int = rng.randi_range(40, 66)
			_line(img, px, ty + 2, px + rng.randi_range(-4, 4), ty - tt, 4, _col(0.2))
			for b in range(4):
				var by: int = ty - tt + b * 12
				var dirx: int = 1 if rng.randf() < 0.5 else -1
				_line(img, px, by + 8, px + dirx * rng.randi_range(14, 26), by - rng.randi_range(6, 16), 2, _col(0.2))
		# струи лавы с острова
		for k in range(rng.randi_range(1, 2)):
			var fdx: int = rng.randi_range(-int(hw * 0.45), int(hw * 0.45))
			var fb: int = int(bottoms[fdx])
			_streak(glow, rng, cx + fdx, fb - 2, rng.randi_range(40, 130), 3, 0.9)
	return [img, glow]


# --------------------------------------------------------------------------- cliffs (mid hills with lava)

static func _gen_cliffs() -> Array:
	var w: int = 2050
	var h: int = 300
	var img: Image = _img(w, h)
	var glow: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 905
	var tops: PackedInt32Array = PackedInt32Array()
	tops.resize(w)
	for x in range(w):
		var fx: float = float(x)
		var hh: float = _ridge(fx, float(w), 120.0, 26.0, 2.2)
		var s: float = _ridge(fx - 3.0, float(w), 120.0, 26.0, 2.2) - _ridge(fx + 3.0, float(w), 120.0, 26.0, 2.2)
		var v: float = clampf(0.30 + s * 0.02, 0.2, 0.5)
		var top: int = h - int(hh)
		tops[x] = top
		_fill(img, x, top, 1, h - top, _col(v))
	for i in range(16):
		var sx: int = rng.randi_range(0, w - 1)
		_streak(glow, rng, sx, tops[sx] + 6, rng.randi_range(60, 150), rng.randi_range(2, 3), 0.95)
	return [img, glow]


# --------------------------------------------------------------------------- ruins

static func _gen_ruins() -> Image:
	var w: int = 2050
	var h: int = 300
	var img: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 4242
	var x: int = 60
	while x < w - 40:
		var kind: int = rng.randi_range(0, 4)
		match kind:
			0:  # сломанная колонна
				var cw: int = rng.randi_range(14, 22)
				var ch: int = rng.randi_range(70, 160)
				_fill(img, x, h - ch, cw, ch, _col(0.36))
				_fill(img, x + cw - 3, h - ch, 3, ch, _col(0.66))
				_fill(img, x - 3, h - ch, cw + 6, 7, _col(0.36))
				for k in range(0, cw, 3):
					_fill(img, x + k, h - ch - 3, 3, rng.randi_range(2, 14), CLEAR)
				x += cw + rng.randi_range(70, 140)
			1:  # готическая арка из двух колонн и косых каменных рёбер
				var gap: int = rng.randi_range(52, 78)
				var ah: int = rng.randi_range(110, 150)
				var pw: int = 14
				_fill(img, x, h - ah, pw, ah, _col(0.34))
				_fill(img, x + pw - 3, h - ah, 3, ah, _col(0.64))
				var rx: int = x + pw + gap
				_fill(img, rx, h - ah + rng.randi_range(0, 30), pw, ah, _col(0.34))
				_fill(img, rx + pw - 3, h - ah + 10, 3, ah, _col(0.64))
				var apex_x: int = x + pw + int(gap * 0.5)
				var apex_y: int = h - ah - int(gap * 0.55)
				_line(img, x + int(pw * 0.5), h - ah, apex_x, apex_y, 8, _col(0.34))
				if rng.randf() < 0.6:
					_line(img, rx + int(pw * 0.5), h - ah, apex_x + 4, apex_y + 4, 8, _col(0.34))
				_fill(img, x - 5, h - 16, gap + pw * 2 + 10, 16, _col(0.34))
				x += gap + pw * 2 + rng.randi_range(80, 160)
			2:  # обломок стены с проёмами
				var ww: int = rng.randi_range(70, 130)
				var col_x: int = x
				while col_x < x + ww:
					var colh: int = rng.randi_range(60, 120)
					_fill(img, col_x, h - colh, 6, colh, _col(0.34))
					col_x += 6
				_fill(img, x + ww - 3, h - 70, 3, 70, _col(0.64))
				for wx in range(x + 14, x + ww - 22, 36):
					_arch(img, wx + 6, h - 62, 10, 26, CLEAR)
				x += ww + rng.randi_range(60, 140)
			3:  # куча щебня
				var rw: int = rng.randi_range(60, 130)
				_tri_up(img, x + int(rw * 0.5), h - rng.randi_range(22, 40), h, int(rw * 0.5), _col(0.30))
				x += rw + rng.randi_range(40, 120)
			_:  # копьё/кол
				var sh: int = rng.randi_range(70, 120)
				_line(img, x, h, x + rng.randi_range(-18, 18), h - sh, 4, _col(0.26))
				x += rng.randi_range(60, 140)
	_fill(img, 0, h - 14, w, 14, _col(0.28))
	return img


# --------------------------------------------------------------------------- road

static func _gen_road() -> Array:
	var w: int = 2050
	var h: int = 200
	var img: Image = _img(w, h)
	var glow: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 5150
	# нижний «корпус» дороги — рваный край над лавой
	for x in range(w):
		var t: float = float(x) / float(w) * TAU
		var bottom: float = 150.0 + 28.0 * sin(t * 9.0 + 0.5) + 20.0 * sin(t * 23.0 + 1.1) + 16.0 * (1.0 - absf(sin(t * 41.0)))
		bottom = clampf(bottom, 104.0, 196.0)
		_fill(img, x, 0, 1, int(bottom), _col(0.30))
		_fill(img, x, int(bottom) - 3, 1, 4, _col(0.2))
		if bottom < 190.0:
			_fill(glow, x, int(bottom) - 4, 1, 5, _col(1.0, 0.55))
	# верхняя плоскость дороги (по ней бежит герой)
	_fill(img, 0, 0, w, 27, _col(0.60))
	_fill(img, 0, 0, w, 3, _col(0.90))
	_fill(img, 0, 24, w, 3, _col(0.30))
	var sx: int = 40
	while sx < w:
		_fill(img, sx, 3, 2, 21, _col(0.26))
		_fill(img, sx - 14, 12, 8, 1, _col(0.4))
		sx += rng.randi_range(100, 190)
	# лицевая кладка
	_fill(img, 0, 27, w, 77, _col(0.40))
	for row in range(5):
		var y: int = 27 + row * 18
		_fill(img, 0, y, w, 2, _col(0.20))
		var bx: int = (row % 2) * 28
		while bx < w:
			_fill(img, bx, y + 2, 2, 16, _col(0.20))
			bx += 56
	# трещины с лавой
	for i in range(34):
		var cx: float = float(rng.randi_range(0, w - 1))
		var y0: int = rng.randi_range(0, 60)
		var length: int = rng.randi_range(24, 70)
		for k in range(length):
			cx += rng.randf_range(-1.6, 1.6)
			_fill(img, int(cx), y0 + k, 2, 1, _col(0.10))
			_fill(glow, int(cx), y0 + k, 2, 1, _col(1.0, 0.85 * (1.0 - float(k) / float(length))))
	# капли лавы под дорогой
	for i in range(26):
		var dx: int = rng.randi_range(0, w - 1)
		var t2: float = float(dx) / float(w) * TAU
		var bt: float = clampf(150.0 + 28.0 * sin(t2 * 9.0 + 0.5) + 20.0 * sin(t2 * 23.0 + 1.1) + 16.0 * (1.0 - absf(sin(t2 * 41.0))), 104.0, 196.0)
		_streak(glow, rng, dx, int(bt) - 2, rng.randi_range(6, maxi(8, 199 - int(bt))), 2, 0.9)
	return [img, glow]


# --------------------------------------------------------------------------- foreground

static func _gen_fore_bottom() -> Image:
	var w: int = 3072
	var h: int = 130
	var img: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 8800
	for x in range(w):
		var t: float = float(x) / float(w) * TAU
		var gh: int = int(26.0 + 10.0 * sin(t * 13.0) + 7.0 * sin(t * 37.0 + 1.0))
		_fill(img, x, h - gh, 1, gh, _col(0.12))
	var x2: int = 40
	while x2 < w - 40:
		var kind: int = rng.randi_range(0, 2)
		if kind == 0:
			var sh: int = rng.randi_range(46, 112)
			var sw: int = rng.randi_range(12, 30)
			_tri_up(img, x2, h - sh, h, sw, _col(0.11))
			for r in range(sh):
				var rw: int = int(float(sw) * float(r) / float(sh))
				_fill(img, x2 + rw - 1, h - sh + r, 2, 1, _col(0.32))
		elif kind == 1:
			var cw: int = rng.randi_range(14, 22)
			var chh: int = rng.randi_range(50, 100)
			_fill(img, x2, h - chh, cw, chh, _col(0.11))
			_fill(img, x2 + cw - 2, h - chh, 2, chh, _col(0.30))
			for k in range(0, cw, 3):
				_fill(img, x2 + k, h - chh - 2, 3, rng.randi_range(2, 10), CLEAR)
		else:
			var rw2: int = rng.randi_range(40, 90)
			_tri_up(img, x2 + int(rw2 * 0.5), h - rng.randi_range(36, 60), h, int(rw2 * 0.5), _col(0.12))
		x2 += rng.randi_range(130, 380)
	return img


static func _gen_fore_top() -> Image:
	var w: int = 2602
	var h: int = 260
	var img: Image = _img(w, h)
	var rng := RandomNumberGenerator.new()
	rng.seed = 2468
	for x in range(w):
		var t: float = float(x) / float(w) * TAU
		var gh: int = int(14.0 + 8.0 * sin(t * 11.0) + 6.0 * sin(t * 29.0 + 2.0))
		_fill(img, x, 0, 1, gh, _col(0.10))
	var x2: int = 30
	while x2 < w - 30:
		if rng.randf() < 0.72:
			var len: int = rng.randi_range(50, 210)
			var hw: int = rng.randi_range(10, 26)
			_tri_down(img, x2, 0, len, hw, _col(0.10))
			for r in range(len):
				var rw: int = int(float(hw) * (1.0 - float(r) / float(len)))
				_fill(img, x2 + rw - 1, r, 2, 1, _col(0.28))
		else:
			var cl: int = rng.randi_range(80, 200)
			var y: int = 0
			while y < cl:
				_fill(img, x2, y, 4, 7, _col(0.10))
				y += 10
			_fill(img, x2 - 4, cl, 12, 12, _col(0.10))
		x2 += rng.randi_range(70, 220)
	return img


# --------------------------------------------------------------------------- clouds

static func _gen_clouds() -> Texture2D:
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.frequency = 0.011
	noise.fractal_octaves = 4
	noise.seed = 1357
	var img: Image = noise.get_seamless_image(1026, 255)
	img.resize(513, 127, Image.INTERPOLATE_NEAREST)
	return ImageTexture.create_from_image(img)
