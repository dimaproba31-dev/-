extends Node2D
## Атмосферные частицы. Два экземпляра сцены: «задний» (дым, свечение) идёт за героем,
## «передний» (пепел, искры, крупные хлопья) — перед ним.

@export var front: bool = true

var _emitters: Array[Dictionary] = []   # {node, kind}


func _ready() -> void:
	var soft_small: Texture2D = _hard_texture()
	var soft_mid: Texture2D = _soft_texture(64)
	var soft_big: Texture2D = _soft_texture(128)
	if front:
		_add(_make_ash(soft_small, 110, 11.0, 1.0, 2.0, 150.0, 340.0, 0.0), &"ash")
		_add(_make_sparks(soft_small), &"sparks")
		_add(_make_ash(soft_mid, 12, 6.0, 1.4, 2.6, 520.0, 800.0, 0.3), &"bokeh")
		_add(_make_motes(soft_mid), &"motes")
	else:
		_add(_make_smoke(soft_big), &"smoke")
		_add(_make_ash(soft_small, 50, 14.0, 1.0, 1.0, 70.0, 150.0, 0.0), &"ash_far")


func _add(p: CPUParticles2D, kind: StringName) -> void:
	add_child(p)
	_emitters.append({"node": p, "kind": kind})


func _process(_delta: float) -> void:
	var vs: Vector2 = Game.view_size
	var pal: Dictionary = Game.palette
	var ratio: float = Game.speed / Game.BASE_SPEED
	for e in _emitters:
		var p: CPUParticles2D = e["node"]
		var kind: StringName = e["kind"]
		p.speed_scale = ratio
		match kind:
			&"ash", &"ash_far":
				p.position = Vector2(vs.x + 60.0, vs.y * 0.5)
				var c: Color = (pal["tint_far"] as Color).lerp(Color(0.7, 0.6, 0.55), 0.5)
				c.a = clampf(0.25 + float(pal["ash"]) * 0.5, 0.0, 1.0)
				p.color = c
			&"bokeh":
				p.position = Vector2(vs.x + 100.0, vs.y * 0.5)
				var cb: Color = (pal["tint_far"] as Color).lerp(Color(0.6, 0.5, 0.45), 0.4)
				cb.a = 0.16 * float(pal["ash"])
				p.color = cb
			&"sparks":
				p.position = Vector2(vs.x + 60.0, vs.y * 0.86)
				var cs: Color = pal["glow"]
				cs.a = clampf(0.3 + float(pal["sparks"]) * 0.7, 0.0, 1.0)
				p.color = cs
			&"motes":
				p.position = Vector2(vs.x + 80.0, vs.y * 0.55)
				var cm: Color = pal["glow"]
				cm.a = 0.14
				p.color = cm
			&"smoke":
				p.position = Vector2(vs.x + 220.0, vs.y * 0.68)
				var cf: Color = pal["fog"]
				cf.a = 0.20 * float(pal["cloud"])
				p.color = cf


# --------------------------------------------------------------------------- фабрики эмиттеров

func _base(amount: int, lifetime: float, tex: Texture2D, additive: bool) -> CPUParticles2D:
	var p := CPUParticles2D.new()
	p.amount = amount
	p.lifetime = lifetime
	p.preprocess = lifetime
	p.texture = tex
	p.local_coords = false
	p.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	p.direction = Vector2(-1.0, 0.0)
	p.gravity = Vector2.ZERO
	p.randomness = 0.6
	if additive:
		var m := CanvasItemMaterial.new()
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		p.material = m
	return p


func _fade(a_mid: float) -> Gradient:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.12, 0.85, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1, 1, 1, a_mid), Color(1, 1, 1, a_mid), Color(1, 1, 1, 0)])
	return g


func _make_ash(tex: Texture2D, amount: int, life: float, smin: float, smax: float, vmin: float, vmax: float, spin: float) -> CPUParticles2D:
	var p: CPUParticles2D = _base(amount, life, tex, false)
	p.emission_rect_extents = Vector2(40.0, 400.0)
	p.direction = Vector2(-1.0, 0.18)
	p.spread = 22.0
	p.initial_velocity_min = vmin
	p.initial_velocity_max = vmax
	p.gravity = Vector2(0.0, 14.0)
	p.scale_amount_min = smin
	p.scale_amount_max = smax
	p.angular_velocity_min = -90.0 * spin
	p.angular_velocity_max = 90.0 * spin
	p.color_ramp = _fade(1.0)
	return p


func _make_sparks(tex: Texture2D) -> CPUParticles2D:
	var p: CPUParticles2D = _base(46, 4.2, tex, true)
	p.emission_rect_extents = Vector2(40.0, 70.0)
	p.direction = Vector2(-1.0, -0.65)
	p.spread = 28.0
	p.initial_velocity_min = 220.0
	p.initial_velocity_max = 480.0
	p.gravity = Vector2(0.0, -34.0)
	p.damping_min = 4.0
	p.damping_max = 18.0
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.08, 0.5, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1.0, 0.9, 0.7, 1.0), Color(1.0, 0.45, 0.15, 0.8), Color(0.6, 0.1, 0.05, 0.0)])
	p.color_ramp = g
	return p


func _make_motes(tex: Texture2D) -> CPUParticles2D:
	var p: CPUParticles2D = _base(22, 8.0, tex, true)
	p.emission_rect_extents = Vector2(40.0, 330.0)
	p.direction = Vector2(-1.0, -0.1)
	p.spread = 30.0
	p.initial_velocity_min = 90.0
	p.initial_velocity_max = 230.0
	p.gravity = Vector2(0.0, -8.0)
	p.scale_amount_min = 0.5
	p.scale_amount_max = 1.4
	p.color_ramp = _fade(1.0)
	return p


func _make_smoke(tex: Texture2D) -> CPUParticles2D:
	var p: CPUParticles2D = _base(16, 17.0, tex, false)
	p.emission_rect_extents = Vector2(60.0, 140.0)
	p.direction = Vector2(-1.0, -0.08)
	p.spread = 14.0
	p.initial_velocity_min = 110.0
	p.initial_velocity_max = 190.0
	p.gravity = Vector2(0.0, -6.0)
	p.scale_amount_min = 2.6
	p.scale_amount_max = 5.2
	p.angular_velocity_min = -8.0
	p.angular_velocity_max = 8.0
	p.color_ramp = _fade(1.0)
	return p


## Мягкий радиальный круг (белый → прозрачный) — единственная «текстура» частиц.
func _soft_texture(size: int) -> Texture2D:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.35, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 1), Color(1, 1, 1, 0.38), Color(1, 1, 1, 0)])
	var t := GradientTexture2D.new()
	t.gradient = g
	t.width = size
	t.height = size
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	return t


## Жёсткий квадрат PIXEL×PIXEL — «один пиксель арта» при масштабе 1.
func _hard_texture() -> Texture2D:
	var img: Image = Image.create_empty(Game.PIXEL, Game.PIXEL, false, Image.FORMAT_RGBA8)
	img.fill(Color.WHITE)
	return ImageTexture.create_from_image(img)
