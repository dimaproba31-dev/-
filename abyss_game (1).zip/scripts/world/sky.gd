extends Node2D
## Небо: вертикальный градиент зоны и кроваво-красное затмение.


func _process(_delta: float) -> void:
	queue_redraw()


func _draw() -> void:
	var vs: Vector2 = Game.view_size
	var p: Dictionary = Game.palette
	var top: Color = p["sky_top"]
	var mid: Color = p["sky_mid"]
	var low: Color = p["sky_low"]
	var y1: float = vs.y * 0.52
	var y2: float = vs.y * 0.86
	draw_polygon(PackedVector2Array([Vector2(0, 0), Vector2(vs.x, 0), Vector2(vs.x, y1), Vector2(0, y1)]),
			PackedColorArray([top, top, mid, mid]))
	draw_polygon(PackedVector2Array([Vector2(0, y1), Vector2(vs.x, y1), Vector2(vs.x, y2), Vector2(0, y2)]),
			PackedColorArray([mid, mid, low, low]))
	draw_rect(Rect2(0, y2, vs.x, vs.y - y2 + 2.0), low)
	_draw_eclipse(vs, p)


func _draw_eclipse(vs: Vector2, p: Dictionary) -> void:
	var c := Vector2(vs.x * float(p["eclipse_x"]), vs.y * float(p["eclipse_y"]))
	var r: float = vs.y * float(p["eclipse_r"])
	var glow: Color = p["glow"]
	var pulse: float = 1.0 + 0.04 * sin(Game.elapsed * 0.8)
	# ореол
	for i in range(16):
		var f: float = float(i) / 16.0
		var a: float = 0.085 * pow(1.0 - f, 2.0)
		draw_circle(c, r * (1.12 + f * 4.2) * pulse, Color(glow.r, glow.g, glow.b, a))
	# лучи затмения (медленно вращаются)
	for k in range(18):
		var ang: float = TAU * float(k) / 18.0 + Game.elapsed * 0.03
		var len: float = r * (5.0 + 2.5 * sin(float(k) * 2.3 + Game.elapsed * 0.4))
		var d: Vector2 = Vector2(cos(ang), sin(ang))
		var nrm: Vector2 = d.orthogonal() * r * 0.22
		draw_colored_polygon(PackedVector2Array([c + d * r * 1.1 + nrm, c + d * (r + len), c + d * r * 1.1 - nrm]),
				Color(glow.r, glow.g, glow.b, 0.07))
	# тонкая яркая корона и чёрный диск со смещением = серп
	draw_circle(c, r * 1.07, Color(glow.r, glow.g * 0.85, glow.b * 0.8, 0.55))
	draw_circle(c, r * 1.03, Color(1.0, 0.72, 0.5, 0.95))
	draw_circle(c + Vector2(-r * 0.05, r * 0.02), r, Color(0.0, 0.0, 0.0, 1.0))
