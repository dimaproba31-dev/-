extends ColorRect
## Полноэкранная виньетка и свечение лавы снизу. Цвет следует за палитрой зоны.

var _mat: ShaderMaterial


func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_mat = ShaderMaterial.new()
	_mat.shader = preload("res://shaders/overlay.gdshader")
	material = _mat


func _process(_delta: float) -> void:
	var p: Dictionary = Game.palette
	_mat.set_shader_parameter("vignette", p["vignette"])
	_mat.set_shader_parameter("glow_color", p["glow"])
