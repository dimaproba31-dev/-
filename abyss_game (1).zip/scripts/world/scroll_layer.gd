extends Node2D
## Один слой параллакса: бесшовная тайловая текстура, сдвигаемая по дистанции забега.
## Цвет берётся из палитры текущей зоны (Game.palette), поэтому фон плавно меняется сам.

const LayerTextures := preload("res://scripts/world/layer_textures.gd")

@export var kind: StringName = &"mountains"      ## имя процедурной текстуры (см. layer_textures.gd)
@export var shader: Shader                       ## шейдер слоя
@export var scroll_factor: float = 0.1           ## 0 — неподвижно, 1 — скорость дороги
@export var scroll_offset: float = 0.0           ## начальный сдвиг, px
@export var bottom_y: float = 560.0              ## где находится низ текстуры (верх, если anchor_top)
@export var anchor_top: bool = false
@export var tint_key: StringName = &"tint_far"   ## ключ цвета в палитре зоны
@export var fog_amount: float = 0.4
@export var intensity: float = 1.0
@export var opacity: float = 1.0
@export var flicker: float = 0.0                 ## мерцание яркости, 0..1
@export var tile_scale: float = 1.0
@export var bob_amplitude: float = 0.0           ## плавное покачивание (парящие острова)
@export var bob_speed: float = 0.5
@export var phase: float = 0.0

var _tex: Texture2D
var _mat: ShaderMaterial


func _ready() -> void:
	_tex = LayerTextures.get_texture(kind)
	_mat = ShaderMaterial.new()
	_mat.shader = shader
	material = _mat


func _process(_delta: float) -> void:
	var p: Dictionary = Game.palette
	_mat.set_shader_parameter("tint", p[String(tint_key)])
	_mat.set_shader_parameter("fog_color", p["fog"])
	_mat.set_shader_parameter("fog_amount", fog_amount)
	var k: float = intensity
	if flicker > 0.0:
		k *= 1.0 - flicker * (0.5 + 0.5 * sin(Game.elapsed * 3.1 + phase) * sin(Game.elapsed * 1.3 + phase * 2.0))
	_mat.set_shader_parameter("intensity", k)
	_mat.set_shader_parameter("opacity", opacity)
	position.y = roundf(sin(Game.elapsed * bob_speed + phase) * bob_amplitude / float(Game.PIXEL)) * float(Game.PIXEL)
	queue_redraw()


func _draw() -> void:
	if _tex == null:
		return
	var vw: float = Game.view_size.x
	var px: float = float(Game.PIXEL)
	var tw: float = float(_tex.get_width()) * px * tile_scale
	var th: float = float(_tex.get_height()) * px * tile_scale
	var y: float = roundf((bottom_y if anchor_top else bottom_y - th) / px) * px
	var x: float = -floorf(fposmod(Game.distance * scroll_factor + scroll_offset, tw) / px) * px
	while x < vw:
		draw_texture_rect(_tex, Rect2(x, y, tw + px, th), false)
		x += tw
