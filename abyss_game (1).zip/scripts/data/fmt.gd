extends RefCounted
## Форматирование больших чисел: 1.23K, 4.5M, … QA, QI, SX … (в шрифте всё в верхнем регистре).

const SUFFIXES: Array[String] = ["", "K", "M", "B", "T", "Qa", "Qi", "Sx", "Sp", "Oc", "No", "Dc", "Ud", "Dd", "Td", "Qad", "Qid"]


static func num(v: float) -> String:
	if v < 0.0:
		return "-" + num(-v)
	if v < 1000.0:
		return str(int(v)) if v >= 10.0 or v == floorf(v) else "%.1f" % v
	var idx: int = 0
	var x: float = v
	while x >= 1000.0 and idx < SUFFIXES.size() - 1:
		x /= 1000.0
		idx += 1
	if x >= 1000.0:
		return "%.2fe%d" % [v / pow(10.0, floorf(log(v) / log(10.0))), int(floorf(log(v) / log(10.0)))]
	var s: String
	if x < 10.0:
		s = "%.2f" % x
	elif x < 100.0:
		s = "%.1f" % x
	else:
		s = "%d" % int(x)
	return s + SUFFIXES[idx]


static func time(seconds: float) -> String:
	var s: int = int(maxf(0.0, seconds))
	var d: int = s / 86400
	var h: int = (s % 86400) / 3600
	var m: int = (s % 3600) / 60
	var sec: int = s % 60
	if d > 0:
		return "%dД %dЧ" % [d, h]
	if h > 0:
		return "%d:%02d:%02d" % [h, m, sec]
	return "%d:%02d" % [m, sec]
