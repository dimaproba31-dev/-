extends RefCounted
## Питомцы: виды и качество. Качество задаёт цвет, редкость выпадения и бонус к золоту/доходу.

const RARITIES: Array[Dictionary] = [
	{"name": "Низкое", "color": Color(0.64, 0.64, 0.68), "weight": 50.0, "bonus": 3.0},
	{"name": "Нормальное", "color": Color(0.30, 0.85, 0.35), "weight": 28.0, "bonus": 6.0},
	{"name": "Выше среднего", "color": Color(0.28, 0.55, 1.0), "weight": 13.0, "bonus": 12.0},
	{"name": "Хорошее", "color": Color(0.72, 0.38, 1.0), "weight": 6.0, "bonus": 22.0},
	{"name": "Отличное", "color": Color(1.0, 0.52, 0.12), "weight": 2.2, "bonus": 40.0},
	{"name": "Превосходное", "color": Color(0.62, 1.0, 0.1), "weight": 0.7, "bonus": 70.0},
	{"name": "Божественное", "color": Color(1.0, 0.82, 0.2), "weight": 0.12, "bonus": 130.0},
]

const SPECIES: Array[Dictionary] = [
	{"name": "Дракончик"},
	{"name": "Око Бездны"},
	{"name": "Теневой лис"},
]


static func roll_rarity(bias: int = 0) -> int:
	var total: float = 0.0
	for r in RARITIES:
		total += float(r["weight"])
	var x: float = randf() * total
	var idx: int = 0
	for i in range(RARITIES.size()):
		x -= float(RARITIES[i]["weight"])
		if x <= 0.0:
			idx = i
			break
		idx = i
	return mini(idx + bias, RARITIES.size() - 1)


static func color_of(r: int) -> Color:
	return RARITIES[clampi(r, 0, RARITIES.size() - 1)]["color"]


static func title(species: int, rarity: int) -> String:
	return "%s (%s)" % [SPECIES[species]["name"], String(RARITIES[rarity]["name"]).to_lower()]
