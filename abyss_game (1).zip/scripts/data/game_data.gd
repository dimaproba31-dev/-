extends RefCounted
## Статические данные игры: снаряжение, улучшения, задания, достижения. Всё на русском, названия — свои.

const MILESTONES: Array[int] = [10, 25, 50, 100, 150, 200, 250, 300, 400, 500, 600, 700, 800, 900, 1000]

## Снаряжение: пассивный доход (монет/с) = base_income × уровень × 2^(пройденные вехи) × бонусы.
const EQUIPMENT: Array[Dictionary] = [
	{"id": "sword", "name": "Клинок Рассвета", "icon": "sword", "base_cost": 22.5, "growth": 1.25, "base_income": 0.5},
	{"id": "shield", "name": "Щит Стража", "icon": "shield", "base_cost": 180, "growth": 1.25, "base_income": 4.0},
	{"id": "armor", "name": "Доспех Падшего", "icon": "armor", "base_cost": 1650, "growth": 1.25, "base_income": 34.0},
	{"id": "helm", "name": "Шлем Теней", "icon": "helm", "base_cost": 18000, "growth": 1.25, "base_income": 300.0},
	{"id": "boots", "name": "Сапоги Странника", "icon": "boots", "base_cost": 210000, "growth": 1.25, "base_income": 2800.0},
	{"id": "bow", "name": "Лук Шёпота", "icon": "bow", "base_cost": 2.7e+06, "growth": 1.25, "base_income": 27000.0},
	{"id": "ring", "name": "Кольцо Затмения", "icon": "ring", "base_cost": 3.9e+07, "growth": 1.25, "base_income": 2.7e5},
	{"id": "amulet", "name": "Амулет Бездны", "icon": "amulet", "base_cost": 6.3e+08, "growth": 1.25, "base_income": 2.9e6},
]

## Улучшения за монеты (сбрасываются при перерождении). key — эффект, val — величина.
const UPGRADES: Array[Dictionary] = [
	{"id": "u_double", "name": "Двойной прыжок", "icon": "wing", "desc": "Позволяет прыгнуть ещё раз в воздухе.", "cost": 1000, "key": "double_jump", "val": 1.0},
	{"id": "u_magnet", "name": "Магнит монет", "icon": "magnet", "desc": "Монеты и осколки притягиваются к герою.", "cost": 6250, "key": "magnet", "val": 140.0},
	{"id": "u_reach", "name": "Длинный клинок", "icon": "sword", "desc": "Меч достаёт врагов на 40% дальше.", "cost": 30000, "key": "melee_range", "val": 40.0},
	{"id": "u_auto", "name": "Авто-лук", "icon": "bow", "desc": "Сам стреляет по летающим врагам.", "cost": 150000, "key": "auto_bolt", "val": 1.6},
	{"id": "u_gold", "name": "Золотая лихорадка", "icon": "star", "desc": "Монеты стоят на 50% больше.", "cost": 750000, "key": "coin_pct", "val": 50.0},
	{"id": "u_clover", "name": "Клевер удачи", "icon": "clover", "desc": "Сундуки-мимики появляются чаще.", "cost": 3.75e+06, "key": "chest_pct", "val": 60.0},
	{"id": "u_blood", "name": "Жажда осколков", "icon": "skull", "desc": "+50% осколков за убийства.", "cost": 2e+07, "key": "shard_pct", "val": 50.0},
	{"id": "u_rage", "name": "Накал ярости", "icon": "flame", "desc": "Ярость копится на 50% быстрее.", "cost": 1e+08, "key": "rage_gain", "val": 50.0},
	{"id": "u_boots", "name": "Лёгкая поступь", "icon": "boots", "desc": "Мир движется на 10% быстрее.", "cost": 5e+08, "key": "speed_pct", "val": 10.0},
	{"id": "u_potion", "name": "Зелье достатка", "icon": "potion", "desc": "Пассивный доход ×2.", "cost": 2.5e+09, "key": "income_pct", "val": 100.0},
	{"id": "u_boss", "name": "Охотник на боссов", "icon": "trophy", "desc": "Боссы дают вдвое больше.", "cost": 1.25e+10, "key": "boss_pct", "val": 100.0},
	{"id": "u_speed", "name": "Быстрая тетива", "icon": "bolt", "desc": "Стрельба быстрее на 30%.", "cost": 6.25e+10, "key": "shoot_cd_pct", "val": 30.0},
	{"id": "u_scroll", "name": "Свиток разломов", "icon": "scroll", "desc": "Разломы появляются чаще.", "cost": 3.75e+11, "key": "portal_pct", "val": 100.0},
	{"id": "u_shield", "name": "Печать стража", "icon": "shield", "desc": "Весь доход +100%.", "cost": 5e+13, "key": "income_pct", "val": 100.0},
]

## Шаблоны ежедневных и еженедельных заданий.
const QUEST_TEMPLATES: Array[Dictionary] = [
	{"id": "q_kill", "event": "kill", "text": "Победите %s врагов", "daily": [25, 60], "weekly": [300, 600]},
	{"id": "q_coin", "event": "coin_pick", "text": "Соберите %s монет", "daily": [60, 140], "weekly": [800, 1500]},
	{"id": "q_dist", "event": "distance_m", "text": "Пробегите %s м", "daily": [800, 2000], "weekly": [8000, 16000]},
	{"id": "q_rage", "event": "rage", "text": "Включите ярость %s раз", "daily": [1, 3], "weekly": [6, 12]},
	{"id": "q_boss", "event": "boss", "text": "Победите боссов: %s", "daily": [1, 3], "weekly": [8, 16]},
	{"id": "q_chest", "event": "chest", "text": "Откройте сундуков: %s", "daily": [2, 5], "weekly": [20, 40]},
	{"id": "q_portal", "event": "portal", "text": "Войдите в разломы: %s", "daily": [1, 3], "weekly": [6, 12]},
	{"id": "q_buy", "event": "buy", "text": "Улучшите снаряжение: %s раз", "daily": [10, 40], "weekly": [150, 400]},
	{"id": "q_jump", "event": "jump", "text": "Прыгните %s раз", "daily": [40, 100], "weekly": [500, 1000]},
]

## Достижения: за каждый достигнутый порог +2% к доходу и стоимости монет навсегда.
const ACHIEVEMENTS: Array[Dictionary] = [
	{"id": "a_kill", "stat": "kills", "name": "Охотник", "text": "Победите врагов", "tiers": [100, 1000, 10000, 100000, 1000000]},
	{"id": "a_coin", "stat": "coins_total", "name": "Золотая жила", "text": "Заработайте монет", "tiers": [1e3, 1e6, 1e9, 1e12, 1e15, 1e18]},
	{"id": "a_dist", "stat": "distance_m", "name": "Странник", "text": "Пробегите метров", "tiers": [1000, 10000, 100000, 1000000]},
	{"id": "a_boss", "stat": "bosses", "name": "Убийца титанов", "text": "Победите боссов", "tiers": [5, 50, 500]},
	{"id": "a_reb", "stat": "rebirths", "name": "Феникс", "text": "Переродитесь", "tiers": [1, 5, 25, 100]},
	{"id": "a_shard", "stat": "shards", "name": "Собиратель осколков", "text": "Соберите осколков", "tiers": [100, 10000, 1000000, 100000000]},
	{"id": "a_chest", "stat": "chests", "name": "Взломщик", "text": "Откройте сундуков", "tiers": [10, 100, 1000]},
	{"id": "a_portal", "stat": "portals", "name": "Пространник", "text": "Войдите в разломы", "tiers": [5, 50, 500]},
	{"id": "a_items", "stat": "items", "name": "Кузнец", "text": "Улучшите снаряжение", "tiers": [100, 1000, 10000]},
	{"id": "a_rage", "stat": "rage", "name": "Берсерк", "text": "Включите ярость", "tiers": [10, 100, 1000]},
]


## Деревня: постоянные постройки за души. Каждый уровень даёт эффект навсегда (даже после перерождения).
const VILLAGE: Array[Dictionary] = [
	{"id": "forge", "name": "Кузница", "icon": "sword", "desc": "+15% к урону за уровень", "key": "dmg_pct", "per": 15.0, "base": 3.0, "growth": 1.55, "max": 20},
	{"id": "market", "name": "Рынок", "icon": "bag", "desc": "+8% к стоимости монет за уровень", "key": "coin_pct", "per": 8.0, "base": 2.0, "growth": 1.5, "max": 30},
	{"id": "shrine", "name": "Святилище", "icon": "star", "desc": "+6% к пассивному доходу за уровень", "key": "income_pct", "per": 6.0, "base": 4.0, "growth": 1.55, "max": 30},
	{"id": "alchemist", "name": "Алхимик", "icon": "potion", "desc": "Ярость копится на 6% быстрее за уровень", "key": "rage_gain", "per": 6.0, "base": 3.0, "growth": 1.5, "max": 20},
	{"id": "crypt", "name": "Склеп", "icon": "skull", "desc": "+8% осколков за уровень", "key": "shard_pct", "per": 8.0, "base": 5.0, "growth": 1.55, "max": 25},
	{"id": "tavern", "name": "Таверна", "icon": "clock", "desc": "Офлайн-доход копится на 0.5 ч дольше за уровень", "key": "offline_hours", "per": 0.5, "base": 6.0, "growth": 1.6, "max": 16},
	{"id": "library", "name": "Библиотека", "icon": "scroll", "desc": "+3% очков Бездны за перерождение за уровень", "key": "points_pct", "per": 3.0, "base": 8.0, "growth": 1.6, "max": 20},
	{"id": "tower", "name": "Сторожевая башня", "icon": "magnet", "desc": "Разломы и сундуки чаще на 8% за уровень", "key": "portal_pct", "per": 8.0, "base": 10.0, "growth": 1.6, "max": 15},
]

## Измерения: открываются перерождениями, меняют вид мира и множители.
const DIMENSIONS: Array[Dictionary] = [
	{"id": "crimson", "name": "Багровая бездна", "need": 0, "desc": "Родной мир. Без бонусов и штрафов.", "coin": 1.0, "shard": 1.0, "income": 1.0, "soul": 1.0, "tint": 0},
	{"id": "swamp", "name": "Изумрудные топи", "need": 2, "desc": "Осколков ×1.8, монеты ×0.85.", "coin": 0.85, "shard": 1.8, "income": 1.0, "soul": 1.0, "tint": 1},
	{"id": "azure", "name": "Лазурная пустота", "need": 6, "desc": "Монеты ×1.8, осколки ×0.8.", "coin": 1.8, "shard": 0.8, "income": 1.0, "soul": 1.0, "tint": 2},
	{"id": "void", "name": "Тёмное солнце", "need": 15, "desc": "Доход ×1.6, души ×2, монеты ×0.9.", "coin": 0.9, "shard": 1.0, "income": 1.6, "soul": 2.0, "tint": 3},
]
