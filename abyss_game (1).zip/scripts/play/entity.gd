extends RefCounted
## Один объект на дороге: монета, осколок, враг, сундук, босс, портал, снаряд.
## Лёгкая структура данных; логика — в entity_layer.gd.

var kind: String = ""
var tex: String = ""
var pos: Vector2 = Vector2.ZERO
var half: Vector2 = Vector2(16, 16)    ## половина хитбокса, логические px
var hp: float = 1.0
var max_hp: float = 1.0
var t: float = 0.0
var alive: bool = true
var value: float = -1.0                ## -1 — значение по умолчанию (цена монеты и т.п.)
var fps: float = 8.0
var variant: int = 0
var flash: float = 0.0
var magnet: bool = false
var delay: float = 0.0
var base_y: float = 0.0
var phase: float = 0.0
var life: float = 0.0
var state: int = 0
var approach: float = 0.0              ## собственная скорость навстречу герою
var vel: Vector2 = Vector2.ZERO
var target: RefCounted = null          ## для снарядов
var last_hit: float = 0.0
var scroll: float = 1.0                ## множитель прокрутки вместе с миром
var tag: String = ""
var frame: int = -1                    ## принудительный кадр (босс)
var act: int = 0                       ## подфаза босса
var act_t: float = 0.0
var cycles: int = 0
var hit_done: bool = false


func is_enemy() -> bool:
	return kind == "worm" or kind == "golem" or kind == "bat" or kind == "skull" or kind == "chest"


func is_pickup() -> bool:
	return kind == "coin" or kind == "gem"
