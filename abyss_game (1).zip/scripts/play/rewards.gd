extends RefCounted
## Награды за убийства и подборы: монеты, осколки, заряд ярости, эффекты и звуки.

const Fmt := preload("res://scripts/data/fmt.gd")
const PetData := preload("res://scripts/data/pet_data.gd")

const KILL_COINS: Dictionary = {"worm": 3.0, "golem": 6.0, "bat": 4.0, "skull": 5.0}


static func charge_rage(amount: float) -> void:
	if Game.rage_active:
		return
	Save.d["rage"] = minf(1.0, float(Save.d["rage"]) + amount * Eco.rage_gain_mult())


static func kill_enemy(fx: Node2D, e: RefCounted, crit: bool = false) -> void:
	var mult: float = float(KILL_COINS.get(e.kind, 3.0))
	var coins: float = Eco.coin_value() * mult * (2.0 if crit else 1.0) * (4.0 if e.tag == "gallery" else 1.0)
	Eco.add_coins(coins)
	var shards: float = (1.0 + float(Eco.zone_number()) * 0.5) * Eco.shard_mult()
	Eco.add_shards(shards)
	Eco.event("kill", 1.0)
	var soul_chance: float = 0.12 if e.kind == "golem" else (0.07 if e.kind == "skull" else 0.0)
	if randf() < soul_chance:
		Eco.add_souls(1.0)
		fx.popup("+1 ДУША", e.pos + Vector2(0, -50), Color(0.8, 0.6, 1.0), 2)
	charge_rage(0.02)
	roll_pet(fx, e)
	if crit:
		fx.popup("КРИТ!", e.pos + Vector2(0, -56), Color(1.0, 0.45, 0.3), 3)
	fx.popup("+" + Fmt.num(coins), e.pos + Vector2(0, -20), Color(1.0, 0.85, 0.25), 3 if crit else 2)
	fx.popup("+" + Fmt.num(shards), e.pos + Vector2(0, 6), Color(0.5, 0.8, 1.0), 2)
	fx.burst(e.pos, Color(1.0, 0.7, 0.2), 8)
	fx.burst(e.pos, Color(0.4, 0.75, 1.0), 4, 200.0)
	Sfx.play("kill")


static func pick_coin(fx: Node2D, e: RefCounted) -> void:
	var v: float = Eco.coin_value() if e.value < 0.0 else e.value
	Eco.add_coins(v)
	Eco.event("coin_pick", 1.0)
	fx.popup("+" + Fmt.num(v), e.pos + Vector2(0, -24), Color(1.0, 0.85, 0.25), 2)
	Sfx.play("coin", 1.0 + randf() * 0.12)


static func pick_gem(fx: Node2D, e: RefCounted) -> void:
	var v: float = (3.0 if e.value < 0.0 else e.value) * Eco.shard_mult()
	Eco.add_shards(v)
	charge_rage(0.01)
	fx.popup("+" + Fmt.num(v), e.pos + Vector2(0, -24), Color(0.5, 0.82, 1.0), 2)
	Sfx.play("gem")


const PET_CHANCE: Dictionary = {"worm": 0.03, "golem": 0.06, "bat": 0.03, "skull": 0.045, "boss": 1.0, "chest": 0.25}


static func roll_pet(fx: Node2D, e: RefCounted) -> void:
	var ch: float = float(PET_CHANCE.get(e.kind, 0.03)) * (1.0 + float(Eco.m.get("pet_pct", 0.0)) / 100.0)
	if randf() < ch:
		drop_pet(fx, e.pos, randi() % PetData.SPECIES.size(), PetData.roll_rarity(2 if e.kind == "boss" else 0))


## Выдаёт питомца игроку: столб света цвета качества, надпись, авто-экипировка лучшего.
static func drop_pet(fx: Node2D, pos: Vector2, species: int, rarity: int) -> void:
	var pets: Array = Save.d["pets"]
	pets.append([species, rarity])
	var cur: int = int(Save.d["pet"])
	var cur_r: int = -1
	if cur >= 0 and cur < pets.size() - 1:
		cur_r = int((pets[cur] as Array)[1])
	if rarity > cur_r:
		Save.d["pet"] = pets.size() - 1
	Eco.recalc()
	var col: Color = PetData.color_of(rarity)
	fx.loot_beam(pos, col, rarity)
	fx.popup("ПИТОМЕЦ!", pos + Vector2(0, -90), col, 3)
	fx.popup(PetData.title(species, rarity), pos + Vector2(0, -60), col, 2)
	Sfx.play("gem", 0.7)
