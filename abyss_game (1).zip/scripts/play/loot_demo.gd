extends Node2D
## Демонстрация лута: по очереди выпадают питомцы всех 7 качеств, затем витрина.
## Запуск: --loot-demo

const PetData := preload("res://scripts/data/pet_data.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")
const Pet := preload("res://scripts/hero/pet.gd")
const Rewards := preload("res://scripts/play/rewards.gd")

var _t: float = 0.0
var _step: int = 0
var _show: bool = false
var _pets: Array[Node2D] = []


func _ready() -> void:
	z_index = 30


func _process(delta: float) -> void:
	_t += delta
	var hero: Node2D = Game.hero
	if hero == null:
		return
	var fx: Node2D = hero.get_node_or_null("../Fx") as Node2D
	if fx == null:
		return
	if _step < 7 and _t > 1.5 + float(_step) * 1.3:
		var pos: Vector2 = hero.position + Vector2(260.0 + float(_step % 2) * 90.0, 0.0)
		Rewards.drop_pet(fx, pos, _step % 3, _step)
		_step += 1
	if _step >= 7 and not _show and _t > 1.5 + 7.0 * 1.3 + 1.2:
		_show = true
		var names: Array = PetData.RARITIES
		for i in range(7):
			var p: Node2D = Pet.new()
			p.follow = false
			p.label = true
			p.position = Vector2(150.0 + float(i) * 163.0, 250.0)
			p.call("set_pet", i % 3, i)
			add_child(p)
			_pets.append(p)
	queue_redraw()


func _draw() -> void:
	if not _show:
		return
	draw_rect(Rect2(0, 110, 1280, 270), Color(0.03, 0.01, 0.06, 0.82))
	draw_rect(Rect2(0, 110, 1280, 4), Color(1.0, 0.8, 0.3, 0.8))
	draw_rect(Rect2(0, 376, 1280, 4), Color(1.0, 0.8, 0.3, 0.8))
	PixelFont.draw_text_centered(self, "КАЧЕСТВО ПИТОМЦЕВ", 640.0, 126.0, 3, Color(1.0, 0.9, 0.6))
