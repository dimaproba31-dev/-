extends Node2D
## Эффекты: всплывающие числа, пиксельные искры. Рисуются в логических координатах мира.

const PixelFont := preload("res://scripts/hud/pixel_font.gd")

var _pops: Array[Dictionary] = []
var _sparks: Array[Dictionary] = []
var _beams: Array[Dictionary] = []
var _impacts: Array[Dictionary] = []   ## {p, age, life, big, kind}


func popup(text: String, pos: Vector2, color: Color = Color(1.0, 0.85, 0.25), size: int = 2) -> void:
	if _pops.size() > 60:
		_pops.pop_front()
	_pops.append({"t": text, "p": pos, "c": color, "age": 0.0, "s": size})


func burst(pos: Vector2, color: Color, n: int = 10, speed: float = 260.0) -> void:
	for i in range(n):
		if _sparks.size() > 300:
			break
		var a: float = randf() * TAU
		var v: float = randf_range(0.3, 1.0) * speed
		_sparks.append({"p": pos, "v": Vector2(cos(a), sin(a)) * v + Vector2(0, -80), "c": color, "age": 0.0, "life": randf_range(0.3, 0.6)})


func impact(pos: Vector2, big: bool = false) -> void:
	_impacts.append({"p": pos, "age": 0.0, "life": 0.22 if big else 0.16, "big": big, "k": "star"})


func loot_beam(pos: Vector2, color: Color, rarity: int) -> void:
	_beams.append({"p": pos, "c": color, "r": rarity, "age": 0.0, "life": 1.4 + 0.15 * float(rarity)})
	ring(pos, color)
	burst(pos, color, 10 + rarity * 5, 300.0 + 40.0 * float(rarity))


func ring(pos: Vector2, color: Color) -> void:
	_impacts.append({"p": pos, "age": 0.0, "life": 0.3, "big": true, "k": "ring", "c": color})


func dust(pos: Vector2, n: int = 6) -> void:
	for i in range(n):
		if _sparks.size() > 300:
			break
		var v: Vector2 = Vector2(randf_range(-180.0, 40.0), randf_range(-90.0, -20.0))
		_sparks.append({"p": pos + Vector2(randf_range(-10.0, 10.0), -2.0), "v": v, "c": Color(0.75, 0.6, 0.5), "age": 0.0, "life": randf_range(0.25, 0.45), "g": 200.0})


## Угольки и пепел: поднимаются вверх, из оранжевого остывают в серый.
func ash(pos: Vector2, n: int = 12, spread: float = 28.0) -> void:
	for i in range(n):
		if _sparks.size() > 300:
			break
		_sparks.append({"p": pos + Vector2(randf_range(-spread, spread), randf_range(-spread, spread)),
				"v": Vector2(randf_range(-70.0, 70.0), randf_range(-170.0, -40.0)),
				"c": Color(1.0, randf_range(0.45, 0.8), 0.12), "c2": Color(0.30, 0.26, 0.30),
				"age": 0.0, "life": randf_range(0.55, 1.2), "g": -40.0})


func trail(pos: Vector2, color: Color) -> void:
	if _sparks.size() > 300:
		return
	_sparks.append({"p": pos, "v": Vector2(randf_range(-40.0, 40.0), randf_range(-40.0, 40.0)), "c": color, "age": 0.0, "life": 0.25, "g": 0.0})


func _process(delta: float) -> void:
	for im in _impacts:
		im["age"] = float(im["age"]) + delta
	_impacts = _impacts.filter(func(i: Dictionary) -> bool: return float(i["age"]) < float(i["life"]))
	for b in _beams:
		b["age"] = float(b["age"]) + delta
	_beams = _beams.filter(func(b: Dictionary) -> bool: return float(b["age"]) < float(b["life"]))
	for p in _pops:
		p["age"] = float(p["age"]) + delta
		p["p"] = (p["p"] as Vector2) + Vector2(0, -70.0 * delta)
	_pops = _pops.filter(func(p: Dictionary) -> bool: return float(p["age"]) < 0.9)
	for s in _sparks:
		s["age"] = float(s["age"]) + delta
		s["v"] = (s["v"] as Vector2) + Vector2(0, float(s.get("g", 900.0)) * delta)
		s["p"] = (s["p"] as Vector2) + (s["v"] as Vector2) * delta
	_sparks = _sparks.filter(func(s: Dictionary) -> bool: return float(s["age"]) < float(s["life"]))
	queue_redraw()


func _draw() -> void:
	var px: float = float(Game.PIXEL)
	for im in _impacts:
		var f: float = float(im["age"]) / float(im["life"])
		var p: Vector2 = im["p"]
		p = Vector2(roundf(p.x / px) * px, roundf(p.y / px) * px)
		if im["k"] == "ring":
			var r: float = (10.0 + 70.0 * f) * 1.0
			var c: Color = im["c"]
			for i in range(24):
				var a: float = float(i) / 24.0 * TAU
				var q: Vector2 = p + Vector2(cos(a), sin(a) * 0.55) * r
				draw_rect(Rect2(roundf(q.x / px) * px, roundf(q.y / px) * px, px * 2.0, px * 2.0), Color(c.r, c.g, c.b, 1.0 - f))
			continue
		var big: bool = im["big"]
		var len0: float = (46.0 if big else 30.0) * (1.0 - f * 0.4)
		var w: float = px * (3.0 if f < 0.5 else 2.0)
		var col: Color = Color(1.0, 1.0, 0.85, 1.0 - f * 0.6)
		for k in range(8):
			var a2: float = float(k) / 8.0 * TAU + 0.4
			var l: float = len0 * (1.0 if k % 2 == 0 else 0.55) * (0.4 + f)
			var a_dir := Vector2(cos(a2), sin(a2))
			draw_line(p + a_dir * 6.0, p + a_dir * l, col, w if k % 2 == 0 else px * 2.0)
		draw_circle(p, (10.0 if big else 7.0) * (1.0 - f), Color(1, 1, 1, 0.9 * (1.0 - f)))
	for b in _beams:
		var f2: float = float(b["age"]) / float(b["life"])
		var cc: Color = b["c"]
		var bp: Vector2 = b["p"]
		var rr: int = int(b["r"])
		var a3: float = clampf(1.0 - f2, 0.0, 1.0)
		var w0: float = (10.0 + 4.0 * float(rr)) * (1.0 - f2 * 0.4)
		var hgt: float = 360.0 + 30.0 * float(rr)
		for i in range(6):
			var k: float = float(i) / 5.0
			draw_rect(Rect2(bp.x - w0 * (1.0 - k * 0.7) * 0.5, bp.y - hgt, w0 * (1.0 - k * 0.7), hgt), Color(cc.r, cc.g, cc.b, 0.16 * a3))
		draw_rect(Rect2(bp.x - px * 2.0, bp.y - hgt, px * 4.0, hgt), Color(1, 1, 1, 0.55 * a3))
		draw_circle(bp, 14.0 + 6.0 * float(rr), Color(cc.r, cc.g, cc.b, 0.25 * a3))
	for s in _sparks:
		var a: float = 1.0 - float(s["age"]) / float(s["life"])
		var c: Color = s["c"]
		if s.has("c2"):
			c = c.lerp(s["c2"], 1.0 - a)
		var p: Vector2 = (s["p"] as Vector2)
		draw_rect(Rect2(floorf(p.x / px) * px, floorf(p.y / px) * px, px * 2.0, px * 2.0), Color(c.r, c.g, c.b, clampf(a * 1.5, 0.0, 1.0)))
	for p in _pops:
		var a2: float = clampf(1.6 - float(p["age"]) * 1.8, 0.0, 1.0)
		var c2: Color = p["c"]
		var pos: Vector2 = p["p"]
		var sc: int = int(p["s"])
		var tx: String = String(p["t"])
		var w: float = float(PixelFont.text_width(tx, sc))
		PixelFont.draw_text(self, tx, Vector2(floorf((pos.x - w * 0.5) / px) * px, floorf(pos.y / px) * px), sc, Color(c2.r, c2.g, c2.b, a2), Color(0.05, 0.02, 0.06, a2))
