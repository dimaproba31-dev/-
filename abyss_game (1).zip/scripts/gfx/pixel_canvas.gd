extends RefCounted
## Маленький растеризатор для пиксель-арта: фигуры (круги, линии, полигоны) кладутся в карту
## материалов, затем bake() превращает её в картинку с тремя тонами и тёмной обводкой.
## Палитра: id материала -> Color (база; тень/свет считаются сами) или Array из 3 Color [тень, база, свет].

var w: int
var h: int
var ids: PackedByteArray = PackedByteArray()
var pal: Dictionary = {}
var outline_color: Color = Color(0.03, 0.01, 0.04)


func _init(width: int, height: int, palette: Dictionary) -> void:
	w = width
	h = height
	ids.resize(w * h)
	for k in palette.keys():
		var v: Variant = palette[k]
		if v is Color:
			var c: Color = v
			pal[k] = [c.darkened(0.38), c, c.lightened(0.38)]
		else:
			pal[k] = v


func clear() -> void:
	ids.fill(0)


func put(x: int, y: int, id: int) -> void:
	if x < 0 or y < 0 or x >= w or y >= h:
		return
	ids[y * w + x] = id


func rect(x: int, y: int, rw: int, rh: int, id: int) -> void:
	for yy in range(y, y + rh):
		for xx in range(x, x + rw):
			put(xx, yy, id)


func ellipse(c: Vector2, rx: float, ry: float, id: int) -> void:
	if rx <= 0.0 or ry <= 0.0:
		return
	var x0: int = int(floor(c.x - rx))
	var x1: int = int(ceil(c.x + rx))
	var y0: int = int(floor(c.y - ry))
	var y1: int = int(ceil(c.y + ry))
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			var dx: float = (float(x) + 0.5 - c.x) / rx
			var dy: float = (float(y) + 0.5 - c.y) / ry
			if dx * dx + dy * dy <= 1.0:
				put(x, y, id)


func disc(c: Vector2, r: float, id: int) -> void:
	ellipse(c, r, r, id)


func line(a: Vector2, b: Vector2, width: float, id: int) -> void:
	var n: int = maxi(1, int(a.distance_to(b) * 2.0))
	for i in range(n + 1):
		disc(a.lerp(b, float(i) / float(n)), width * 0.5, id)


func poly(pts: PackedVector2Array, id: int) -> void:
	var n: int = pts.size()
	if n < 3:
		return
	var ymin: float = pts[0].y
	var ymax: float = pts[0].y
	for p in pts:
		ymin = minf(ymin, p.y)
		ymax = maxf(ymax, p.y)
	for y in range(int(floor(ymin)), int(ceil(ymax)) + 1):
		var yc: float = float(y) + 0.5
		var xs: Array[float] = []
		for i in range(n):
			var p: Vector2 = pts[i]
			var q: Vector2 = pts[(i + 1) % n]
			if (p.y <= yc and q.y > yc) or (q.y <= yc and p.y > yc):
				xs.append(p.x + (yc - p.y) / (q.y - p.y) * (q.x - p.x))
		xs.sort()
		var k: int = 0
		while k + 1 < xs.size():
			for x in range(int(round(xs[k])), int(round(xs[k + 1]))):
				put(x, y, id)
			k += 2


## tint: умножается на цвета (для перекраски вариантов). flash: осветляет к белому.
func bake(outline: bool = true, tint: Color = Color.WHITE, flash: float = 0.0) -> Image:
	var img: Image = Image.create_empty(w, h, false, Image.FORMAT_RGBA8)
	for y in range(h):
		for x in range(w):
			var id: int = ids[y * w + x]
			if id == 0:
				continue
			var tri: Array = pal[id]
			var up: int = ids[(y - 1) * w + x] if y > 0 else 0
			var dn: int = ids[(y + 1) * w + x] if y < h - 1 else 0
			var lf: int = ids[y * w + x - 1] if x > 0 else 0
			var col: Color = tri[1]
			if up != id:
				col = tri[2]
			elif dn != id or lf != id:
				col = tri[0]
			col = Color(col.r * tint.r, col.g * tint.g, col.b * tint.b, 1.0)
			if flash > 0.0:
				col = col.lerp(Color.WHITE, flash)
			img.set_pixel(x, y, col)
	if outline:
		for y in range(h):
			for x in range(w):
				if ids[y * w + x] != 0:
					continue
				var near: bool = false
				if x > 0 and ids[y * w + x - 1] != 0:
					near = true
				elif x < w - 1 and ids[y * w + x + 1] != 0:
					near = true
				elif y > 0 and ids[(y - 1) * w + x] != 0:
					near = true
				elif y < h - 1 and ids[(y + 1) * w + x] != 0:
					near = true
				if near:
					img.set_pixel(x, y, outline_color)
	return img


func to_texture(outline: bool = true, tint: Color = Color.WHITE, flash: float = 0.0) -> ImageTexture:
	return ImageTexture.create_from_image(bake(outline, tint, flash))
