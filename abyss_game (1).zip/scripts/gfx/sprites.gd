extends RefCounted
## Процедурные пиксель-спрайты: монеты, осколки, враги, боссы, портал, иконки.
## Все рисуются через PixelCanvas (3 тона + обводка), кадры анимации кэшируются.
## ВРЕМЕННЫЙ арт: любой спрайт можно заменить нарисованным — достаточно вернуть другую текстуру из get_tex().

const PC := preload("res://scripts/gfx/pixel_canvas.gd")
const PetData := preload("res://scripts/data/pet_data.gd")

const FRAMES: Dictionary = {
	"coin": 4, "gem": 3, "bat": 4, "skull": 3, "worm": 4, "golem": 2, "chest": 4,
	"boss": 7, "wave": 4, "portal": 4, "bolt": 1, "pet": 4,
}
const BOSS_TINTS: Array[Color] = [Color(1, 1, 1), Color(0.75, 0.55, 1.15), Color(0.6, 1.1, 0.65), Color(0.6, 0.85, 1.2)]

static var _cache: Dictionary = {}


static func frame_count(name: String) -> int:
	return int(FRAMES.get(name, 1))


static func get_tex(name: String, frame: int = 0, variant: int = 0) -> Texture2D:
	var f: int = frame % frame_count(name)
	var key: String = "%s:%d:%d" % [name, f, variant]
	if _cache.has(key):
		return _cache[key]
	var tex: Texture2D = _build(name, f, variant)
	_cache[key] = tex
	return tex


static func icon(name: String) -> Texture2D:
	var key: String = "icon:" + name
	if _cache.has(key):
		return _cache[key]
	var tex: Texture2D = _build_icon(name)
	_cache[key] = tex
	return tex


static func _build(name: String, f: int, variant: int) -> Texture2D:
	match name:
		"coin": return _coin(f)
		"gem": return _gem(f)
		"bat": return _bat(f)
		"skull": return _skull(f)
		"worm": return _worm(f)
		"golem": return _golem(f)
		"chest": return _chest(f)
		"boss": return _boss(f, variant)
		"portal": return _portal(f)
		"wave": return _wave(f)
		"bolt": return _bolt()
		"pet": return _pet(f, variant)
	push_error("Sprites: нет спрайта " + name)
	return null


# --------------------------------------------------------------------------- пикапы

static func _coin(f: int) -> Texture2D:
	var c := PC.new(24, 24, {1: Color(1.0, 0.76, 0.12), 2: Color(1.0, 0.92, 0.45), 3: Color(0.78, 0.38, 0.04), 4: Color(1.0, 1.0, 0.92)})
	var rx: float = [11.0, 8.0, 3.2, 8.0][f]
	c.ellipse(Vector2(12, 12), rx + 0.6, 11.6, 3)
	c.ellipse(Vector2(12, 12), rx, 11.0, 1)
	if f != 2:
		var ri: float = maxf(rx - 3.0, 0.6)
		c.ellipse(Vector2(12, 12), ri, 8.2, 3)
		c.ellipse(Vector2(12, 12), maxf(ri - 1.0, 0.4), 7.2, 2)
		# блик
		if f == 0 or f == 3:
			c.rect(7, 6, 3, 3, 4)
			c.rect(7, 9, 2, 4, 4)
		# узор: вертикальная метка в центре
		c.rect(11, 8, 2, 8, 1)
	return c.to_texture()


static func _gem(f: int) -> Texture2D:
	var c := PC.new(14, 20, {1: Color(0.28, 0.6, 1.0), 2: Color(0.12, 0.30, 0.82), 3: Color(0.78, 0.94, 1.0)})
	c.poly(PackedVector2Array([Vector2(7, 1), Vector2(12, 7), Vector2(7, 19), Vector2(2, 7)]), 1)
	c.poly(PackedVector2Array([Vector2(7, 1), Vector2(7, 19), Vector2(2, 7)]), 2)
	c.poly(PackedVector2Array([Vector2(8, 4), Vector2(10, 7), Vector2(8, 8)]), 3)
	var sp: Array = [Vector2i(4, 6), Vector2i(9, 12), Vector2i(6, 14)]
	c.put(sp[f].x, sp[f].y, 3)
	return c.to_texture()


static func _bolt() -> Texture2D:
	var c := PC.new(22, 16, {1: [Color(0.7, 0.18, 0.04), Color(1.0, 0.55, 0.12), Color(1.0, 0.9, 0.5)], 2: Color(1.0, 1.0, 0.9)})
	c.poly(PackedVector2Array([Vector2(2, 0), Vector2(10, 1), Vector2(17, 5), Vector2(21, 8), Vector2(17, 11), Vector2(10, 15), Vector2(2, 16), Vector2(9, 12), Vector2(13, 8), Vector2(9, 4)]), 1)
	c.line(Vector2(9, 3), Vector2(19, 8), 1.4, 2)
	return c.to_texture()


# --------------------------------------------------------------------------- враги

static func _bat(f: int) -> Texture2D:
	var c := PC.new(36, 26, {1: Color(0.40, 0.18, 0.55), 2: Color(0.22, 0.09, 0.34), 3: Color(1.0, 0.2, 0.2), 4: Color(0.95, 0.95, 0.88)})
	var dy: float = [-9.0, -3.0, 5.0, -3.0][f]
	var left: Array[Vector2] = [Vector2(14, 11), Vector2(8, 10.0 + dy * 0.6), Vector2(1, 12.0 + dy), Vector2(5, 16.0 + dy * 0.7),
			Vector2(7, 13.0 + dy * 0.4), Vector2(9, 18.0 + dy * 0.3), Vector2(13, 16)]
	var pl := PackedVector2Array()
	var pr := PackedVector2Array()
	for p in left:
		pl.append(p)
		pr.append(Vector2(36.0 - p.x, p.y))
	c.poly(pl, 2)
	c.poly(pr, 2)
	c.ellipse(Vector2(18, 14), 5.2, 6.0, 1)
	c.poly(PackedVector2Array([Vector2(13, 11), Vector2(14, 5), Vector2(17, 10)]), 1)
	c.poly(PackedVector2Array([Vector2(19, 10), Vector2(22, 5), Vector2(23, 11)]), 1)
	c.rect(15, 13, 2, 2, 3)
	c.rect(20, 13, 2, 2, 3)
	c.put(16, 19, 4)
	c.put(20, 19, 4)
	return c.to_texture()


static func _skull(f: int) -> Texture2D:
	var c := PC.new(28, 32, {1: Color(0.9, 0.87, 0.78), 2: Color(0.06, 0.0, 0.10), 3: Color(1.0, 0.45, 0.1), 4: Color(1.0, 0.85, 0.3)})
	var a: float = float(f % 2) * 2.0
	c.poly(PackedVector2Array([Vector2(8, 12), Vector2(8, 6.0 + a), Vector2(11, 10), Vector2(14, 2.0 + float(f)), Vector2(17, 10), Vector2(20, 6.0 + (2.0 - a)), Vector2(20, 12)]), 3)
	c.poly(PackedVector2Array([Vector2(11, 12), Vector2(14, 6), Vector2(17, 12)]), 4)
	c.ellipse(Vector2(14, 19), 9.0, 8.5, 1)
	c.rect(9, 24, 10, 5, 1)
	c.ellipse(Vector2(10.5, 19), 2.4, 3.0, 2)
	c.ellipse(Vector2(17.5, 19), 2.4, 3.0, 2)
	c.put(14, 22, 2)
	c.put(13, 22, 2)
	for x in [11, 14, 17]:
		c.put(x, 27, 2)
		c.put(x, 28, 2)
	return c.to_texture()


static func _worm(f: int) -> Texture2D:
	var c := PC.new(34, 20, {1: Color(0.95, 0.45, 0.1), 2: Color(0.55, 0.14, 0.05), 3: Color(1, 1, 1), 4: Color(0.05, 0.0, 0.05), 5: Color(0.9, 0.85, 0.7)})
	var t: float = float(f) * PI * 0.5
	for i in range(5, -1, -1):
		var x: float = 7.0 + float(i) * 5.0
		var y: float = 11.0 + sin(t - float(i) * 0.9) * 2.4
		var r: float = 5.6 if i == 0 else 4.7 - float(i) * 0.25
		c.disc(Vector2(x, y), r, 1)
		if i % 2 == 1:
			c.ellipse(Vector2(x + 1.0, y + 1.5), r * 0.55, r * 0.7, 2)
	var hy: float = 11.0 + sin(t) * 2.4
	c.rect(4, int(hy) - 4, 3, 3, 3)
	c.rect(8, int(hy) - 4, 3, 3, 3)
	c.put(4, int(hy) - 3, 4)
	c.put(8, int(hy) - 3, 4)
	c.poly(PackedVector2Array([Vector2(1, hy + 1), Vector2(5, hy + 1), Vector2(3, hy + 5)]), 5)
	return c.to_texture()


static func _golem(f: int) -> Texture2D:
	var c := PC.new(38, 38, {1: Color(0.50, 0.44, 0.48), 2: Color(0.30, 0.26, 0.30), 3: Color(1.0, 0.45, 0.1), 4: Color(0.78, 0.72, 0.76)})
	var s: int = f * 2
	c.rect(10, 27, 7, 10 - s, 2)
	c.rect(21, 27, 7, 8 + s, 2)
	c.poly(PackedVector2Array([Vector2(8, 10), Vector2(30, 10), Vector2(33, 28), Vector2(5, 28)]), 1)
	c.poly(PackedVector2Array([Vector2(13, 2), Vector2(25, 2), Vector2(27, 11), Vector2(11, 11)]), 4)
	c.rect(1, 12 + s, 6, 14, 1)
	c.rect(31, 12 + (2 - s), 6, 14, 1)
	c.rect(16, 16, 7, 7, 3)
	c.rect(15, 5, 3, 2, 3)
	c.rect(21, 5, 3, 2, 3)
	c.rect(11, 19, 2, 3, 2)
	c.rect(26, 19, 2, 3, 2)
	return c.to_texture()


static func _chest(f: int) -> Texture2D:
	var c := PC.new(38, 32, {1: Color(0.62, 0.34, 0.14), 2: Color(1.0, 0.76, 0.18), 3: Color(0.30, 0.14, 0.06), 4: Color(0.92, 0.92, 1.0), 5: Color(0.12, 0.05, 0.05), 6: Color(0.78, 0.46, 0.2)})
	var dy: float = [-7.0, -1.0, 5.0, -1.0][f]
	var wl: Array[Vector2] = [Vector2(11, 14), Vector2(5, 9.0 + dy * 0.5), Vector2(0, 8.0 + dy), Vector2(3, 15.0 + dy * 0.6), Vector2(11, 19)]
	var pl := PackedVector2Array()
	var pr := PackedVector2Array()
	for p in wl:
		pl.append(p)
		pr.append(Vector2(38.0 - p.x, p.y))
	c.poly(pl, 4)
	c.poly(pr, 4)
	c.rect(11, 12, 16, 16, 1)
	c.poly(PackedVector2Array([Vector2(11, 12), Vector2(27, 12), Vector2(25, 7), Vector2(13, 7)]), 6)
	c.rect(11, 17, 16, 2, 2)
	c.rect(17, 7, 4, 21, 2)
	c.rect(18, 18, 2, 4, 5)
	c.rect(11, 27, 16, 2, 3)
	return c.to_texture()


## Босс «Палач Бездны»: рогатый латник с огромным мечом, смотрит влево. 140x128, земля на y=124.
## Кадры: 0-1 стойка, 2-3 шаг, 4 замах, 5 удар, 6 призыв.
static func _boss(f: int, variant: int) -> Texture2D:
	var pal: Dictionary = {
		1: [Color(0.10, 0.11, 0.17), Color(0.28, 0.30, 0.42), Color(0.55, 0.58, 0.74)],
		2: [Color(0.16, 0.02, 0.07), Color(0.40, 0.06, 0.14), Color(0.66, 0.14, 0.22)],
		3: [Color(0.33, 0.19, 0.06), Color(0.72, 0.50, 0.20), Color(1.0, 0.84, 0.48)],
		4: [Color(0.30, 0.08, 0.62), Color(0.60, 0.26, 1.0), Color(0.86, 0.62, 1.0)],
		5: Color(0.78, 0.96, 1.0),
		6: [Color(0.20, 0.20, 0.27), Color(0.50, 0.52, 0.62), Color(0.84, 0.87, 0.94)],
		7: Color(1.0, 0.56, 0.14),
		8: Color(0.02, 0.0, 0.05),
		9: [Color(0.46, 0.40, 0.30), Color(0.85, 0.80, 0.66), Color(1.0, 0.98, 0.9)],
	}
	var c := PC.new(156, 128, pal)
	var bob: int = [0, 1, 0, 1, -2, 3, -1][f]
	var lf: Vector2 = Vector2(66, 124)
	var rf: Vector2 = Vector2(96, 124)
	if f == 2:
		lf = Vector2(58, 124)
		rf = Vector2(98, 118)
	elif f == 3:
		lf = Vector2(72, 118)
		rf = Vector2(92, 124)
	elif f == 4 or f == 6:
		lf = Vector2(60, 124)
		rf = Vector2(100, 124)
	elif f == 5:
		lf = Vector2(54, 124)
		rf = Vector2(102, 124)
	var by: int = bob
	# плащ
	var wv: float = [0.0, 2.0, 1.0, 3.0, -2.0, 5.0, 0.0][f]
	c.poly(PackedVector2Array([Vector2(98, 44 + by), Vector2(124, 64 + by + wv), Vector2(128, 104 + wv * 0.5), Vector2(112, 110), Vector2(104, 98), Vector2(96, 112), Vector2(88, 90)]), 2)
	# задняя рука
	c.line(Vector2(102, 50 + by), Vector2(108, 66 + by), 8.0, 1)
	c.line(Vector2(108, 66 + by), Vector2(104, 82 + by), 7.0, 1)
	c.disc(Vector2(104, 84 + by), 4.5, 3)
	# ноги
	var hip: Vector2 = Vector2(80, 76 + by)
	for pair in [[Vector2(72, 76 + by), lf], [Vector2(90, 76 + by), rf]]:
		var h0: Vector2 = pair[0]
		var ft: Vector2 = pair[1]
		var kn: Vector2 = (h0 + ft) * 0.5 + Vector2(-5, 0)
		c.line(h0, kn, 13.0, 1)
		c.line(kn, ft + Vector2(0, -6), 11.0, 1)
		c.disc(kn, 6.0, 3)
		c.ellipse(ft + Vector2(-4, -3), 12.0, 5.0, 1)
		c.rect(int(ft.x - 14), int(ft.y - 4), 10, 4, 3)
	# торс
	c.poly(PackedVector2Array([Vector2(58, 42 + by), Vector2(100, 42 + by), Vector2(95, 80 + by), Vector2(63, 80 + by)]), 1)
	c.poly(PackedVector2Array([Vector2(64, 44 + by), Vector2(94, 44 + by), Vector2(90, 62 + by), Vector2(68, 62 + by)]), 6)
	c.rect(62, 74 + by, 34, 6, 3)
	c.disc(Vector2(79, 54 + by), 3.4, 7)
	c.rect(76, 80 + by, 6, 12, 2)
	# наплечники с шипами
	c.ellipse(Vector2(55, 46 + by), 14.0, 10.0, 1)
	c.poly(PackedVector2Array([Vector2(42, 44 + by), Vector2(32, 30 + by), Vector2(52, 38 + by)]), 3)
	c.poly(PackedVector2Array([Vector2(48, 38 + by), Vector2(46, 25 + by), Vector2(58, 37 + by)]), 3)
	c.ellipse(Vector2(102, 46 + by), 12.0, 9.0, 1)
	c.poly(PackedVector2Array([Vector2(110, 42 + by), Vector2(122, 28 + by), Vector2(108, 48 + by)]), 3)
	# голова: шлем, прорезь, рога
	var hc: Vector2 = Vector2(78, 31 + by)
	c.line(Vector2(70, 26 + by), Vector2(56, 20 + by), 8.0, 9)
	c.line(Vector2(56, 20 + by), Vector2(48, 28 + by), 6.0, 9)
	c.line(Vector2(48, 28 + by), Vector2(47, 38 + by), 3.5, 9)
	c.line(Vector2(88, 26 + by), Vector2(100, 20 + by), 8.0, 9)
	c.line(Vector2(100, 20 + by), Vector2(108, 28 + by), 6.0, 9)
	c.line(Vector2(108, 28 + by), Vector2(109, 38 + by), 3.5, 9)
	c.ellipse(hc, 12.0, 13.0, 1)
	c.poly(PackedVector2Array([Vector2(74, 17 + by), Vector2(82, 12 + by), Vector2(86, 22 + by)]), 3)
	c.rect(64, 29 + by, 14, 4, 8)
	c.rect(65, 30 + by, 5, 2, 7)
	c.rect(72, 30 + by, 4, 2, 7)
	c.rect(66, 38 + by, 4, 5, 8)
	c.rect(72, 38 + by, 4, 5, 8)
	# пламя над головой
	var fh: float = 1.0 if f != 6 and f != 4 else 1.25
	for i in range(6):
		var x: float = 63.0 + float(i) * 5.5
		var h: float = minf((9.0 + 4.0 * sin(float(f) * 1.7 + float(i) * 1.3) + (3.0 if i % 2 == 0 else 0.0)) * fh, 15.0)
		var y0: float = 18.0 + float(by)
		c.poly(PackedVector2Array([Vector2(x - 1, y0 + 2), Vector2(x + 7, y0 + 2), Vector2(x + 3.0 + sin(float(f) + float(i)) * 2.0, y0 - h)]), 4)
		c.poly(PackedVector2Array([Vector2(x + 1, y0 + 2), Vector2(x + 5, y0 + 2), Vector2(x + 3, y0 - h * 0.55)]), 5)
	# рука с мечом
	var sh: Vector2 = Vector2(56, 50 + by)
	var hand: Vector2 = Vector2(48, 68 + by)
	var tip: Vector2 = Vector2(18, 122)
	if f == 4 or f == 6:
		hand = Vector2(54, 36 + by)
		tip = Vector2(106, 4)
	elif f == 5:
		hand = Vector2(42, 72 + by)
		tip = Vector2(4, 124)
	elif f == 2 or f == 3:
		hand = Vector2(46, 66 + by)
		tip = Vector2(14, 118)
	var el: Vector2 = (sh + hand) * 0.5 + Vector2(-2, 10)
	c.line(sh, el, 9.0, 1)
	c.line(el, hand, 8.0, 1)
	c.disc(el, 4.5, 3)
	var d: Vector2 = (tip - hand).normalized()
	var nrm: Vector2 = d.orthogonal()
	var len: float = hand.distance_to(tip)
	var b0: Vector2 = hand + d * 8.0
	c.poly(PackedVector2Array([b0 + nrm * 6.0, b0 + d * len * 0.55 + nrm * 7.0, tip, b0 + d * len * 0.55 - nrm * 7.0, b0 - nrm * 6.0]), 6)
	for i in range(3):
		var q: Vector2 = b0 + d * (14.0 + float(i) * 14.0) - nrm * 6.0
		c.poly(PackedVector2Array([q, q - nrm * 5.0 - d * 3.0, q + d * 6.0]), 6)
	c.line(b0 + d * 6.0, b0 + d * (len * 0.7), 1.6, 7)
	c.line(hand - nrm * 11.0, hand + nrm * 11.0, 4.0, 3)
	c.line(hand - d * 10.0, hand, 4.0, 2)
	c.disc(hand - d * 11.0, 3.0, 3)
	c.disc(hand, 5.0, 3)
	# левый наплечник поверх руки
	c.ellipse(Vector2(53, 48 + by), 10.0, 7.0, 1)
	return c.to_texture(true, BOSS_TINTS[variant % BOSS_TINTS.size()])


## Огненная волна от удара босса: бежит по земле.
static func _wave(f: int) -> Texture2D:
	var c := PC.new(28, 40, {1: [Color(0.6, 0.12, 0.05), Color(1.0, 0.45, 0.1), Color(1.0, 0.85, 0.4)], 2: Color(1.0, 0.95, 0.7)})
	for i in range(6):
		var x: float = 4.0 + float(i) * 4.0
		var h: float = 16.0 + 14.0 * absf(sin(float(f) * 1.3 + float(i) * 1.1))
		c.poly(PackedVector2Array([Vector2(x - 3, 40), Vector2(x + 3, 40), Vector2(x + 0.5, 40.0 - h)]), 1)
		c.poly(PackedVector2Array([Vector2(x - 1, 40), Vector2(x + 2, 40), Vector2(x + 0.5, 40.0 - h * 0.5)]), 2)
	return c.to_texture()


static func _portal(f: int) -> Texture2D:
	var c := PC.new(36, 52, {1: Color(0.55, 0.16, 0.82), 2: Color(0.07, 0.0, 0.16), 3: Color(0.95, 0.65, 1.0), 4: Color(0.72, 0.32, 0.96)})
	c.ellipse(Vector2(18, 26), 15.0, 24.0, 1)
	c.ellipse(Vector2(18, 26), 11.5, 20.5, 2)
	for k in range(10):
		var ang: float = float(f) * 0.55 + float(k) * 0.63
		var r: float = 0.22 + float(k) * 0.075
		var p := Vector2(18.0 + cos(ang) * r * 10.0, 26.0 + sin(ang) * r * 18.0)
		c.rect(int(p.x), int(p.y), 2, 2, 3 if k % 2 == 0 else 4)
	return c.to_texture()


# --------------------------------------------------------------------------- иконки 16×16

static func _build_icon(name: String) -> Texture2D:
	var c := PC.new(18, 18, {
		1: Color(0.78, 0.84, 0.94), 2: Color(1.0, 0.76, 0.18), 3: Color(0.55, 0.30, 0.12), 4: Color(0.30, 0.45, 0.85),
		5: Color(0.85, 0.15, 0.18), 6: Color(0.62, 0.25, 0.85), 7: Color(0.30, 0.78, 0.35), 8: Color(1.0, 0.5, 0.1),
		9: Color(0.92, 0.92, 0.88), 10: Color(0.45, 0.5, 0.58), 11: Color(1.0, 0.9, 0.35),
	})
	match name:
		"sword":
			c.line(Vector2(5, 12), Vector2(14, 3), 3.0, 1)
			c.line(Vector2(3, 10), Vector2(9, 16), 2.0, 2)
			c.line(Vector2(2, 15), Vector2(5, 12), 2.0, 3)
		"shield":
			c.poly(PackedVector2Array([Vector2(9, 1), Vector2(16, 3), Vector2(15, 11), Vector2(9, 17), Vector2(3, 11), Vector2(2, 3)]), 4)
			c.poly(PackedVector2Array([Vector2(9, 4), Vector2(12, 5), Vector2(11, 10), Vector2(9, 12), Vector2(7, 10), Vector2(6, 5)]), 2)
		"armor":
			c.poly(PackedVector2Array([Vector2(5, 2), Vector2(13, 2), Vector2(17, 5), Vector2(15, 9), Vector2(14, 16), Vector2(4, 16), Vector2(3, 9), Vector2(1, 5)]), 10)
			c.poly(PackedVector2Array([Vector2(7, 2), Vector2(11, 2), Vector2(9, 6)]), 3)
			c.rect(4, 11, 10, 2, 2)
		"helm":
			c.ellipse(Vector2(9, 9), 7.0, 7.0, 1)
			c.rect(2, 9, 14, 6, 1)
			c.rect(4, 9, 10, 2, 3)
			c.poly(PackedVector2Array([Vector2(9, 0), Vector2(14, 3), Vector2(9, 5)]), 5)
		"boots":
			c.poly(PackedVector2Array([Vector2(4, 2), Vector2(10, 2), Vector2(10, 10), Vector2(16, 12), Vector2(16, 16), Vector2(3, 16)]), 3)
			c.rect(3, 14, 13, 2, 10)
			c.rect(4, 4, 6, 2, 2)
		"bow":
			for i in range(15):
				var a: float = deg_to_rad(-72.0 + float(i) * 10.0)
				c.disc(Vector2(5.0 + cos(a) * 9.0, 9.0 + sin(a) * 8.5), 1.2, 3)
			c.line(Vector2(7, 1), Vector2(7, 17), 1.0, 9)
			c.line(Vector2(4, 9), Vector2(16, 9), 1.0, 1)
			c.poly(PackedVector2Array([Vector2(14, 7), Vector2(17, 9), Vector2(14, 11)]), 1)
		"ring":
			c.ellipse(Vector2(9, 10), 6.5, 6.5, 2)
			c.ellipse(Vector2(9, 10), 3.5, 3.5, 0)
			c.poly(PackedVector2Array([Vector2(9, 1), Vector2(12, 4), Vector2(9, 7), Vector2(6, 4)]), 6)
		"amulet":
			c.line(Vector2(3, 1), Vector2(9, 9), 1.5, 2)
			c.line(Vector2(15, 1), Vector2(9, 9), 1.5, 2)
			c.disc(Vector2(9, 12), 5.0, 2)
			c.disc(Vector2(9, 12), 2.6, 6)
		"magnet":
			c.ellipse(Vector2(9, 10), 7.0, 7.0, 5)
			c.ellipse(Vector2(9, 10), 3.0, 4.0, 0)
			c.rect(2, 1, 5, 4, 9)
			c.rect(11, 1, 5, 4, 9)
			c.rect(2, 5, 5, 4, 5)
			c.rect(11, 5, 5, 4, 5)
		"wing":
			c.poly(PackedVector2Array([Vector2(2, 14), Vector2(4, 4), Vector2(9, 6), Vector2(14, 2), Vector2(16, 9), Vector2(12, 12), Vector2(7, 16)]), 9)
			c.line(Vector2(5, 13), Vector2(13, 6), 1.0, 10)
		"flame":
			c.poly(PackedVector2Array([Vector2(9, 0), Vector2(13, 6), Vector2(15, 12), Vector2(9, 17), Vector2(3, 12), Vector2(5, 6), Vector2(7, 9)]), 8)
			c.poly(PackedVector2Array([Vector2(9, 8), Vector2(12, 12), Vector2(9, 16), Vector2(6, 12)]), 11)
		"clover":
			c.disc(Vector2(6, 6), 3.6, 7)
			c.disc(Vector2(12, 6), 3.6, 7)
			c.disc(Vector2(6, 11), 3.6, 7)
			c.disc(Vector2(12, 11), 3.6, 7)
			c.line(Vector2(9, 11), Vector2(12, 17), 1.5, 3)
		"star":
			var pts := PackedVector2Array()
			for i in range(10):
				var rr: float = 8.5 if i % 2 == 0 else 3.6
				var a2: float = -PI * 0.5 + float(i) * PI / 5.0
				pts.append(Vector2(9.0 + cos(a2) * rr, 9.5 + sin(a2) * rr))
			c.poly(pts, 11)
		"potion":
			c.ellipse(Vector2(9, 11), 6.0, 6.0, 6)
			c.rect(7, 2, 4, 5, 9)
			c.rect(7, 0, 4, 2, 3)
		"scroll":
			c.rect(4, 3, 10, 12, 9)
			c.ellipse(Vector2(9, 3), 6.0, 2.0, 2)
			c.ellipse(Vector2(9, 15), 6.0, 2.0, 2)
			for y in [6, 9, 12]:
				c.rect(6, y, 6, 1, 3)
		"trophy":
			c.poly(PackedVector2Array([Vector2(4, 2), Vector2(14, 2), Vector2(13, 9), Vector2(9, 12), Vector2(5, 9)]), 2)
			c.rect(8, 11, 2, 3, 2)
			c.rect(5, 14, 8, 3, 2)
		"gear":
			c.disc(Vector2(9, 9), 6.0, 10)
			for i in range(8):
				var a3: float = float(i) * PI / 4.0
				c.disc(Vector2(9.0 + cos(a3) * 7.5, 9.0 + sin(a3) * 7.5), 1.6, 10)
			c.disc(Vector2(9, 9), 2.6, 0)
		"close":
			c.line(Vector2(3, 3), Vector2(15, 15), 3.0, 9)
			c.line(Vector2(15, 3), Vector2(3, 15), 3.0, 9)
		"up":
			c.poly(PackedVector2Array([Vector2(9, 1), Vector2(16, 9), Vector2(11, 9), Vector2(11, 16), Vector2(7, 16), Vector2(7, 9), Vector2(2, 9)]), 7)
		"dots":
			for y in [3, 9, 15]:
				c.disc(Vector2(9, y), 2.0, 2)
		"bag":
			c.ellipse(Vector2(9, 11), 7.0, 6.0, 2)
			c.poly(PackedVector2Array([Vector2(6, 1), Vector2(12, 1), Vector2(11, 6), Vector2(7, 6)]), 2)
			c.rect(6, 5, 6, 2, 3)
		"tree":
			c.line(Vector2(9, 17), Vector2(9, 7), 2.0, 3)
			c.disc(Vector2(9, 6), 5.0, 7)
			c.disc(Vector2(5, 9), 3.5, 7)
			c.disc(Vector2(13, 9), 3.5, 7)
		"skull":
			c.ellipse(Vector2(9, 8), 6.5, 6.0, 9)
			c.rect(6, 12, 6, 4, 9)
			c.ellipse(Vector2(6.5, 8), 1.8, 2.2, 0)
			c.ellipse(Vector2(11.5, 8), 1.8, 2.2, 0)
		"bolt":
			c.poly(PackedVector2Array([Vector2(10, 0), Vector2(3, 10), Vector2(8, 10), Vector2(6, 17), Vector2(15, 6), Vector2(10, 6)]), 11)
		"clock":
			c.disc(Vector2(9, 9), 7.0, 9)
			c.disc(Vector2(9, 9), 5.0, 4)
			c.line(Vector2(9, 9), Vector2(9, 5), 1.0, 9)
			c.line(Vector2(9, 9), Vector2(12, 10), 1.0, 9)
		"check":
			c.line(Vector2(3, 9), Vector2(7, 14), 3.0, 7)
			c.line(Vector2(7, 14), Vector2(15, 3), 3.0, 7)
		"lock":
			c.rect(4, 8, 10, 8, 10)
			c.ellipse(Vector2(9, 8), 4.0, 5.0, 10)
			c.ellipse(Vector2(9, 8), 2.0, 3.0, 0)
			c.rect(8, 11, 2, 3, 5)
		_:
			c.disc(Vector2(9, 9), 6.0, 10)
	return c.to_texture()


# --------------------------------------------------------------------------- питомцы

## variant = вид * 10 + качество. Цвет тела берётся из цвета качества.
static func _pet(f: int, variant: int) -> Texture2D:
	var species: int = variant / 10
	var rar: int = variant % 10
	var base: Color = PetData.color_of(rar)
	var body: Array = [base.darkened(0.55), base.darkened(0.15), base.lightened(0.35)]
	var wing: Array = [base.darkened(0.7), base.darkened(0.42), base.darkened(0.1)]
	var pal: Dictionary = {1: body, 2: wing, 3: Color(1.0, 0.95, 0.5), 4: Color(0.96, 0.93, 0.82), 5: Color(0.08, 0.02, 0.1), 6: base.lightened(0.55)}
	var flap: float = [-8.0, -2.0, 6.0, -2.0][f]
	if species == 1:
		var c := PC.new(26, 28, pal)
		var bob: float = [0.0, -1.0, 0.0, 1.0][f]
		for i in range(3):
			var tx: float = 7.0 + float(i) * 6.0
			c.poly(PackedVector2Array([Vector2(tx, 15), Vector2(tx + 2, 15), Vector2(tx + 3.0 + sin(float(f) * 1.6 + float(i)) * 2.5, 25), Vector2(tx + 1.0 + sin(float(f) * 1.6 + float(i)) * 2.5, 25)]), 2)
		c.ellipse(Vector2(13, 12.0 + bob), 10.0, 9.5, 1)
		c.ellipse(Vector2(15, 12.0 + bob), 6.0, 6.0, 4)
		c.disc(Vector2(16, 12.0 + bob), 3.2, 3)
		c.disc(Vector2(16.5, 12.0 + bob), 1.5, 5)
		c.put(14, 9 + int(bob), 6)
		c.poly(PackedVector2Array([Vector2(5, 6), Vector2(3, 1), Vector2(8, 4)]), 1)
		c.poly(PackedVector2Array([Vector2(19, 4), Vector2(22, 0), Vector2(23, 6)]), 1)
		return c.to_texture()
	if species == 2:
		var c2 := PC.new(36, 24, pal)
		var st: float = [0.0, 3.0, 0.0, -3.0][f]
		c2.poly(PackedVector2Array([Vector2(7, 14), Vector2(2, 9.0 + st * 0.4), Vector2(0, 14), Vector2(4, 19), Vector2(9, 18)]), 1)
		c2.ellipse(Vector2(17, 14), 10.0, 5.5, 1)
		c2.ellipse(Vector2(17, 17), 7.0, 2.5, 6)
		c2.line(Vector2(12, 18), Vector2(11.0 - st * 0.6, 23), 3.0, 1)
		c2.line(Vector2(22, 18), Vector2(23.0 + st * 0.6, 23), 3.0, 1)
		c2.ellipse(Vector2(28, 10), 5.0, 4.2, 1)
		c2.poly(PackedVector2Array([Vector2(31, 9), Vector2(36, 11), Vector2(31, 13)]), 6)
		c2.poly(PackedVector2Array([Vector2(24, 7), Vector2(25, 1), Vector2(28, 6)]), 1)
		c2.poly(PackedVector2Array([Vector2(28, 6), Vector2(31, 1), Vector2(31, 7)]), 1)
		c2.rect(29, 9, 2, 2, 3)
		return c2.to_texture()
	var c3 := PC.new(40, 34, pal)
	# крыло
	var wl: Array[Vector2] = [Vector2(19, 15), Vector2(13, 12.0 + flap * 0.6), Vector2(6, 8.0 + flap), Vector2(9, 15.0 + flap * 0.8), Vector2(11, 19.0 + flap * 0.4), Vector2(15, 20)]
	c3.poly(PackedVector2Array(wl), 2)
	c3.line(Vector2(18, 15), Vector2(7, 9.0 + flap), 1.2, 1)
	# хвост
	c3.poly(PackedVector2Array([Vector2(13, 22), Vector2(6, 25), Vector2(2, 31), Vector2(5, 30), Vector2(9, 27), Vector2(15, 26)]), 1)
	c3.poly(PackedVector2Array([Vector2(1, 30), Vector2(0, 33), Vector2(4, 31)]), 6)
	# тело, шея, голова
	c3.ellipse(Vector2(19, 21), 9.5, 6.2, 1)
	c3.ellipse(Vector2(19, 24), 6.5, 3.0, 6)
	c3.poly(PackedVector2Array([Vector2(22, 17), Vector2(28, 10), Vector2(31, 13), Vector2(26, 21)]), 1)
	c3.ellipse(Vector2(30, 11), 5.0, 4.2, 1)
	c3.poly(PackedVector2Array([Vector2(33, 9), Vector2(39, 12), Vector2(33, 15)]), 1)
	c3.poly(PackedVector2Array([Vector2(27, 8), Vector2(24, 2), Vector2(30, 7)]), 4)
	c3.poly(PackedVector2Array([Vector2(30, 7), Vector2(29, 1), Vector2(33, 7)]), 4)
	c3.rect(31, 9, 2, 2, 3)
	c3.put(37, 13, 4)
	c3.put(35, 14, 4)
	# гребень и лапы
	for i in range(4):
		c3.poly(PackedVector2Array([Vector2(12.0 + float(i) * 3.5, 17), Vector2(13.5 + float(i) * 3.5, 13), Vector2(15.0 + float(i) * 3.5, 17)]), 6)
	c3.line(Vector2(15, 25), Vector2(14, 30), 3.0, 1)
	c3.line(Vector2(23, 25), Vector2(25, 30), 3.0, 1)
	# крыло спереди
	c3.poly(PackedVector2Array([Vector2(21, 15), Vector2(25, 9.0 + flap * 0.7), Vector2(18, 7.0 + flap), Vector2(17, 15)]), 2)
	return c3.to_texture()
