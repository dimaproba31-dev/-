extends CanvasLayer
## Отладочная подпись. F3 — показать/скрыть. По умолчанию скрыта (интерфейсов в этапе 1 нет).

@onready var label: Label = $Label


func _ready() -> void:
	label.visible = false


func _unhandled_key_input(event: InputEvent) -> void:
	var k := event as InputEventKey
	if k != null and k.pressed and not k.echo and k.keycode == KEY_F3:
		label.visible = not label.visible


func _process(_delta: float) -> void:
	if not label.visible:
		return
	var zone_name: String = String(Game.ZoneData.zones()[Game.zone_index]["name"])
	label.text = "FPS %d\nДистанция %d\nСкорость %d\nЗона: %s\nОкно %s" % [
			Engine.get_frames_per_second(), int(Game.distance), int(Game.speed), zone_name,
			str(get_viewport().get_visible_rect().size)]
