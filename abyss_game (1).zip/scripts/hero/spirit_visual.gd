extends "res://scripts/hero/hero_visual.gd"
## Дух косы: парящий призрак без ног в рваном одеянии, белая маска Они с рогами, большая коса.
## Строится на том же растеризаторе, что и основной герой (холст, 3 тона, обводка, ткань, шлейфы),
## но анимации покадровые: поза берётся из таблицы ключевых кадров и меняется ступенчато,
## как в настоящем спрайтовом листе. Число кадров: idle 6, fly 8, attack 8, heavy 10, hit 4, skill 10, death 8.
## Размер холста и точка центра (OX, OY) одинаковы во всех кадрах; коса имеет постоянные размеры.

const N_IDLE: int = 6
const N_FLY: int = 8
const N_ATTACK: int = 8
const N_HEAVY: int = 10
const N_HIT: int = 4
const N_SKILL: int = 10
const N_DEATH: int = 8

const HIT_DUR: float = 0.32
const DEATH_DUR: float = 1.4

## Геометрия косы (единицы тела) — постоянная во всех кадрах.
const SC_BACK: float = 26.0     ## древко позади руки
const SC_HEAD: float = 34.0     ## от руки до головки
const SC_BLADE: float = 40.0    ## вынос лезвия
const SC_CURL: float = 14.0     ## загиб острия к хозяину
const SC_WIDTH: float = 11.0

var dead: bool = false
var _hit_t: float = -1.0
var _death_t: float = -1.0
var _tail_ph: float = 0.0
var _fly_k: float = 0.0
var _frame_name: String = "idle"
var _frame_idx: int = 0
var _pv_anim: String = ""
var _pv_i: int = 0
var _charge: float = 0.0
var _burst: float = 0.0
var _hitfx: float = 0.0
var _dissolve: float = 0.0


func _ready() -> void:
	super._ready()
	_pal[M_COAT] = [Color(0.015, 0.008, 0.035), Color(0.055, 0.025, 0.105), Color(0.20, 0.10, 0.36)]
	_pal[M_CLOAK] = [Color(0.06, 0.02, 0.13), Color(0.19, 0.07, 0.36), Color(0.48, 0.24, 0.80)]
	_pal[M_ARMOR_D] = [Color(0.0, 0.0, 0.02), Color(0.03, 0.015, 0.07), Color(0.12, 0.06, 0.22)]
	_pal[M_ARMOR_L] = [Color(0.14, 0.07, 0.28), Color(0.40, 0.22, 0.68), Color(0.80, 0.62, 1.0)]
	_pal[M_HOOD] = [Color(0.03, 0.015, 0.07), Color(0.10, 0.05, 0.19), Color(0.30, 0.16, 0.52)]
	_pal[M_SKIN] = [Color(0.45, 0.38, 0.58), Color(0.78, 0.74, 0.88), Color(0.97, 0.96, 1.0)]
	_pal[M_MASK] = [Color(0.0, 0.0, 0.01), Color(0.015, 0.0, 0.03), Color(0.06, 0.03, 0.12)]
	_pal[M_STEEL] = [Color(0.07, 0.03, 0.14), Color(0.22, 0.10, 0.40), Color(0.80, 0.58, 1.0)]
	_pal[M_GOLD] = [Color(0.26, 0.23, 0.36), Color(0.62, 0.60, 0.76), Color(0.92, 0.90, 1.0)]
	_pal[M_SCARF] = [Color(0.30, 0.0, 0.07), Color(0.70, 0.05, 0.17), Color(1.0, 0.32, 0.38)]
	_pal[M_LEATHER] = [Color(0.04, 0.02, 0.08), Color(0.13, 0.07, 0.22), Color(0.34, 0.20, 0.52)]
	_pal[M_BONE] = [Color(0.40, 0.34, 0.52), Color(0.78, 0.74, 0.88), Color(0.97, 0.96, 1.0)]
	_pal_rage = _pal.duplicate()
	_pal_rage[M_CLOAK] = [Color(0.20, 0.02, 0.10), Color(0.52, 0.08, 0.26), Color(0.95, 0.30, 0.52)]
	_pal_rage[M_STEEL] = [Color(0.25, 0.05, 0.16), Color(0.72, 0.18, 0.42), Color(1.0, 0.82, 0.92)]
	_pal_rage[M_ARMOR_L] = [Color(0.30, 0.06, 0.20), Color(0.70, 0.20, 0.46), Color(1.0, 0.75, 0.88)]
	_render_all(_pose_loco())


func _flat_color(id: int) -> Color:
	match id:
		M_WHITE:
			return Color(0.97, 0.95, 1.0)
		M_IRIS:
			return Color(1.0, 0.85, 0.9) if rage else Color(1.0, 0.18, 0.30)
		M_LIP:
			return Color(0.88, 0.08, 0.16)
		M_FULLER:
			return Color(0.55, 0.35, 0.92)
		M_RUNE:
			return Color(1.0, 0.82, 0.95) if rage else Color(0.78, 0.48, 1.0)
	return Color(0.05, 0.02, 0.08)


# ====================================================================== управление

func hit() -> void:
	if dead or _atk_kind >= 0:
		return
	_hit_t = 0.0


func die() -> void:
	if dead:
		return
	dead = true
	_death_t = 0.0
	_atk_kind = -1


func revive() -> void:
	dead = false
	_death_t = -1.0
	_hit_t = -1.0
	_dissolve = 0.0


func start_attack(kind: int, speed: float = 1.0) -> void:
	if dead:
		return
	_hit_t = -1.0
	super.start_attack(kind, speed)
	_atk_dur = (0.52 if kind == 2 else (0.5 if kind == 3 else 0.36)) / speed


func advance(delta: float, world_speed: float) -> void:
	if _hit_t >= 0.0:
		_hit_t += delta
		if _hit_t >= HIT_DUR:
			_hit_t = -1.0
	if _death_t >= 0.0:
		_death_t = minf(_death_t + delta, DEATH_DUR + 0.5)
	super.advance(delta, world_speed)


## Момент попадания совпадает с кадром-ударом: индекс кадра / число кадров.
func _strike_frac() -> float:
	match _atk_kind:
		0, 1: return 4.0 / float(N_ATTACK)
		2: return 5.0 / float(N_HEAVY)
		3: return 6.0 / float(N_SKILL)
	return 0.5


# ====================================================================== позы по кадрам

func _fr(u: float, n: int) -> int:
	return clampi(int(floor(clampf(u, 0.0, 0.9999) * float(n))), 0, n - 1)


static func _SP(hx: float, hy: float, lean: float, hf: Vector2, hb: Vector2, sw: float, head: float = 0.0) -> Dictionary:
	return _P({"hx": hx, "hy": hy, "lean": lean, "hf": hf, "hb": hb, "sw": sw, "head": head})


func _idle_pose(i: int) -> Dictionary:
	var a: float = TAU * float(i) / float(N_IDLE)
	var b: float = sin(a)
	_tail_ph = a
	return _SP(0.0, -52.0 + 1.8 * b, 0.12 + 0.015 * b, Vector2(12.0, 5.0 + 0.8 * b), Vector2(13.0, 12.0 + 1.6 * sin(a + 1.2)), 2.78 + 0.03 * b, -0.05 + 0.03 * b)


func _fly_pose(i: int) -> Dictionary:
	var a: float = TAU * float(i) / float(N_FLY)
	var b: float = sin(a)
	_tail_ph = a * 2.0
	return _SP(0.0, -50.0 + 2.6 * b, 0.50 + 0.03 * b, Vector2(14.0, 3.0 + 1.2 * cos(a)), Vector2(-3.0 + 2.0 * sin(a + 0.8), 10.0 + 2.0 * cos(a + 0.8)), 2.35 + 0.04 * b, -0.25)


func _pose_loco() -> Dictionary:
	var idle: Dictionary = _idle_pose(_fr(fposmod(_t / 1.2, 1.0), N_IDLE))
	var idle_ph: float = _tail_ph
	var fly: Dictionary = _fly_pose(_fr(fposmod(_t / (0.64 - 0.14 * _spk), 1.0), N_FLY))
	var fly_ph: float = _tail_ph
	var sk: float = clampf(_stand_k, 0.0, 1.0)
	_tail_ph = lerpf(fly_ph, idle_ph, sk)
	_fly_k = 1.0 - sk
	var p: Dictionary = _mix(fly, idle, sk)
	if not on_ground:
		p["lean"] = clampf(0.46 - vy / 3200.0, 0.1, 0.8)
		p["hy"] = float(p["hy"]) - 2.0
		_fly_k = 1.0
		if _flip_t >= 0.0:
			var pr: float = clampf(_flip_t / 0.46, 0.0, 1.0)
			p["rot"] = (pr * pr * (3.0 - 2.0 * pr)) * TAU
	return p


func _attack_table(kind: int) -> Array:
	var rd: Dictionary = _SP(0.0, -50.0, 0.34, Vector2(13.0, 4.0), Vector2(8.0, 12.0), 2.4, -0.1)
	match kind:
		0:   # горизонтальный: замах за плечо, удар на кадре 4, проводка
			return [rd,
				_SP(-3.0, -51.0, 0.12, Vector2(-8.0, -12.0), Vector2(14.0, 0.0), 3.7, 0.0),
				_SP(-6.0, -52.0, 0.0, Vector2(-10.0, -14.0), Vector2(16.0, -2.0), 4.3, 0.05),
				_SP(-2.0, -51.0, 0.25, Vector2(6.0, -12.0), Vector2(12.0, 2.0), 3.2, 0.0),
				_SP(6.0, -48.0, 0.60, Vector2(18.0, 6.0), Vector2(-6.0, 10.0), 1.65, -0.2),
				_SP(9.0, -47.0, 0.65, Vector2(19.0, 10.0), Vector2(-8.0, 10.0), 1.2, -0.2),
				_SP(5.0, -49.0, 0.45, Vector2(16.0, 8.0), Vector2(-2.0, 10.0), 1.5, -0.15),
				_SP(2.0, -50.0, 0.32, Vector2(14.0, 5.0), Vector2(6.0, 12.0), 2.2, -0.1)]
		1:   # восходящий: подсечка снизу вверх, удар на кадре 4
			return [rd,
				_SP(-4.0, -46.0, 0.50, Vector2(-4.0, 16.0), Vector2(10.0, 8.0), 0.2, -0.1),
				_SP(-6.0, -45.0, 0.55, Vector2(-8.0, 18.0), Vector2(12.0, 8.0), -0.3, -0.1),
				_SP(0.0, -48.0, 0.35, Vector2(8.0, 6.0), Vector2(6.0, 10.0), 0.9, -0.1),
				_SP(6.0, -52.0, 0.20, Vector2(17.0, -4.0), Vector2(-5.0, 10.0), 2.0, -0.1),
				_SP(9.0, -55.0, 0.0, Vector2(14.0, -14.0), Vector2(-8.0, 8.0), 3.0, 0.0),
				_SP(7.0, -53.0, 0.1, Vector2(12.0, -8.0), Vector2(-2.0, 10.0), 2.9, 0.0),
				_SP(3.0, -51.0, 0.25, Vector2(13.0, 3.0), Vector2(6.0, 12.0), 2.5, -0.1)]
	match kind:
		2:   # тяжёлый: разворот, дуга энергии, удар на кадре 5
			return [rd,
				_SP(-3.0, -52.0, 0.20, Vector2(-6.0, -14.0), Vector2(14.0, -2.0), 3.8, 0.0),
				_SP(-6.0, -54.0, -0.05, Vector2(-10.0, -18.0), Vector2(16.0, -4.0), 4.5, 0.05),
				_SP(-6.0, -55.0, 0.0, Vector2(-8.0, -16.0), Vector2(14.0, -2.0), 5.2, 0.05),
				_SP(0.0, -52.0, 0.30, Vector2(4.0, -6.0), Vector2(8.0, 6.0), 6.0, 0.0),
				_SP(8.0, -48.0, 0.65, Vector2(19.0, 8.0), Vector2(-8.0, 10.0), 1.62, -0.25),
				_SP(10.0, -47.0, 0.70, Vector2(20.0, 12.0), Vector2(-10.0, 10.0), 1.1, -0.25),
				_SP(9.0, -48.0, 0.62, Vector2(18.0, 10.0), Vector2(-6.0, 10.0), 1.3, -0.2),
				_SP(5.0, -49.0, 0.45, Vector2(16.0, 7.0), Vector2(0.0, 11.0), 1.8, -0.15),
				_SP(2.0, -50.0, 0.34, Vector2(14.0, 5.0), Vector2(6.0, 12.0), 2.3, -0.1)]
	# 3: навык — поднять косу, зарядить, ударить в землю, взрыв кристаллов на кадре 6
	return [rd,
		_SP(-4.0, -52.0, 0.10, Vector2(2.0, -6.0), Vector2(12.0, 0.0), 3.0, 0.0),
		_SP(-4.0, -56.0, -0.10, Vector2(-2.0, -16.0), Vector2(14.0, -6.0), 3.6, 0.0),
		_SP(-4.0, -60.0, -0.20, Vector2(0.0, -20.0), Vector2(14.0, -10.0), 3.14, 0.05),
		_SP(-4.0, -61.0, -0.20, Vector2(0.0, -21.0), Vector2(15.0, -11.0), 3.14, 0.05),
		_SP(6.0, -54.0, 0.35, Vector2(10.0, -8.0), Vector2(6.0, 2.0), 2.4, -0.1),
		_SP(12.0, -46.0, 0.75, Vector2(19.0, 10.0), Vector2(-8.0, 10.0), 1.45, -0.3),
		_SP(12.0, -46.0, 0.80, Vector2(20.0, 12.0), Vector2(-9.0, 10.0), 1.1, -0.3),
		_SP(8.0, -48.0, 0.55, Vector2(17.0, 8.0), Vector2(-2.0, 10.0), 1.6, -0.2),
		_SP(3.0, -50.0, 0.36, Vector2(14.0, 5.0), Vector2(6.0, 12.0), 2.3, -0.1)]


func _attack_frames(kind: int) -> int:
	match kind:
		0, 1: return N_ATTACK
		2: return N_HEAVY
	return N_SKILL


func _hit_pose(i: int) -> Dictionary:
	_hitfx = 1.0 if i == 2 else 0.0
	match i:
		0: return _SP(-3.0, -51.0, 0.0, Vector2(8.0, 6.0), Vector2(10.0, 10.0), 2.8, 0.3)
		1: return _SP(-6.0, -50.0, -0.22, Vector2(6.0, 8.0), Vector2(8.0, 12.0), 2.9, 0.4)
		2: return _SP(-5.0, -50.0, -0.15, Vector2(7.0, 8.0), Vector2(9.0, 12.0), 2.8, 0.35)
	return _SP(-2.0, -51.0, 0.08, Vector2(10.0, 6.0), Vector2(11.0, 11.0), 2.7, 0.1)


func _death_pose(i: int) -> Dictionary:
	_dissolve = [0.0, 0.0, 0.0, 0.05, 0.22, 0.50, 0.80, 1.0][i]
	var rows: Array = [
		_SP(-2.0, -51.0, -0.10, Vector2(8.0, 6.0), Vector2(10.0, 10.0), 2.7, 0.2),
		_SP(-4.0, -49.0, -0.30, Vector2(6.0, 12.0), Vector2(8.0, 14.0), 2.2, 0.35),
		_SP(-5.0, -46.0, -0.50, Vector2(4.0, 16.0), Vector2(6.0, 16.0), 1.4, 0.5),
		_SP(-6.0, -42.0, -0.62, Vector2(2.0, 18.0), Vector2(4.0, 18.0), 0.7, 0.6),
		_SP(-6.0, -38.0, -0.70, Vector2(0.0, 20.0), Vector2(2.0, 20.0), 0.3, 0.7),
		_SP(-6.0, -34.0, -0.75, Vector2(-2.0, 20.0), Vector2(0.0, 20.0), 0.2, 0.7),
		_SP(-6.0, -30.0, -0.78, Vector2(-2.0, 20.0), Vector2(0.0, 20.0), 0.2, 0.7),
		_SP(-6.0, -28.0, -0.80, Vector2(-2.0, 20.0), Vector2(0.0, 20.0), 0.2, 0.7)]
	return rows[i]


func _pose_full() -> Dictionary:
	_charge = 0.0
	_burst = 0.0
	_hitfx = 0.0
	if _pv_anim != "":
		return _preview_pose()
	if dead or _death_t >= 0.0:
		var di: int = _fr(clampf(_death_t, 0.0, DEATH_DUR) / DEATH_DUR, N_DEATH)
		_frame_name = "death"
		_frame_idx = di
		_tail_ph = TAU * float(di) / float(N_DEATH)
		_fly_k = 0.3
		return _death_pose(di)
	var loco: Dictionary = _pose_loco()
	var p: Dictionary = loco
	_dissolve = 0.0
	if _hit_t >= 0.0:
		var hi: int = _fr(_hit_t / HIT_DUR, N_HIT)
		_frame_name = "hit"
		_frame_idx = hi
		return _mix(loco, _hit_pose(hi), 0.9)
	_frame_name = "fly" if _fly_k > 0.5 else "idle"
	if _atk_kind >= 0:
		var f: float = clampf(_atk_t / _atk_dur, 0.0, 1.0)
		var n: int = _attack_frames(_atk_kind)
		var fi: int = _fr(f, n)
		var a: Dictionary = (_attack_table(_atk_kind) as Array)[fi]
		_frame_name = ["attack", "attack", "heavy", "skill"][clampi(_atk_kind, 0, 3)]
		_frame_idx = fi
		var wb: float = clampf(f / 0.10, 0.0, 1.0) * clampf((1.0 - f) / 0.16, 0.0, 1.0)
		wb = wb * wb * (3.0 - 2.0 * wb)
		a = a.duplicate()
		a["sw"] = float(loco["sw"]) + wrapf(float(a["sw"]) - float(loco["sw"]), -PI, PI)
		p = _mix(loco, a, wb)
		_tail_ph += 0.0
		if _atk_kind == 3:
			_charge = 1.0 if (fi >= 2 and fi <= 4) else 0.0
			_burst = float(fi - 5) / 4.0 if fi >= 6 else 0.0
		elif _atk_kind == 2:
			_charge = 0.6 if fi >= 3 and fi <= 6 else 0.0
	if _cast_t > 0.0:
		var cw: float = clampf(_cast_t / 0.3, 0.0, 1.0)
		cw = minf(1.0, (1.0 - cw) * 6.0) if cw > 0.8 else cw / 0.8
		p["hb"] = (p["hb"] as Vector2).lerp(Vector2(25, -3), cw)
	return p


## Предпросмотр: зафиксировать кадр анимации (для листа спрайтов и проверки).
func preview(anim: String, i: int) -> void:
	_pv_anim = anim
	_pv_i = i
	_render_all(_pose_full())


func preview_end() -> void:
	_pv_anim = ""


func _preview_pose() -> Dictionary:
	_frame_name = _pv_anim
	_frame_idx = _pv_i
	_dissolve = 0.0
	_fly_k = 0.0
	match _pv_anim:
		"idle":
			return _idle_pose(_pv_i)
		"fly":
			_fly_k = 1.0
			return _fly_pose(_pv_i)
		"attack":
			_atk_kind = 0
			return (_attack_table(0) as Array)[_pv_i]
		"heavy":
			_atk_kind = 2
			_charge = 0.6 if _pv_i >= 3 and _pv_i <= 6 else 0.0
			return (_attack_table(2) as Array)[_pv_i]
		"skill":
			_atk_kind = 3
			_charge = 1.0 if _pv_i >= 2 and _pv_i <= 4 else 0.0
			_burst = float(_pv_i - 5) / 4.0 if _pv_i >= 6 else 0.0
			return (_attack_table(3) as Array)[_pv_i]
		"hit":
			return _hit_pose(_pv_i)
		"death":
			return _death_pose(_pv_i)
	return _idle_pose(0)


# ====================================================================== скелет и коса

func _scythe_pts(sk: Dictionary) -> Dictionary:
	var hand: Vector2 = sk["hand_f"]
	var hd: Vector2 = _dir(float(sk["sw"]))
	var pr: Vector2 = _rot(hd, PI * 0.5)
	var head_u: Vector2 = hand + hd * SC_HEAD
	var tip_u: Vector2 = head_u + pr * SC_BLADE - hd * (SC_CURL - 4.0)
	return {"hd": hd, "pr": pr, "head": head_u, "tip": tip_u, "back": hand - hd * SC_BACK}


func _skeleton(p: Dictionary) -> Dictionary:
	var sk: Dictionary = super._skeleton(p)
	var sc: Dictionary = _scythe_pts(sk)
	sk["blade_b"] = _to_canvas(sc["head"], sk)
	sk["blade_t"] = _to_canvas(sc["tip"], sk)
	return sk


func _blade_curve(sc: Dictionary, t: float) -> Vector2:
	var hd: Vector2 = sc["hd"]
	var pr: Vector2 = sc["pr"]
	return (sc["head"] as Vector2) + pr * (SC_BLADE * t) + hd * (4.0 * t - SC_CURL * t * t)


# ====================================================================== отрисовка тела

func _wisp(a: Vector2, b: Vector2, mid: Vector2, tip: Vector2, id: int) -> void:
	_poly(PackedVector2Array([a, mid.lerp(a, 0.5) + (mid - a).orthogonal().normalized() * 1.0, tip, b]), id)


func _render_all(p: Dictionary) -> void:
	_ids.fill(0)
	_bx0 = W
	_bx1 = 0
	_by0 = H
	_by1 = 0
	var sk: Dictionary = _skeleton(p)
	_last_sk = sk
	var lean: float = sk["lean"]
	var hip: Vector2 = sk["hip"]
	var chest: Vector2 = sk["chest"]
	var head: Vector2 = sk["head"]
	var fw: Vector2 = Vector2(cos(lean), sin(lean))   # «вперёд» поперёк корпуса
	var up_n: Vector2 = Vector2(sin(lean), -cos(lean))
	var ph: float = _tail_ph
	var dying: bool = _dissolve > 0.0

	# --- плащ: длинный, рваный, развевается назад
	var cape := PackedVector2Array()
	for i in range(_cape_a.size()):
		cape.append((_cape_a[i] as Dictionary)["p"])
	for i in range(_cape_b.size() - 1, -1, -1):
		var jag: float = (3.0 if i % 2 == 0 else 0.0) * S
		cape.append((_cape_b[i] as Dictionary)["p"] + Vector2(0, (7.0 + float(i) * 2.4) * S + jag))
	_poly(cape, M_CLOAK)
	var cape_in := PackedVector2Array()
	for i in range(_cape_a.size()):
		cape_in.append(((_cape_a[i] as Dictionary)["p"] as Vector2).lerp((_cape_b[i] as Dictionary)["p"], 0.35) + Vector2(0, 1.0))
	for i in range(_cape_b.size() - 1, -1, -1):
		cape_in.append(((_cape_b[i] as Dictionary)["p"] as Vector2) + Vector2(0, (2.5 + float(i) * 1.3) * S))
	_poly(cape_in, M_COAT)

	# --- хвост-подол: колокол и три языка дыма вместо ног
	var back_k: float = 6.0 + 9.0 * _fly_k + 8.0 * lean
	var hem: Vector2 = hip + Vector2(-back_k * 0.6, 27.0)
	var wa: Vector2 = _cv(hip + fw * 9.0, sk)
	var wb2: Vector2 = _cv(hip - fw * 10.0, sk)
	_poly(PackedVector2Array([wa, wb2, _cv(hem - fw * 15.0, sk), _cv(hem + fw * 13.0, sk)]), M_COAT)
	for i in range(3):
		var off: float = (float(i) - 1.0) * 9.0
		var sway: float = 3.0 * sin(ph + float(i) * 2.1)
		var base_a: Vector2 = _cv(hem + fw * (off - 5.0), sk)
		var base_b: Vector2 = _cv(hem + fw * (off + 5.0), sk)
		var mid: Vector2 = _cv(hem + Vector2(-back_k * 0.5 + sway, 8.0) + fw * off * 0.8, sk)
		var tip: Vector2 = _cv(hem + Vector2(-back_k * 1.1 - 4.0 + sway * 1.6, 17.0 + 4.0 * float(i % 2)) + fw * off * 0.5, sk)
		_poly(PackedVector2Array([base_a, mid + Vector2(-2.0, 0.0), tip, mid + Vector2(2.0, 0.0), base_b]), M_COAT if i != 1 else M_CLOAK)
	# рваные края подола
	_line(_cv(hem - fw * 14.0, sk), _cv(hem + fw * 12.0, sk), 1.0, M_ARMOR_L)

	# --- дальняя рука: рукав и бледная кисть
	var hb: Vector2 = _cv(sk["hand_b"], sk)
	var elb: Vector2 = _cv(sk["el_b"], sk)
	_limb(_cv(sk["sh_b"], sk), elb, 8.4, 7.8, M_COAT)
	_limb(elb, hb, 8.8, 6.6, M_COAT)
	_disc(hb, 2.7, M_SKIN)
	_line(hb, hb + Vector2(3.0, 2.0), 1.4, M_SKIN)
	_cast_pt = hb

	# --- корпус в рясе
	var sf: Vector2 = _cv(sk["sh_f"], sk)
	var sb: Vector2 = _cv(sk["sh_b"], sk)
	_poly(PackedVector2Array([sf + Vector2(0, -2), sb + Vector2(-1, -2), wb2 + Vector2(-2, 0), wa + Vector2(2, 0)]), M_COAT)
	_line(_cv(chest - fw * 7.0, sk), _cv(hip + fw * 3.0, sk), 1.0, M_ARMOR_L)
	# пояс с красным лоскутом и подвеской-цепью
	var belt_a: Vector2 = _cv(hip + up_n * 3.0 - fw * 9.0, sk)
	var belt_b: Vector2 = _cv(hip + up_n * 3.0 + fw * 9.0, sk)
	_line(belt_a, belt_b, 2.6, M_SCARF)
	_disc(belt_b, 1.8, M_BONE)
	for k in range(5):
		var cx: float = belt_b.x + 1.0 + 1.6 * sin(ph * 0.5 + float(k) * 0.5)
		_put(int(cx), int(belt_b.y) + 3 + k * 2, M_GOLD)

	# --- голова: капюшон, тёмная пустота, маска Они с рогами
	var hc: Vector2 = _cv(head, sk)
	var hx: int = int(round(hc.x))
	var hy: int = int(round(hc.y))
	var nk: Vector2 = _cv(sk["neck"], sk)
	_limb(_cv(chest, sk), hc, 8.0, 7.0, M_HOOD)
	_strip(_hood, 3.8, 1.4, M_HOOD)
	_disc(Vector2(hc.x - 0.5, hc.y + 0.5), 9.6, M_COAT)
	_poly(PackedVector2Array([Vector2(hx - 11, hy + 8), Vector2(hx - 9, hy - 4), Vector2(hx - 2, hy - 11), Vector2(hx + 6, hy - 9), Vector2(hx + 9, hy + 1), Vector2(hx + 6, hy + 9)]), M_COAT)
	_line(Vector2(hx - 8, hy - 7), Vector2(hx + 7, hy - 9), 1.2, M_ARMOR_L)
	_disc(Vector2(hx + 2.0, hy + 1.0), 7.6, M_MASK)
	# маска: вытянутый овал в три четверти
	_disc(Vector2(hx + 3.5, hy), 5.6, M_SKIN)
	_poly(PackedVector2Array([Vector2(hx + 0, hy + 1), Vector2(hx + 9, hy + 1), Vector2(hx + 7, hy + 10), Vector2(hx + 3, hy + 11)]), M_SKIN)
	# красные метки и щель глаза
	_line(Vector2(hx + 5, hy - 3), Vector2(hx + 9, hy - 5), 1.0, M_LIP)
	_line(Vector2(hx + 5, hy + 4), Vector2(hx + 7, hy + 9), 1.0, M_LIP)
	_put(hx + 4, hy + 2, M_LIP)
	var angry: bool = _atk_kind >= 0 or rage or _hit_t >= 0.0
	_put(hx + 5, hy - 1, M_IRIS)
	_put(hx + 6, hy - 1, M_IRIS)
	_put(hx + 8, hy - 1, M_IRIS)
	if angry:
		_put(hx + 5, hy, M_IRIS)
		_put(hx + 7, hy - 2, M_IRIS)
	# рога: два, изогнуты вверх и назад
	_limb(Vector2(hx + 2, hy - 5), Vector2(hx - 1, hy - 13), 3.0, 2.0, M_SKIN)
	_limb(Vector2(hx - 1, hy - 13), Vector2(hx - 4, hy - 19), 2.0, 0.8, M_SKIN)
	_limb(Vector2(hx + 6, hy - 5), Vector2(hx + 6, hy - 12), 2.6, 1.8, M_SKIN)
	_limb(Vector2(hx + 6, hy - 12), Vector2(hx + 4, hy - 18), 1.8, 0.8, M_SKIN)
	_line(nk + Vector2(-3, 2) * S, nk + Vector2(5, 3) * S, 3.0, M_SCARF)
	_strip(_scarf, 3.2, 1.0, M_SCARF)

	# --- коса: цепь на древке, обмотка, лезвие
	var sc: Dictionary = _scythe_pts(sk)
	var back_c: Vector2 = _cv(sc["back"], sk)
	var head_c: Vector2 = _cv(sc["head"], sk)
	_line(back_c, head_c, 2.8, M_LEATHER)
	_line(back_c.lerp(head_c, 0.1), head_c, 1.0, M_ARMOR_L)
	for t in [0.12, 0.62]:
		var wp: Vector2 = back_c.lerp(head_c, t)
		_line(wp - Vector2(1.0, 0.0), wp + Vector2(1.0, 1.0), 3.4, M_SCARF)
	_disc(back_c, 1.8, M_BONE)
	# цепь, обвивающая древко, и маленький череп-подвес
	for t in [0.30, 0.38, 0.46, 0.54]:
		var cp: Vector2 = back_c.lerp(head_c, t)
		_put(int(cp.x) + (1 if int(t * 100.0) % 2 == 0 else -1), int(cp.y), M_GOLD)
	# лезвие: контур внешний/внутренний
	var outer := PackedVector2Array()
	var inner := PackedVector2Array()
	for i in range(0, 13):
		var t2: float = float(i) / 12.0
		var ip: Vector2 = _blade_curve(sc, t2)
		var wdt: float = SC_WIDTH * pow(1.0 - t2, 0.9) + 0.4
		inner.append(_cv(ip, sk))
		outer.append(_cv(ip + (sc["hd"] as Vector2) * wdt, sk))
	var blade := PackedVector2Array()
	blade.append_array(outer)
	for i in range(inner.size() - 1, -1, -1):
		blade.append(inner[i])
	_poly(blade, M_STEEL)
	for i in range(0, outer.size() - 1):
		_line(outer[i], outer[i + 1], 1.0, M_ARMOR_L)
	for i in range(0, inner.size() - 1):
		_line(inner[i], inner[i + 1], 1.2, M_RUNE)
	# втулка с шипами
	for k in range(6):
		var ang: float = float(k) * TAU / 6.0 + 0.3
		var d: Vector2 = Vector2(cos(ang), sin(ang))
		_line(head_c + d * 3.0, head_c + d * 6.5, 1.8, M_STEEL)
	_disc(head_c, 3.8, M_ARMOR_L)
	_disc(head_c, 2.2, M_SCARF)
	_put(int(round(head_c.x)), int(round(head_c.y)), M_RUNE)
	var tip_c: Vector2 = _cv(sc["tip"], sk)
	var mid_c: Vector2 = _cv(_blade_curve(sc, 0.5), sk)
	blade_tip_local = (tip_c - Vector2(float(OX), float(OY))) * float(Game.PIXEL)
	blade_mid_local = (mid_c - Vector2(float(OX), float(OY))) * float(Game.PIXEL)

	# --- ближняя рука поверх древка: широкий рваный рукав и бледная кисть
	var shf: Vector2 = _cv(sk["sh_f"], sk)
	var elf: Vector2 = _cv(sk["el_f"], sk)
	var hdf: Vector2 = _cv(sk["hand_f"], sk)
	_limb(shf, elf, 9.4, 8.4, M_COAT)
	_limb(elf, hdf, 9.6, 6.8, M_COAT)
	_line(elf.lerp(hdf, 0.2), elf.lerp(hdf, 0.8), 1.0, M_ARMOR_L)
	_disc(hdf, 2.8, M_SKIN)
	_line(hdf, hdf + Vector2(2.0, 2.0), 1.4, M_SKIN)

	if dying:
		_apply_dissolve()
	_bake(sk)
	_render_fx(sk)


## Растворение в дым: пиксели исчезают по шуму, порог растёт с кадром смерти.
func _apply_dissolve() -> void:
	var k: float = _dissolve
	for y in range(maxi(_by0, 0), mini(_by1 + 1, H)):
		for x in range(maxi(_bx0, 0), mini(_bx1 + 1, W)):
			var i: int = y * W + x
			if _ids[i] == 0:
				continue
			var h: int = (x * 73856093) ^ (y * 19349663) ^ (_frame_idx * 83492791)
			var r: float = float(absi(h) % 1000) / 1000.0
			var bias: float = float(y - _by0) / maxf(float(_by1 - _by0), 1.0)   # низ растворяется раньше
			if r < k * 1.15 - 0.15 * (1.0 - bias):
				_ids[i] = 0


# ====================================================================== эффекты

func _trail_color(age: float) -> Color:
	if age < 0.22:
		return Color(0.95, 0.85, 1.0, 0.95)
	if age < 0.45:
		return Color(0.78, 0.50, 1.0, 0.8)
	if age < 0.72:
		return Color(0.48, 0.22, 0.85, 0.6)
	return Color(0.26, 0.10, 0.50, 0.4)


func _fx_disc(c: Vector2, r: float, col: Color) -> void:
	for dy in range(int(-r) - 1, int(r) + 2):
		for dx in range(int(-r) - 1, int(r) + 2):
			var d: float = sqrt(float(dx * dx + dy * dy))
			if d <= r:
				_fxp(int(c.x) + dx, int(c.y) + dy, Color(col.r, col.g, col.b, col.a * (1.0 - 0.5 * d / maxf(r, 0.01))))


func _fx_line(a: Vector2, b: Vector2, w: float, col: Color) -> void:
	var n: int = maxi(1, int(a.distance_to(b) * 1.5))
	for i in range(n + 1):
		_fx_disc(a.lerp(b, float(i) / float(n)), w * 0.5, col)


func _sword_glow(sk: Dictionary) -> void:
	# мерцающее фиолетовое сияние вдоль лезвия
	var b: Vector2 = sk["blade_b"]
	var t: Vector2 = sk["blade_t"]
	var tier: int = _sword_tier()
	var col: Color = Color(1.0, 0.6, 0.8) if rage else Color(0.62, 0.30, 1.0)
	var r: float = 2.0 + 0.6 * float(tier) + (2.0 if _atk_kind >= 0 else 0.0)
	for i in range(10):
		var q: Vector2 = b.lerp(t, float(i) / 9.0)
		_fx_disc(q, r, Color(col.r, col.g, col.b, 0.20 + 0.04 * float(tier)))
	_fx_disc(t, 2.4, Color(1.0, 0.9, 1.0, 0.85))


func _render_fx(sk: Dictionary) -> void:
	_fx_img.fill(Color(0, 0, 0, 0))
	# шлейф лезвия и дуга энергии: след острия, чем свежее — тем ярче и толще
	var n: int = _trail.size()
	for i in range(n - 1):
		var a: Dictionary = _trail[i]
		var b: Dictionary = _trail[i + 1]
		var age: float = (_t - float(b["t"])) / 0.17
		if age >= 1.0:
			continue
		var c: Color = _trail_color(age)
		_fx_poly(PackedVector2Array([(a["b"] as Vector2).lerp(a["tip"], 0.4), a["tip"], b["tip"], (b["b"] as Vector2).lerp(b["tip"], 0.4)]), Color(c.r, c.g, c.b, c.a * 0.7))
		var w: float = (3.4 if _atk_kind == 2 else 2.4) * (1.0 - age) + 0.8
		_fx_line(a["tip"], b["tip"], w, c)
	_sword_glow(sk)
	# вспышка у руки при выстреле
	if _cast_t > 0.0:
		var f: float = clampf(_cast_t / 0.3, 0.0, 1.0)
		_fx_disc(_cast_pt + Vector2(3, 0), 2.0 + 5.0 * f, Color(0.8, 0.5, 1.0, 0.8))
	var base: Vector2 = Vector2(float(OX), float(OY)) + (sk["hip"] as Vector2) * K
	# частицы энергии: поднимаются от подола и вьются у лезвия
	if _dissolve < 0.95:
		for i in range(16):
			var s: float = fposmod(_t * 0.8 + float(i) * 0.137, 1.0)
			var px: float = base.x - 4.0 - 20.0 * s * (0.5 + _fly_k) + 7.0 * sin(float(i) * 2.3 + s * 6.0)
			var py: float = base.y + 14.0 - 34.0 * s
			var a2: float = (1.0 - s) * (0.85 if i % 3 != 0 else 0.55) * (1.0 - _dissolve)
			var col: Color = Color(0.85, 0.55, 1.0, a2) if i % 2 == 0 else Color(0.55, 0.25, 0.95, a2)
			_fxp(int(px), int(py), col)
			if i % 4 == 0:
				_fxp(int(px) + 1, int(py), Color(col.r, col.g, col.b, a2 * 0.6))
				_fxp(int(px), int(py) + 1, Color(col.r, col.g, col.b, a2 * 0.6))
	for i in range(6):
		var tw: float = 0.5 + 0.5 * sin(_t * 9.0 + float(i) * 1.9)
		var q: Vector2 = (sk["blade_b"] as Vector2).lerp(sk["blade_t"], float(i) / 5.0) + Vector2(sin(float(i) * 3.1 + _t * 2.0) * 3.0, -3.0 - 4.0 * tw)
		_fxp(int(q.x), int(q.y), Color(0.95, 0.8, 1.0, 0.45 + 0.4 * tw))
	# сбор энергии перед навыком: сходящееся кольцо у лезвия
	if _charge > 0.0:
		var cc: Vector2 = (sk["blade_b"] as Vector2).lerp(sk["blade_t"], 0.5)
		for k in range(14):
			var ang: float = TAU * float(k) / 14.0 + _t * 5.0
			var rr: float = 10.0 + 4.0 * sin(_t * 12.0 + float(k))
			_fx_disc(cc + Vector2(cos(ang), sin(ang)) * rr, 1.0, Color(0.85, 0.6, 1.0, 0.8 * _charge))
	# навык: кристаллы тьмы вырастают из земли впереди и гаснут
	if _burst > 0.0 or (_atk_kind == 3 and _frame_idx >= 6):
		var grow: float = [0.55, 1.0, 0.7, 0.35][clampi(_frame_idx - 6, 0, 3)]
		var gx: float = float(OX) + 52.0
		var heights: Array = [30.0, 22.0, 17.0, 24.0, 13.0, 18.0, 10.0]
		var offs: Array = [0.0, -9.0, 9.0, 18.0, -17.0, 28.0, 36.0]
		for k in range(heights.size()):
			var hgt: float = float(heights[k]) * grow
			var bx: float = gx + float(offs[k])
			var tipy: float = float(OY) - hgt
			_fx_poly(PackedVector2Array([Vector2(bx - 4.0, float(OY)), Vector2(bx, tipy), Vector2(bx + 4.0, float(OY))]), Color(0.55, 0.22, 0.95, 0.85))
			_fx_poly(PackedVector2Array([Vector2(bx - 1.5, float(OY)), Vector2(bx, tipy + 2.0), Vector2(bx + 1.5, float(OY))]), Color(0.95, 0.85, 1.0, 0.9))
		_fx_disc(Vector2(gx, float(OY) - 3.0), 7.0 * grow, Color(0.8, 0.5, 1.0, 0.45))
	# получение урона: вспышка-звезда на груди
	if _hitfx > 0.0:
		var hc2: Vector2 = Vector2(float(OX), float(OY)) + (sk["chest"] as Vector2) * K
		for k in range(8):
			var ang2: float = TAU * float(k) / 8.0
			_fx_line(hc2, hc2 + Vector2(cos(ang2), sin(ang2)) * 14.0, 1.4, Color(1.0, 0.9, 1.0, 0.9))
		_fx_disc(hc2, 4.0, Color(1.0, 1.0, 1.0, 0.9))
	# смерть: клубы дыма поднимаются из места растворения
	if _death_t >= 0.0:
		var dk: float = clampf(_death_t / DEATH_DUR, 0.0, 1.0)
		for i in range(12):
			var s2: float = fposmod(dk * 1.2 + float(i) * 0.09, 1.0)
			var sx: float = base.x - 8.0 + float(i % 6) * 4.0 + 5.0 * sin(float(i) * 1.7 + s2 * 4.0)
			var sy: float = base.y + 18.0 - 30.0 * s2
			_fx_disc(Vector2(sx, sy), 2.0 + 3.0 * s2, Color(0.5, 0.2, 0.85, 0.35 * (1.0 - s2) * minf(dk * 3.0, 1.0)))
	# аура ярости: красно-фиолетовое пламя вокруг подола
	if rage:
		for i in range(7):
			var ph2: float = _t * 7.0 + float(i) * 1.7
			var hgt2: float = 12.0 + 10.0 * (0.5 + 0.5 * sin(ph2 * 1.3)) + float(i % 3) * 4.0
			var bx2: float = base.x - 12.0 + float(i) * 4.0 + sin(ph2) * 2.0
			for j in range(int(hgt2)):
				var f2: float = float(j) / hgt2
				var wd: int = int((1.0 - f2) * 3.0)
				for xx in range(-wd, wd + 1):
					_fxp(int(bx2) + xx, int(base.y + 14.0) - j - int(sin(ph2 + f2 * 3.0) * 2.0), Color(1.0, 0.35 + f2 * 0.3, 0.6, 0.5 * (1.0 - f2)))


func _draw_fx() -> void:
	var px: float = float(Game.PIXEL)
	for g in _ghosts:
		var a: float = (1.0 - float(g["age"]) / 0.26) * 0.38
		var col: Color = Color(1.0, 0.5, 0.7, a) if rage else Color(0.6, 0.3, 1.0, a)
		_fxn.draw_texture_rect(g["tex"], Rect2(-float(OX) * px + float(g["x"]), -float(OY) * px, float(W) * px, float(H) * px), false, col)
	_fxn.draw_texture_rect(_fx_tex, Rect2(-float(OX) * px, -float(OY) * px, float(W) * px, float(H) * px), false)
