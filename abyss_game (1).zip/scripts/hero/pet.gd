extends Node2D
## Питомец: летит рядом с героем, цвет и сияние зависят от качества.
## Для витрины можно задать static_mode и фиксированную позицию.

const PetData := preload("res://scripts/data/pet_data.gd")
const Sprites := preload("res://scripts/gfx/sprites.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")

var species: int = 0
var rarity: int = 0
var follow: bool = true
var label: bool = false
var _t: float = randf() * 10.0
var _target: Vector2 = Vector2.ZERO


func set_pet(sp: int, r: int) -> void:
	species = sp
	rarity = r
	queue_redraw()


func _process(delta: float) -> void:
	_t += delta
	if follow and Game.hero != null:
		var h: Node2D = Game.hero
		_target = h.position + Vector2(-70.0, -175.0 + sin(_t * 3.0) * 10.0)
		if position.distance_to(_target) > 500.0:
			position = _target
		position = position.lerp(_target, clampf(delta * 5.0, 0.0, 1.0))
	queue_redraw()


func _draw() -> void:
	var px: float = float(Game.PIXEL)
	var col: Color = PetData.color_of(rarity)
	var tex: Texture2D = Sprites.get_tex("pet", int(_t * 9.0), species * 10 + rarity)
	var size: Vector2 = Vector2(tex.get_width(), tex.get_height()) * px
	var c: Vector2 = Vector2.ZERO
	# сияние: чем выше качество, тем шире и ярче
	var glow_r: float = 18.0 + 8.0 * float(rarity)
	for i in range(4):
		var rr: float = glow_r * (1.0 - float(i) * 0.2)
		draw_circle(c, rr, Color(col.r, col.g, col.b, (0.05 + 0.012 * float(rarity)) * (1.0 + float(i) * 0.3)))
	if rarity >= 3:
		var n: int = 2 + rarity
		for k in range(n):
			var a: float = _t * (1.2 + 0.2 * float(k % 3)) + float(k) / float(n) * TAU
			var q: Vector2 = c + Vector2(cos(a), sin(a) * 0.6) * (glow_r + 6.0 + sin(_t * 3.0 + float(k)) * 4.0)
			draw_rect(Rect2(roundf(q.x / px) * px, roundf(q.y / px) * px, px * 2.0, px * 2.0), Color(col.r, col.g, col.b, 0.9))
	if rarity >= 6:
		for k in range(8):
			var a2: float = _t * 0.8 + float(k) / 8.0 * TAU
			draw_line(c + Vector2(cos(a2), sin(a2)) * 30.0, c + Vector2(cos(a2), sin(a2)) * (58.0 + sin(_t * 4.0 + float(k)) * 8.0), Color(1.0, 0.9, 0.4, 0.55), px * 2.0)
	var p: Vector2 = c - size * 0.5
	draw_texture_rect(tex, Rect2(Vector2(roundf(p.x / px) * px, roundf(p.y / px) * px), size), false)
	if label:
		var nm: String = String(PetData.SPECIES[species]["name"])
		PixelFont.draw_text_centered(self, nm, 0.0, 48.0, 2, col)
		PixelFont.draw_text_centered(self, String(PetData.RARITIES[rarity]["name"]), 0.0, 70.0, 2, col)
		PixelFont.draw_text_centered(self, "+%d%%" % int(PetData.RARITIES[rarity]["bonus"]), 0.0, 92.0, 2, Color(1, 0.9, 0.5))
