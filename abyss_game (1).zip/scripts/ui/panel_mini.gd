extends RefCounted
## Мини-игра «Сундуки удачи»: три сундука, в каждом свой приз. Выберите один.

const Kit := preload("res://scripts/ui/ui_kit.gd")
const Fmt := preload("res://scripts/data/fmt.gd")
const Sprites := preload("res://scripts/gfx/sprites.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")

var prizes: Array = []
var picked: int = -1
var claimed: bool = false


func start() -> void:
	var z: float = float(Eco.zone_number())
	var base: float = maxf(Eco.income, 10.0)
	prizes = [
		{"t": "coins", "v": base * 60.0 + Eco.coin_value() * 40.0, "label": "МОНЕТЫ"},
		{"t": "coins", "v": base * 400.0 + Eco.coin_value() * 200.0, "label": "ДЖЕКПОТ"},
		{"t": "souls", "v": 3.0 + z, "label": "ДУШИ"},
	]
	prizes.shuffle()
	picked = -1
	claimed = false


func _pick(h: Node2D, i: int) -> void:
	if picked >= 0:
		return
	picked = i
	var p: Dictionary = prizes[i]
	if p["t"] == "coins":
		Eco.add_coins(float(p["v"]))
	else:
		Eco.add_souls(float(p["v"]))
	claimed = true
	Sfx.play("chest")


func draw(h: Node2D) -> void:
	var c: CanvasItem = h.c
	c.draw_rect(Rect2(Vector2.ZERO, h.view), Color(0, 0, 0, 0.6))
	var R := Rect2(h.view.x * 0.5 - 190.0, 70.0, 380.0, 220.0)
	Kit.frame(c, R)
	PixelFont.draw_text_centered(c, "СУНДУКИ УДАЧИ", R.position.x + 190.0, R.position.y + 12.0, 2, Kit.GOLD_L)
	PixelFont.draw_text_centered(c, "ВЫБЕРИ ОДИН СУНДУК" if picked < 0 else "ТВОЙ ПРИЗ ПОЛУЧЕН!", R.position.x + 190.0, R.position.y + 36.0, 1, Kit.DIM)
	for i in range(3):
		var bx: float = R.position.x + 20.0 + float(i) * 118.0
		var box := Rect2(bx, R.position.y + 56.0, 108, 100)
		var open: bool = picked >= 0
		var mine: bool = picked == i
		Kit.frame(c, box, Kit.BG2, Kit.GOLD if (mine or picked < 0) else Kit.GOLD_D)
		var tex: Texture2D = Sprites.get_tex("chest", 0 if not open else 3)
		var col: Color = Color(1, 1, 1, 1) if (mine or not open) else Color(0.5, 0.5, 0.55, 1)
		c.draw_texture_rect(tex, Rect2(box.position + Vector2(24, 8), tex.get_size() * 2.0), false, col)
		if open:
			var p: Dictionary = prizes[i]
			var txt: String = ("+" + Fmt.num(float(p["v"]))) if p["t"] == "coins" else ("+" + Fmt.num(float(p["v"]) * float(Eco.dim_data()["soul"])) + " ДУШ")
			PixelFont.draw_text_centered(c, String(p["label"]), box.position.x + 54.0, box.position.y + 66.0, 1, Kit.GOLD_L if mine else Kit.DIM)
			PixelFont.draw_text_centered(c, txt, box.position.x + 54.0, box.position.y + 80.0, 1, Kit.TEXT if mine else Kit.DIM)
		else:
			var idx: int = i
			h.hit_area(box, func() -> void: _pick(h, idx))
			PixelFont.draw_text_centered(c, "?", box.position.x + 54.0, box.position.y + 74.0, 2, Kit.GOLD_L)
	if picked >= 0:
		h.btn(Rect2(R.position.x + 130.0, R.end.y - 40.0, 120, 30), "ЗАБРАТЬ", func() -> void: h.close_panel(), Kit.S_GREEN, true, "", "", 2)
