extends Node2D
## Слой с отсечением по прямоугольнику: рисует переданным колбэком только внутри clip_rect.

var clip_rect: Rect2 = Rect2()
var draw_cb: Callable = Callable()


func _process(_d: float) -> void:
	queue_redraw()


func _draw() -> void:
	var ci: RID = get_canvas_item()
	if not draw_cb.is_valid() or clip_rect.size.x <= 0.0:
		RenderingServer.canvas_item_set_clip(ci, false)
		return
	RenderingServer.canvas_item_set_clip(ci, true)
	RenderingServer.canvas_item_set_custom_rect(ci, true, clip_rect)
	draw_cb.call(self)
