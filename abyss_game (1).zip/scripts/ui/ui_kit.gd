extends RefCounted
## Пиксельные примитивы интерфейса: рамки, кнопки, полосы. Координаты — в пикселях арта.

const PixelFont := preload("res://scripts/hud/pixel_font.gd")

const BG := Color(0.15, 0.15, 0.18, 0.98)
const BG2 := Color(0.22, 0.22, 0.25, 1.0)
const WOOD := Color(0.50, 0.30, 0.13)
const GOLD := Color(0.86, 0.62, 0.10)
const GOLD_L := Color(1.0, 0.85, 0.35)
const GOLD_D := Color(0.38, 0.22, 0.05)
const TEXT := Color(1.0, 1.0, 1.0)
const DIM := Color(0.60, 0.55, 0.62)
const GREEN := Color(0.16, 0.72, 0.22)
const RED := Color(0.70, 0.18, 0.20)
const PURPLE := Color(0.50, 0.24, 0.72)
const BLUE := Color(0.25, 0.45, 0.85)
const GREY := Color(0.28, 0.25, 0.32)

enum { S_GOLD, S_GREEN, S_RED, S_PURPLE, S_GREY, S_TAB, S_TAB_ON }


static func frame(c: CanvasItem, r: Rect2, fill: Color = BG, border: Color = WOOD) -> void:
	c.draw_rect(r, Color(0.04, 0.02, 0.02))
	c.draw_rect(r.grow(-1.0), border.darkened(0.35))
	c.draw_rect(r.grow(-2.0), border)
	# светлая грань сверху-слева, тёмная снизу-справа: рамка выглядит объёмной
	c.draw_rect(Rect2(r.position + Vector2(2, 2), Vector2(r.size.x - 4.0, 1.0)), border.lightened(0.45))
	c.draw_rect(Rect2(r.position + Vector2(2, 2), Vector2(1.0, r.size.y - 4.0)), border.lightened(0.3))
	c.draw_rect(Rect2(r.position + Vector2(2, r.size.y - 3.0), Vector2(r.size.x - 4.0, 1.0)), border.darkened(0.4))
	c.draw_rect(Rect2(r.position + Vector2(r.size.x - 3.0, 2), Vector2(1.0, r.size.y - 4.0)), border.darkened(0.4))
	c.draw_rect(r.grow(-4.0), Color(0.04, 0.02, 0.02))
	c.draw_rect(r.grow(-5.0), fill)
	c.draw_rect(Rect2(r.position + Vector2(5, 5), Vector2(r.size.x - 10.0, 1.0)), fill.lightened(0.12))


static func _style_colors(style: int, enabled: bool) -> Array:
	if not enabled:
		return [GREY, GREY.lightened(0.18), GREY.darkened(0.35)]
	var base: Color = GOLD
	match style:
		S_GREEN: base = GREEN
		S_RED: base = RED
		S_PURPLE: base = PURPLE
		S_GREY: base = GREY
		S_TAB: base = Color(0.20, 0.10, 0.26)
		S_TAB_ON: base = GOLD.darkened(0.15)
	return [base, base.lightened(0.38), base.darkened(0.55)]


static func button(c: CanvasItem, r: Rect2, label: String, style: int, enabled: bool, pressed: bool, sub: String = "", icon: Texture2D = null, scale: int = 2) -> void:
	var cols: Array = _style_colors(style, enabled)
	var rr: Rect2 = r
	if pressed and enabled:
		rr.position.y += 1.0
	c.draw_rect(rr, Color(0.02, 0.0, 0.03))
	c.draw_rect(rr.grow(-1.0), cols[2])
	c.draw_rect(Rect2(rr.position + Vector2(1, 1), rr.size - Vector2(2, 3)), cols[0])
	c.draw_rect(Rect2(rr.position + Vector2(1, 1), Vector2(rr.size.x - 2.0, 2.0)), cols[1])
	c.draw_rect(Rect2(rr.position + Vector2(1, 1), Vector2(1.0, rr.size.y - 3.0)), cols[1])
	var col: Color = TEXT if enabled else DIM
	var cx: float = rr.position.x + rr.size.x * 0.5
	var ix: float = 0.0
	if icon != null:
		ix = float(icon.get_width()) * 0.5 + 2.0
		var ip := Vector2(rr.position.x + 4.0, rr.position.y + (rr.size.y - float(icon.get_height())) * 0.5 - 1.0)
		c.draw_texture(icon, ip, Color(1, 1, 1, 1) if enabled else Color(0.6, 0.6, 0.6, 1))
		cx += ix
	if sub != "":
		PixelFont.draw_text_centered(c, label, cx, rr.position.y + 4.0, 1, col)
		PixelFont.draw_text_centered(c, sub, cx, rr.position.y + 14.0, scale, col)
	elif label != "":
		var th: float = 7.0 * float(scale)
		PixelFont.draw_text_centered(c, label, cx, rr.position.y + (rr.size.y - th) * 0.5 - 1.0, scale, col)


static func bar(c: CanvasItem, r: Rect2, f: float, fill: Color, back: Color = Color(0.12, 0.05, 0.12)) -> void:
	c.draw_rect(r, Color(0.02, 0.0, 0.03))
	c.draw_rect(r.grow(-1.0), back)
	var w: float = (r.size.x - 2.0) * clampf(f, 0.0, 1.0)
	if w >= 1.0:
		c.draw_rect(Rect2(r.position + Vector2(1, 1), Vector2(floorf(w), r.size.y - 2.0)), fill)
		c.draw_rect(Rect2(r.position + Vector2(1, 1), Vector2(floorf(w), 1.0)), fill.lightened(0.4))


static func icon_box(c: CanvasItem, r: Rect2, icon: Texture2D, active: bool = true) -> void:
	c.draw_rect(r, Color(0.02, 0.0, 0.03))
	c.draw_rect(r.grow(-1.0), Color(0.12, 0.12, 0.14) if active else Color(0.09, 0.09, 0.10))
	if icon != null:
		var k: float = maxf(1.0, floorf(minf((r.size.x - 2.0) / icon.get_width(), (r.size.y - 2.0) / icon.get_height())))
		var sz: Vector2 = icon.get_size() * k
		var p: Vector2 = r.position + (r.size - sz) * 0.5
		c.draw_texture_rect(icon, Rect2(Vector2(floorf(p.x), floorf(p.y)), sz), false, Color(1, 1, 1, 1) if active else Color(0.35, 0.35, 0.4, 1))
