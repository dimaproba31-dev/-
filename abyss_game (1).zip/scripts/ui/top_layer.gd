extends Node2D
var hud: Node2D

func _process(_d: float) -> void:
	queue_redraw()

func _draw() -> void:
	if hud != null:
		hud.call("draw_top", self)
