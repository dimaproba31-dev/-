extends RefCounted
## Лавка: снаряжение, улучшения, задания, меню.

const Kit := preload("res://scripts/ui/ui_kit.gd")
const Fmt := preload("res://scripts/data/fmt.gd")
const GameData := preload("res://scripts/data/game_data.gd")
const Sprites := preload("res://scripts/gfx/sprites.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")

const TABS: Array = [["ВЕЩИ", "sword"], ["БОНУСЫ", "potion"], ["ЗАДАНИЯ", "scroll"], ["МЕНЮ", "gear"]]
const BUY_MODES: Array = [["x1", 1], ["x10", 10], ["x50", 50], ["МАКС", -1]]

var tab: int = 0
var buy_mode: int = 0
var _reset_arm: float = 0.0
var _top: float = 0.0
var _rect: Rect2


func on_open(h: Node2D) -> void:
	tab = 0
	h.scroll = 0.0


func _set_tab(h: Node2D, t: int) -> void:
	tab = t
	h.scroll = 0.0


func draw(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var P: Rect2 = h.panel_rect()
	_rect = P
	c.draw_rect(Rect2(Vector2.ZERO, h.view), Color(0, 0, 0, 0.55))
	Kit.frame(c, P)
	# вкладки
	for i in range(TABS.size()):
		var r := Rect2(P.position.x + 8.0 + float(i) * 98.0, P.position.y + 7.0, 94, 26)
		var idx: int = i
		h.btn(r, TABS[i][0], func() -> void: _set_tab(h, idx), Kit.S_TAB_ON if tab == i else Kit.S_TAB, true, "", TABS[i][1], 1)
	# монеты и закрыть
	h.btn(Rect2(P.end.x - 34.0, P.position.y + 7.0, 26, 26), "X", func() -> void: h.close_panel(), Kit.S_RED, true, "", "", 2)
	var coin: Texture2D = Sprites.get_tex("coin", 0)
	var cs: String = Fmt.num(Eco.coins())
	var cw: int = PixelFont.text_width(cs, 2)
	c.draw_texture(coin, Vector2(P.end.x - 44.0 - float(cw) - 20.0, P.position.y + 9.0))
	PixelFont.draw_text_right(c, cs, P.end.x - 44.0, P.position.y + 13.0, 2, Kit.GOLD_L)
	var body_top: float = P.position.y + 40.0
	if tab == 0:
		for i in range(BUY_MODES.size()):
			var mi: int = i
			var r2 := Rect2(P.position.x + 8.0 + float(i) * 62.0, body_top, 58, 18)
			h.btn(r2, BUY_MODES[i][0], func() -> void: buy_mode = mi, Kit.S_GREEN if buy_mode == i else Kit.S_GREY, true, "", "", 1)
		PixelFont.draw_text_right(c, "ДОХОД: " + Fmt.num(Eco.income) + "/С", P.end.x - 10.0, body_top + 6.0, 1, Kit.DIM)
		body_top += 24.0
	_top = body_top
	h.list_rect = Rect2(P.position.x + 4.0, body_top, P.size.x - 8.0, P.end.y - body_top - 6.0)
	h.scroll_max = maxf(0.0, _content_height() - h.list_rect.size.y)
	h.scroll = clampf(h.scroll, 0.0, h.scroll_max)


func _content_height() -> float:
	match tab:
		0: return _visible_equip() * 50.0 + 4.0
		1: return float(GameData.UPGRADES.size()) * 54.0 + 4.0
		2: return 210.0
		_: return 250.0


func _visible_equip() -> float:
	var top: int = 0
	for i in range(GameData.EQUIPMENT.size()):
		if Eco.level(i) > 0:
			top = i
	return float(mini(top + 2, GameData.EQUIPMENT.size()))


func draw_list(h: Node2D) -> void:
	match tab:
		0: _equip(h)
		1: _upgrades(h)
		2: _quests(h)
		_: _menu(h)


func _y0(h: Node2D) -> float:
	return h.list_rect.position.y - h.scroll


func _equip(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var n: int = int(_visible_equip())
	for i in range(n):
		var e: Dictionary = GameData.EQUIPMENT[i]
		var row := Rect2(R.position.x + 2.0, _y0(h) + float(i) * 50.0, R.size.x - 4.0, 46)
		if row.end.y < R.position.y or row.position.y > R.end.y:
			continue
		var lvl: int = Eco.level(i)
		var locked: bool = i > 0 and Eco.level(i - 1) == 0 and lvl == 0
		Kit.frame(c, row, Kit.BG2, Kit.GOLD_D)
		Kit.icon_box(c, Rect2(row.position.x + 6.0, row.position.y + 6.0, 34, 34), Sprites.icon(e["icon"]), not locked)
		PixelFont.draw_text(c, String(e["name"]) if not locked else "???", row.position + Vector2(48, 6), 2, Kit.TEXT if not locked else Kit.DIM)
		var info: String = "УР. " + str(lvl)
		if lvl > 0:
			info += "   +" + Fmt.num(Eco.item_income(i)) + "/С"
		PixelFont.draw_text(c, info, row.position + Vector2(48, 24), 1, Kit.GOLD_L)
		var nxt: int = 0
		var prev: int = 0
		for m in GameData.MILESTONES:
			if m > lvl:
				nxt = m
				break
			prev = m
		if nxt > 0:
			Kit.bar(c, Rect2(row.position.x + 48.0, row.position.y + 34.0, 110, 5), float(lvl - prev) / float(nxt - prev), Color(0.9, 0.6, 0.15))
			PixelFont.draw_text(c, "×2 НА " + str(nxt), row.position + Vector2(164, 33), 1, Kit.DIM)
		# кнопка покупки
		var mode: int = int(BUY_MODES[buy_mode][1])
		var cnt: int = mode
		if mode < 0:
			cnt = maxi(Eco.max_affordable(i), 1)
		var cost: float = Eco.item_cost(i, cnt)
		var can: bool = Eco.coins() >= cost
		var br := Rect2(row.end.x - 130.0, row.position.y + 5.0, 124, 36)
		var idx: int = i
		h.btn(br, "+" + str(cnt) + " УР.", func() -> void: _buy(h, idx), Kit.S_GREEN, can and not locked, Fmt.num(cost), "", 2)


func _buy(h: Node2D, i: int) -> void:
	var mode: int = int(BUY_MODES[buy_mode][1])
	var got: int = Eco.buy_equip(i, mode)
	if got > 0:
		Sfx.play("buy")
	else:
		Sfx.play("error")


func _upgrades(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var order: Array = []
	for u in GameData.UPGRADES:
		if not Eco.has_upgrade(u["id"]):
			order.append(u)
	for u in GameData.UPGRADES:
		if Eco.has_upgrade(u["id"]):
			order.append(u)
	for i in range(order.size()):
		var u: Dictionary = order[i]
		var row := Rect2(R.position.x + 2.0, _y0(h) + float(i) * 54.0, R.size.x - 4.0, 50)
		if row.end.y < R.position.y or row.position.y > R.end.y:
			continue
		var owned: bool = Eco.has_upgrade(u["id"])
		Kit.frame(c, row, Kit.BG2, Kit.GOLD_D)
		Kit.icon_box(c, Rect2(row.position.x + 6.0, row.position.y + 8.0, 34, 34), Sprites.icon(u["icon"]), true)
		PixelFont.draw_text(c, String(u["name"]), row.position + Vector2(48, 6), 2, Kit.TEXT)
		var lines: Array[String] = PixelFont.wrap(String(u["desc"]), int(row.size.x - 48.0 - 140.0), 1)
		for li in range(mini(lines.size(), 2)):
			PixelFont.draw_text(c, lines[li], row.position + Vector2(48, 24.0 + float(li) * 10.0), 1, Kit.DIM)
		var br := Rect2(row.end.x - 130.0, row.position.y + 7.0, 124, 36)
		if owned:
			h.icon("check", Vector2(br.position.x + 10.0, br.position.y + 8.0), 1)
			PixelFont.draw_text(c, "КУПЛЕНО", Vector2(br.position.x + 34.0, br.position.y + 14.0), 1, Color(0.5, 0.9, 0.5))
		else:
			var uid: String = u["id"]
			h.btn(br, "КУПИТЬ", func() -> void: _buy_upgrade(uid), Kit.S_GREEN, Eco.coins() >= float(u["cost"]), Fmt.num(float(u["cost"])), "", 2)


func _buy_upgrade(id: String) -> void:
	if Eco.buy_upgrade(id):
		Sfx.play("buy")
	else:
		Sfx.play("error")


func _quests(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var y: float = _y0(h)
	var groups: Array = [["daily", "ЕЖЕДНЕВНЫЕ", Eco.secs_to_daily()], ["weekly", "ЕЖЕНЕДЕЛЬНЫЕ", Eco.secs_to_weekly()]]
	for g in groups:
		PixelFont.draw_text(c, String(g[0]) if false else String(g[1]), Vector2(R.position.x + 8.0, y + 2.0), 1, Kit.GOLD_L)
		PixelFont.draw_text_right(c, "ОБНОВЛЕНИЕ ЧЕРЕЗ " + Fmt.time(float(g[2])), R.end.x - 8.0, y + 2.0, 1, Kit.DIM)
		y += 14.0
		var arr: Array = Save.d["quests"][g[0]]
		for qi in range(arr.size()):
			var q: Dictionary = arr[qi]
			var row := Rect2(R.position.x + 2.0, y, R.size.x - 4.0, 38)
			Kit.frame(c, row, Kit.BG2, Kit.GOLD_D)
			PixelFont.draw_text(c, Eco.quest_text(q), row.position + Vector2(8, 6), 2, Kit.DIM if q["claimed"] else Kit.TEXT)
			var f: float = float(q["prog"]) / float(q["target"])
			Kit.bar(c, Rect2(row.position.x + 8.0, row.position.y + 25.0, 250, 7), f, Color(0.3, 0.7, 0.9))
			PixelFont.draw_text(c, Fmt.num(float(q["prog"])) + "/" + Fmt.num(float(q["target"])), row.position + Vector2(266, 25), 1, Kit.DIM)
			var rw: Dictionary = Eco.quest_reward(String(g[0]))
			var br := Rect2(row.end.x - 120.0, row.position.y + 4.0, 114, 30)
			if q["claimed"]:
				PixelFont.draw_text(c, "ПОЛУЧЕНО", Vector2(br.position.x + 22.0, br.position.y + 11.0), 1, Color(0.5, 0.9, 0.5))
			else:
				var grp: String = g[0]
				var idx: int = qi
				h.btn(br, "ЗАБРАТЬ", func() -> void: _claim(grp, idx), Kit.S_GREEN, Eco.quest_done(q), "+" + str(rw["points"]) + " ОЧК.", "", 1)
			y += 42.0
		y += 6.0


func _claim(group: String, idx: int) -> void:
	if Eco.claim_quest(group, idx):
		Sfx.play("claim")


func _menu(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var y: float = _y0(h) + 2.0
	var st: Dictionary = Save.d["stats"]
	var rows: Array = [
		["Побеждено врагов", st["kills"]], ["Побеждено боссов", st["bosses"]], ["Собрано монет", st["coin_pick"]],
		["Заработано монет", st["coins_total"]], ["Пройдено метров", st["distance_m"]], ["Осколков собрано", st["shards"]],
		["Сундуков открыто", st["chests"]], ["Разломов пройдено", st["portals"]], ["Прыжков", st["jumps"]], ["Перерождений", st["rebirths"]],
	]
	for r in rows:
		PixelFont.draw_text(c, String(r[0]), Vector2(R.position.x + 10.0, y), 1, Kit.DIM)
		PixelFont.draw_text_right(c, Fmt.num(float(r[1])), R.end.x - 140.0, y, 1, Kit.TEXT)
		y += 12.0
	var snd: bool = bool(Save.d["settings"]["sound"])
	h.btn(Rect2(R.end.x - 126.0, _y0(h) + 4.0, 118, 28), "ЗВУК: ВКЛ" if snd else "ЗВУК: ВЫКЛ", func() -> void: _toggle_sound(), Kit.S_GREEN if snd else Kit.S_GREY, true, "", "", 1)
	var armed: bool = Time.get_ticks_msec() / 1000.0 - _reset_arm < 3.0
	h.btn(Rect2(R.end.x - 126.0, _y0(h) + 40.0, 118, 28), "ТОЧНО? ЕЩЁ РАЗ" if armed else "СБРОС ИГРЫ", func() -> void: _reset(h), Kit.S_RED, true, "", "", 1)
	PixelFont.draw_text(c, "ОСКОЛКИ БЕЗДНЫ / ВЕРСИЯ 0.2", Vector2(R.position.x + 10.0, y + 10.0), 1, Kit.DIM)
	PixelFont.draw_text(c, "КЛАВИШИ: ПРОБЕЛ - ПРЫЖОК, X - ВЫСТРЕЛ, R - ЯРОСТЬ, B - ЛАВКА", Vector2(R.position.x + 10.0, y + 24.0), 1, Kit.DIM)


func _toggle_sound() -> void:
	Save.d["settings"]["sound"] = not bool(Save.d["settings"]["sound"])
	Save.save_game()


func _reset(h: Node2D) -> void:
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - _reset_arm < 3.0:
		Save.reset_all()
		Eco.recalc()
		Game.reset_run()
		h.close_panel()
		h.toast("ПРОГРЕСС СБРОШЕН", Kit.RED)
		_reset_arm = 0.0
	else:
		_reset_arm = now
