extends RefCounted
## Экран перерождения: сброс забега за очки Бездны, древо навыков (Свет/Тьма/Нечисть), достижения.

const Kit := preload("res://scripts/ui/ui_kit.gd")
const Fmt := preload("res://scripts/data/fmt.gd")
const GameData := preload("res://scripts/data/game_data.gd")
const SkillData := preload("res://scripts/data/skill_data.gd")
const Sprites := preload("res://scripts/gfx/sprites.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")

const TABS: Array = [["ПЕРЕРОЖД.", "flame"], ["ДРЕВО", "tree"], ["ДЕРЕВНЯ", "bag"], ["МИРЫ", "portal"], ["НАГРАДЫ", "trophy"]]

var tab: int = 0
var selected: String = ""
var _arm: float = 0.0
var _tree_init: bool = false
var _info_rect: Rect2


func on_open(h: Node2D) -> void:
	h.scroll = 0.0
	_tree_init = false


func _set_tab(h: Node2D, t: int) -> void:
	tab = t
	h.scroll = 0.0
	_tree_init = false


func draw(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var P: Rect2 = h.panel_rect()
	c.draw_rect(Rect2(Vector2.ZERO, h.view), Color(0, 0, 0, 0.6))
	Kit.frame(c, P, Color(0.06, 0.03, 0.12, 0.98), Kit.PURPLE.lightened(0.2))
	for i in range(TABS.size()):
		var r := Rect2(P.position.x + 8.0 + float(i) * 98.0, P.position.y + 7.0, 94, 26)
		var idx: int = i
		h.btn(r, TABS[i][0], func() -> void: _set_tab(h, idx), Kit.S_TAB_ON if tab == i else Kit.S_TAB, true, "", TABS[i][1], 1)
	h.btn(Rect2(P.end.x - 34.0, P.position.y + 7.0, 26, 26), "X", func() -> void: h.close_panel(), Kit.S_RED, true, "", "", 2)
	PixelFont.draw_text_right(c, "ОЧКИ: " + str(Eco.points_available()), P.end.x - 42.0, P.position.y + 8.0, 1, Color(0.85, 0.7, 1.0))
	PixelFont.draw_text_right(c, "ДУШИ: " + Fmt.num(Eco.souls()), P.end.x - 42.0, P.position.y + 20.0, 1, Color(0.8, 0.6, 1.0))
	var top: float = P.position.y + 40.0
	match tab:
		0:
			h.list_rect = Rect2()
			h.scroll_max = 0.0
			_rebirth(h, Rect2(P.position.x, top, P.size.x, P.end.y - top))
		1:
			var info_h: float = 58.0
			h.tree_rect = Rect2(P.position.x + 4.0, top, P.size.x - 8.0, P.end.y - top - info_h - 6.0)
			_info_rect = Rect2(P.position.x + 4.0, h.tree_rect.end.y + 2.0, P.size.x - 8.0, info_h)
			if not _tree_init:
				_tree_init = true
				h.tree_pan = Vector2.ZERO
			_tree_info(h)
		2:
			h.list_rect = Rect2(P.position.x + 4.0, top, P.size.x - 8.0, P.end.y - top - 6.0)
			h.scroll_max = maxf(0.0, float(GameData.VILLAGE.size()) * 54.0 + 26.0 - h.list_rect.size.y)
			h.scroll = clampf(h.scroll, 0.0, h.scroll_max)
		3:
			h.list_rect = Rect2(P.position.x + 4.0, top, P.size.x - 8.0, P.end.y - top - 6.0)
			h.scroll_max = maxf(0.0, float(GameData.DIMENSIONS.size()) * 64.0 + 24.0 - h.list_rect.size.y)
			h.scroll = clampf(h.scroll, 0.0, h.scroll_max)
		4:
			h.list_rect = Rect2(P.position.x + 4.0, top, P.size.x - 8.0, P.end.y - top - 6.0)
			h.scroll_max = maxf(0.0, float(GameData.ACHIEVEMENTS.size()) * 44.0 + 22.0 - h.list_rect.size.y)
			h.scroll = clampf(h.scroll, 0.0, h.scroll_max)


func draw_list(h: Node2D) -> void:
	if tab == 1:
		_tree(h)
	elif tab == 2:
		_village(h)
	elif tab == 3:
		_worlds(h)
	elif tab == 4:
		_achievements(h)


# ---------------------------------------------------------------- перерождение

func _rebirth(h: Node2D, R: Rect2) -> void:
	var c: CanvasItem = h.c
	var cx: float = R.position.x + R.size.x * 0.5
	var shards: float = float(Save.d["shards"])
	var pend: int = Eco.pending_points()
	PixelFont.draw_text_centered(c, "ОСКОЛКОВ В ЭТОМ ЗАБЕГЕ", cx, R.position.y + 6.0, 1, Kit.DIM)
	var gem: Texture2D = Sprites.get_tex("gem", 0)
	var s: String = Fmt.num(shards)
	var w: int = PixelFont.text_width(s, 2)
	c.draw_texture(gem, Vector2(cx - float(w + 22) * 0.5, R.position.y + 17.0))
	PixelFont.draw_text(c, s, Vector2(cx - float(w + 22) * 0.5 + 22.0, R.position.y + 20.0), 2, Color(0.55, 0.8, 1.0))
	PixelFont.draw_text_centered(c, "ОЧКОВ БЕЗДНЫ ЗА ПЕРЕРОЖДЕНИЕ", cx, R.position.y + 46.0, 1, Kit.DIM)
	PixelFont.draw_text_centered(c, "+" + str(pend), cx, R.position.y + 58.0, 4, Color(0.85, 0.65, 1.0) if pend > 0 else Kit.DIM)
	var lo: float = Eco.shards_for_points(pend)
	var hi: float = Eco.shards_for_points(pend + 1)
	Kit.bar(c, Rect2(cx - 120.0, R.position.y + 92.0, 240, 8), (shards - lo) / maxf(hi - lo, 1.0), Color(0.55, 0.35, 0.95))
	PixelFont.draw_text_centered(c, "ДО СЛЕДУЮЩЕГО ОЧКА: " + Fmt.num(maxf(hi - shards, 0.0)) + " ОСКОЛКОВ", cx, R.position.y + 104.0, 1, Kit.DIM)
	PixelFont.draw_text_centered(c, "ВСЕГО ОЧКОВ: " + str(int(Save.d["points_total"])) + "   ПОСТОЯННЫЙ БОНУС: ×" + Fmt.num(Eco.permanent_mult), cx, R.position.y + 122.0, 1, Kit.GOLD_L)
	PixelFont.draw_text_centered(c, "СБРАСЫВАЮТСЯ: МОНЕТЫ, СНАРЯЖЕНИЕ, БОНУСЫ, ОСКОЛКИ, ДИСТАНЦИЯ", cx, R.position.y + 140.0, 1, Kit.DIM)
	PixelFont.draw_text_centered(c, "ОСТАЮТСЯ: ОЧКИ, ДРЕВО НАВЫКОВ, ДОСТИЖЕНИЯ, ЗАДАНИЯ", cx, R.position.y + 152.0, 1, Kit.DIM)
	var armed: bool = Time.get_ticks_msec() / 1000.0 - _arm < 3.0
	var lbl: String = "НАЖМИТЕ ЕЩЁ РАЗ" if armed else "ПЕРЕРОДИТЬСЯ"
	h.btn(Rect2(cx - 100.0, R.position.y + 172.0, 200, 40), lbl, func() -> void: _do_rebirth(h), Kit.S_PURPLE if armed else Kit.S_GREEN, pend >= 1, "", "", 2)
	if pend < 1:
		PixelFont.draw_text_centered(c, "НУЖНО ХОТЯ БЫ 4 ОСКОЛКА (ОЧКО НА ЭТО)", cx, R.position.y + 218.0, 1, Kit.DIM)


func _do_rebirth(h: Node2D) -> void:
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - _arm < 3.0:
		_arm = 0.0
		Eco.rebirth()
	else:
		_arm = now


# ---------------------------------------------------------------- древо

func _node_screen(h: Node2D, n: Dictionary) -> Vector2:
	var T: Rect2 = h.tree_rect
	var origin: Vector2 = Vector2(T.position.x + T.size.x * 0.5, T.end.y - 22.0) + h.tree_pan
	return origin + (n["pos"] as Vector2) * Vector2(1.0, 1.0)


func _tree(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var T: Rect2 = h.tree_rect
	c.draw_rect(T, Color(0.03, 0.01, 0.06))
	# мерцающие точки фона
	for i in range(30):
		var p := Vector2(T.position.x + fmod(float(i) * 97.3, T.size.x), T.position.y + fmod(float(i) * 53.7, T.size.y))
		c.draw_rect(Rect2(p, Vector2(1, 1)), Color(0.4, 0.3, 0.6, 0.5))
	var nodes: Array[Dictionary] = SkillData.nodes()
	for n in nodes:
		var a: Vector2 = _node_screen(h, n)
		for pid in n["parents"]:
			var p: Dictionary = SkillData.get_node_data(String(pid))
			var b: Vector2 = _node_screen(h, p)
			var on: bool = Eco.has_skill(String(n["id"]))
			var col: Color = (n["color"] as Color) if on else Color(0.3, 0.25, 0.4)
			c.draw_line(a, b, col.darkened(0.5), 3.0)
			c.draw_line(a, b, col, 1.0)
	for n in nodes:
		var pos: Vector2 = _node_screen(h, n)
		var r := Rect2(pos - Vector2(10, 10), Vector2(20, 20))
		if not T.intersects(r):
			continue
		var id: String = n["id"]
		var owned: bool = Eco.has_skill(id)
		var can: bool = Eco.can_buy_skill(id)
		var col: Color = n["color"]
		c.draw_rect(r.grow(1.0), Color(0.02, 0.0, 0.03))
		if owned:
			c.draw_rect(r, col.darkened(0.2))
			c.draw_rect(r.grow(-3.0), col.lightened(0.3))
		elif can:
			c.draw_rect(r, col.darkened(0.5))
			c.draw_rect(r.grow(-3.0), Color(0.1, 0.05, 0.15))
			var pulse: float = 0.5 + 0.5 * sin(Time.get_ticks_msec() / 200.0)
			c.draw_rect(r.grow(-1.0), Color(col.r, col.g, col.b, 0.25 + 0.3 * pulse), false, 1.0)
		else:
			c.draw_rect(r, Color(0.15, 0.12, 0.2))
			c.draw_rect(r.grow(-3.0), Color(0.08, 0.06, 0.12))
		if selected == id:
			c.draw_rect(r.grow(3.0), Color.WHITE, false, 1.0)
		if id == "ROOT":
			c.draw_texture(Sprites.icon("star"), pos - Vector2(9, 9))
		elif not owned:
			PixelFont.draw_text_centered(c, str(n["cost"]), pos.x, pos.y - 3.0, 1, Kit.TEXT if can else Kit.DIM)
		h.hit_area(r.grow(2.0), func() -> void: _select(id))
	var names: Array = [["СВЕТ", -100.0, Color(1.0, 0.85, 0.35)], ["ТЬМА", 0.0, Color(1.0, 0.35, 0.3)], ["НЕЧИСТЬ", 100.0, Color(0.5, 1.0, 0.55)]]
	for nm in names:
		var o: Vector2 = _node_screen(h, {"pos": Vector2(float(nm[1]), 26.0)})
		PixelFont.draw_text_centered(c, String(nm[0]), o.x, o.y, 1, nm[2])


func _select(id: String) -> void:
	selected = id
	Sfx.play("click")


func _tree_info(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = _info_rect
	Kit.frame(c, R, Kit.BG2, Kit.PURPLE)
	if selected == "":
		PixelFont.draw_text(c, "НАЖМИТЕ НА УЗЕЛ. ТАЩИТЕ ПАЛЬЦЕМ, ЧТОБЫ СДВИНУТЬ ДРЕВО.", R.position + Vector2(8, 22), 1, Kit.DIM)
		return
	var n: Dictionary = SkillData.get_node_data(selected)
	if n.is_empty():
		return
	PixelFont.draw_text(c, String(n["name"]), R.position + Vector2(8, 8), 2, n["color"])
	var lines: Array[String] = PixelFont.wrap(String(n["desc"]), int(R.size.x - 160.0), 1)
	for i in range(mini(lines.size(), 3)):
		PixelFont.draw_text(c, lines[i], R.position + Vector2(8, 28.0 + float(i) * 10.0), 1, Kit.TEXT)
	var id: String = selected
	if Eco.has_skill(id):
		PixelFont.draw_text(c, "ИЗУЧЕНО", Vector2(R.end.x - 100.0, R.position.y + 22.0), 2, Color(0.5, 0.9, 0.5))
	else:
		var can: bool = Eco.can_buy_skill(id)
		var linked: bool = false
		for p in n["parents"]:
			if Eco.has_skill(String(p)):
				linked = true
		var sub: String = str(n["cost"]) + " ОЧК."
		h.btn(Rect2(R.end.x - 140.0, R.position.y + 10.0, 130, 38), "ИЗУЧИТЬ" if linked else "ЗАКРЫТО", func() -> void: _buy(id), Kit.S_PURPLE, can, sub, "", 2)


func _buy(id: String) -> void:
	if Eco.buy_skill(id):
		Sfx.play("buy")
	else:
		Sfx.play("error")


# ---------------------------------------------------------------- достижения

func _achievements(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var y: float = R.position.y - h.scroll
	PixelFont.draw_text(c, "КАЖДЫЙ УРОВЕНЬ: +2% К ДОХОДУ И МОНЕТАМ НАВСЕГДА (СЕЙЧАС +" + str(Eco.ach_tiers_total() * 2) + "%)", Vector2(R.position.x + 8.0, y + 4.0), 1, Kit.GOLD_L)
	y += 18.0
	for a in GameData.ACHIEVEMENTS:
		var row := Rect2(R.position.x + 2.0, y, R.size.x - 4.0, 40)
		y += 44.0
		if row.end.y < R.position.y or row.position.y > R.end.y:
			continue
		Kit.frame(c, row, Kit.BG2, Kit.GOLD_D)
		var tier: int = Eco.ach_tier(a)
		var tiers: Array = a["tiers"]
		var v: float = float(Save.d["stats"].get(a["stat"], 0.0))
		PixelFont.draw_text(c, String(a["name"]), row.position + Vector2(8, 6), 2, Kit.TEXT)
		var nxt: float = float(tiers[tier]) if tier < tiers.size() else float(tiers[tiers.size() - 1])
		var prev: float = float(tiers[tier - 1]) if tier > 0 else 0.0
		PixelFont.draw_text(c, String(a["text"]) + ": " + Fmt.num(v) + " / " + Fmt.num(nxt), row.position + Vector2(8, 24), 1, Kit.DIM)
		Kit.bar(c, Rect2(row.end.x - 170.0, row.position.y + 24.0, 100, 6), (v - prev) / maxf(nxt - prev, 1.0) if tier < tiers.size() else 1.0, Color(0.9, 0.7, 0.2))
		for i in range(tiers.size()):
			var px: float = row.end.x - 170.0 + float(i) * 12.0
			var col: Color = Kit.GOLD_L if i < tier else Color(0.22, 0.18, 0.26)
			c.draw_rect(Rect2(px, row.position.y + 8.0, 9, 9), Color(0.02, 0, 0.03))
			c.draw_rect(Rect2(px + 1.0, row.position.y + 9.0, 7, 7), col)


# ---------------------------------------------------------------- деревня

func _village(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var y: float = R.position.y - h.scroll
	PixelFont.draw_text(c, "ПОСТРОЙКИ РАБОТАЮТ ВЕЧНО. ДУШИ ДАЮТ БОССЫ, ГОЛЕМЫ, СУНДУКИ И ПЕРЕРОЖДЕНИЕ.", Vector2(R.position.x + 8.0, y + 4.0), 1, Color(0.8, 0.6, 1.0))
	y += 18.0
	for b in GameData.VILLAGE:
		var row := Rect2(R.position.x + 2.0, y, R.size.x - 4.0, 50)
		y += 54.0
		if row.end.y < R.position.y or row.position.y > R.end.y:
			continue
		var id: String = b["id"]
		var lv: int = Eco.village_level(id)
		Kit.frame(c, row, Kit.BG2, Color(0.5, 0.3, 0.7))
		Kit.icon_box(c, Rect2(row.position.x + 6.0, row.position.y + 8.0, 34, 34), Sprites.icon(b["icon"]), true)
		PixelFont.draw_text(c, String(b["name"]) + "  " + str(lv) + "/" + str(b["max"]), row.position + Vector2(48, 6), 2, Kit.TEXT)
		PixelFont.draw_text(c, String(b["desc"]), row.position + Vector2(48, 26), 1, Kit.DIM)
		PixelFont.draw_text(c, "СЕЙЧАС: +" + Fmt.num(float(b["per"]) * float(lv)) + ("" if String(b["key"]) == "offline_hours" else "%"), row.position + Vector2(48, 37), 1, Kit.GOLD_L)
		var br := Rect2(row.end.x - 130.0, row.position.y + 7.0, 124, 36)
		if lv >= int(b["max"]):
			PixelFont.draw_text(c, "МАКСИМУМ", Vector2(br.position.x + 28.0, br.position.y + 14.0), 1, Color(0.5, 0.9, 0.5))
		else:
			var cost: float = Eco.village_cost(b)
			h.btn(br, "ПОСТРОИТЬ", func() -> void: _buy_village(id), Kit.S_PURPLE, Eco.souls() >= cost, Fmt.num(cost) + " ДУШ", "", 1)


func _buy_village(id: String) -> void:
	if Eco.buy_village(id):
		Sfx.play("buy")
	else:
		Sfx.play("error")


# ---------------------------------------------------------------- измерения

func _worlds(h: Node2D) -> void:
	var c: CanvasItem = h.c
	var R: Rect2 = h.list_rect
	var y: float = R.position.y - h.scroll
	PixelFont.draw_text(c, "ИЗМЕРЕНИЯ ОТКРЫВАЮТСЯ ПЕРЕРОЖДЕНИЯМИ. МЕНЯЙТЕ МИР В ЛЮБОЙ МОМЕНТ.", Vector2(R.position.x + 8.0, y + 4.0), 1, Kit.GOLD_L)
	y += 18.0
	var tints: Array = [Color(0.9, 0.2, 0.2), Color(0.3, 0.9, 0.4), Color(0.4, 0.7, 1.0), Color(0.7, 0.35, 0.9)]
	for i in range(GameData.DIMENSIONS.size()):
		var d: Dictionary = GameData.DIMENSIONS[i]
		var row := Rect2(R.position.x + 2.0, y, R.size.x - 4.0, 60)
		y += 64.0
		if row.end.y < R.position.y or row.position.y > R.end.y:
			continue
		var unlocked: bool = Eco.dim_unlocked(i)
		var cur: bool = int(Save.d["dim"]) == i
		Kit.frame(c, row, Kit.BG2, tints[i] if unlocked else Color(0.3, 0.28, 0.34))
		c.draw_rect(Rect2(row.position.x + 6.0, row.position.y + 8.0, 44, 44), Color(0.02, 0, 0.03))
		c.draw_rect(Rect2(row.position.x + 7.0, row.position.y + 9.0, 42, 42), (tints[i] as Color).darkened(0.1) if unlocked else Color(0.15, 0.14, 0.18))
		if unlocked:
			c.draw_texture(Sprites.get_tex("portal", int(Time.get_ticks_msec() / 100.0)), Vector2(row.position.x + 17.0, row.position.y + 12.0))
		PixelFont.draw_text(c, String(d["name"]), row.position + Vector2(58, 8), 2, Kit.TEXT if unlocked else Kit.DIM)
		PixelFont.draw_text(c, String(d["desc"]), row.position + Vector2(58, 30), 1, Kit.GOLD_L if unlocked else Kit.DIM)
		if not unlocked:
			PixelFont.draw_text(c, "НУЖНО ПЕРЕРОЖДЕНИЙ: " + str(d["need"]) + " (У ВАС " + str(int(Save.d["stats"]["rebirths"])) + ")", row.position + Vector2(58, 42), 1, Kit.RED.lightened(0.3))
		else:
			var idx: int = i
			var br := Rect2(row.end.x - 130.0, row.position.y + 12.0, 124, 36)
			if cur:
				PixelFont.draw_text(c, "ВЫБРАНО", Vector2(br.position.x + 34.0, br.position.y + 14.0), 1, Color(0.5, 0.9, 0.5))
			else:
				h.btn(br, "ПЕРЕЙТИ", func() -> void: _go_dim(idx), Kit.S_PURPLE, true, "", "", 2)


func _go_dim(i: int) -> void:
	if Eco.set_dim(i):
		Sfx.play("portal")
