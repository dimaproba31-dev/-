extends Node
const Fmt := preload("res://scripts/data/fmt.gd")
const GameData := preload("res://scripts/data/game_data.gd")
const SkillData := preload("res://scripts/data/skill_data.gd")
## Корневая сцена игры. Пока только проверка окружения и dev-аргументы командной строки
## (используются для автоматической проверки сцены, игроку не нужны):
##   godot --path . -- --start-distance=7000 --shot=/tmp/a.png --shot-frame=90

var _autoplay: bool = false
var _loot_demo: bool = false
var _sim_secs: float = 600.0
var _sim_t: float = 0.0
var _sim_next_log: float = 0.0
var _sim_think: float = 0.0
var _sim_rebirths: int = 0
var _sim_buy_enabled: bool = true


func _ready() -> void:
	var v: Dictionary = Engine.get_version_info()
	print("[Осколки Бездны] Godot %s.%s.%s (%s), рендерер: %s" % [
			v["major"], v["minor"], v["patch"], v["status"],
			ProjectSettings.get_setting("rendering/renderer/rendering_method")])
	var sub: SubViewport = $PixelView/PixelWorld
	sub.canvas_transform = Transform2D(0.0, Vector2.ONE / float(Game.PIXEL), 0.0, Vector2.ZERO)
	_update_view()
	_apply_dev_args()
	if _loot_demo:
		Save.disabled = true
		var ld: Node2D = preload("res://scripts/play/loot_demo.gd").new()
		$PixelView/PixelWorld/World.add_child(ld)


func _process(delta: float) -> void:
	_update_view()
	var sub: SubViewport = $PixelView/PixelWorld
	var off := Vector2(randf_range(-1.0, 1.0), randf_range(-1.0, 1.0)) * Game.shake
	sub.canvas_transform = Transform2D(0.0, Vector2.ONE / float(Game.PIXEL), 0.0, off.round())
	if _autoplay:
		_autoplay_tick(delta)


## Мир рисуется в SubViewport в 1/PIXEL разрешении; логические координаты слоёв остаются прежними.
func _update_view() -> void:
	var sub: SubViewport = $PixelView/PixelWorld
	if sub.size.x > 0:
		Game.view_size = Vector2(sub.size) * float(Game.PIXEL)


func _apply_dev_args() -> void:
	var shot_path: String = ""
	var shot_frame: int = 60
	for a in OS.get_cmdline_user_args():
		if a.begins_with("--start-distance="):
			Game.distance = float(a.get_slice("=", 1))
		elif a.begins_with("--cheat-coins="):
			Save.d["coins"] = float(a.get_slice("=", 1))
		elif a.begins_with("--cheat-shards="):
			Save.d["shards"] = float(a.get_slice("=", 1))
		elif a.begins_with("--cheat-points="):
			Save.d["points_total"] = int(a.get_slice("=", 1))
		elif a.begins_with("--cheat-equip="):
			var parts: PackedStringArray = a.get_slice("=", 1).split(",")
			for i in range(parts.size()):
				(Save.d["equip"] as Array)[i] = int(parts[i])
			Eco.recalc()
		elif a.begins_with("--cheat-souls="):
			Save.d["souls"] = float(a.get_slice("=", 1))
		elif a.begins_with("--cheat-rebirths="):
			Save.d["stats"]["rebirths"] = float(a.get_slice("=", 1))
		elif a.begins_with("--dim="):
			Save.d["dim"] = int(a.get_slice("=", 1))
		elif a.begins_with("--minigame="):
			_mini_later(a.get_slice("=", 1))
		elif a == "--loot-demo":
			_loot_demo = true
		elif a == "--sprint":
			Game.sprint_touch = true
		elif a.begins_with("--cheat-rage"):
			Save.d["rage"] = 1.0
		elif a.begins_with("--autoplay"):
			_autoplay = true
		elif a.begins_with("--sim-secs="):
			_sim_secs = float(a.get_slice("=", 1))
		elif a.begins_with("--time-scale="):
			Engine.time_scale = float(a.get_slice("=", 1))
			Game.base_ts = Engine.time_scale
		elif a.begins_with("--spawn="):
			_spawn_later(a.get_slice("=", 1))
		elif a.begins_with("--test-ui"):
			Save.disabled = true
			_ui_test()
		elif a.begins_with("--tour"):
			Save.disabled = true
			_autoplay = true
			_tour()
		elif a.begins_with("--open="):
			_open_later(a.get_slice("=", 1))
		elif a.begins_with("--click="):
			_click_later(a.get_slice("=", 1))
		elif a.begins_with("--shot="):
			shot_path = a.get_slice("=", 1)
		elif a.begins_with("--shot-frame="):
			shot_frame = int(a.get_slice("=", 1))
	if shot_path != "":
		Save.disabled = true
		_take_shot_later(shot_path, shot_frame)


## Dev: имитация нажатия мышью. Формат --click=x,y,кадр (логические координаты).
func _click_later(spec: String) -> void:
	var parts: PackedStringArray = spec.split(",")
	for i in range(int(parts[2])):
		await get_tree().process_frame
	var pos := Vector2(float(parts[0]), float(parts[1]))
	for pressed in [true, false]:
		var ev := InputEventMouseButton.new()
		ev.button_index = MOUSE_BUTTON_LEFT
		ev.pressed = pressed
		ev.position = pos
		Input.parse_input_event(ev)
		await get_tree().process_frame
	print("[dev] click at ", pos)


func _take_shot_later(path: String, frames: int) -> void:
	for i in range(frames):
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	var img: Image = get_viewport().get_texture().get_image()
	img.save_png(path)
	print("[dev] screenshot: %s (%dx%d)" % [path, img.get_width(), img.get_height()])
	get_tree().quit()


func _open_later(spec: String) -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	var hud: Node = get_tree().root.find_child("Counters", true, false)
	if hud == null:
		return
	var parts: PackedStringArray = spec.split(":")
	hud.call("open_panel", parts[0])
	if parts.size() > 1:
		var pn: Object = hud.get("_shop") if parts[0] == "shop" else hud.get("_asc")
		pn.set("tab", int(parts[1]))


## Dev: автоигра для проверки баланса. Умеет прыгать, покупать выгодное снаряжение и перерождаться.
func _autoplay_tick(delta: float) -> void:
	_sim_t += delta
	_sim_think -= delta
	if _sim_think <= 0.0:
		_sim_think = 0.45
		if Game.hero != null and randf() < 0.55:
			Game.hero.call("request_jump")
		if _sim_buy_enabled:
			_sim_buy()
	if _sim_t >= _sim_next_log:
		_sim_next_log += 60.0
		var lv: Array = Save.d["equip"]
		print("[sim] t=%4.0fм coins=%s income=%s/с lv=%s upg=%d shards=%s pend=%d pts=%d reb=%d m=%.0f" % [
			_sim_t / 60.0, Fmt.num(Eco.coins()), Fmt.num(Eco.income), str(lv), (Save.d["upg"] as Array).size(),
			Fmt.num(float(Save.d["shards"])), Eco.pending_points(), int(Save.d["points_total"]), _sim_rebirths, Game.meters()])
	if _sim_t >= _sim_secs:
		get_tree().quit()


func _sim_buy() -> void:
	for u in GameData.UPGRADES:
		if Eco.buy_upgrade(u["id"]):
			pass
	# выгода: доход на монету
	var best: int = -1
	var best_ratio: float = 0.0
	for i in range(GameData.EQUIPMENT.size()):
		var cost: float = Eco.item_cost(i, 1)
		var gain: float = float(GameData.EQUIPMENT[i]["base_income"]) * Eco.income_mult()
		var r: float = gain / cost
		if r > best_ratio:
			best_ratio = r
			best = i
	if best >= 0:
		var n: int = Eco.max_affordable(best)
		if n > 0:
			Eco.buy_equip(best, -1)
	# навыки
	for n2 in SkillData.nodes():
		if Eco.can_buy_skill(String(n2["id"])):
			Eco.buy_skill(String(n2["id"]))
	if Eco.pending_points() >= maxi(3, int(Save.d["points_total"]) / 2 + 3) and Game.distance > 20000.0:
		_sim_rebirths += 1
		Eco.rebirth()


func _spawn_later(spec: String) -> void:
	for i in range(30):
		await get_tree().process_frame
	var layer: Node = get_tree().root.find_child("Entities", true, false)
	var sp: RefCounted = layer.get("_spawner")
	for fn in spec.split(","):
		if fn == "bonus":
			Game.enter_bonus(12.0)
		elif fn == "gallery":
			Game.enter_bonus(12.0, "gallery")
		elif fn == "rage":
			Save.d["rage"] = 1.0
			Game.start_rage()
		else:
			sp.call(fn)


func _click(p: Vector2) -> void:
	var d := InputEventMouseButton.new()
	d.button_index = MOUSE_BUTTON_LEFT
	d.pressed = true
	d.position = p
	Input.parse_input_event(d)
	await get_tree().process_frame
	var u := InputEventMouseButton.new()
	u.button_index = MOUSE_BUTTON_LEFT
	u.pressed = false
	u.position = p
	Input.parse_input_event(u)
	await get_tree().process_frame
	await get_tree().process_frame


func _ui_test() -> void:
	for i in range(40):
		await get_tree().process_frame
	var hud: Node = get_tree().root.find_child("Counters", true, false)
	Save.d["coins"] = 1000.0
	await _click(Vector2(1220, 48))
	print("[test] открыта лавка: ", hud.get("panel") == "shop")
	await _click(Vector2(1092, 202))
	print("[test] куплен 1 ур. клинка: ", Eco.level(0) == 1, " монеты=", Save.d["coins"])
	await _click(Vector2(1198, 68))
	print("[test] лавка закрыта: ", hud.get("panel") == "")
	var y0: float = Game.hero.position.y
	var peak: float = 0.0
	_click(Vector2(600, 300))
	for i in range(25):
		await get_tree().process_frame
		peak = maxf(peak, y0 - Game.hero.position.y)
	print("[test] прыжок по тапу, высота=", peak)
	Save.d["coins"] = 1e6
	await _click(Vector2(1220, 48))
	await _click(Vector2(300, 68))
	print("[test] вкладка бонусов: ", (hud.get("_shop") as RefCounted).get("tab") == 1)
	await _click(Vector2(1092, 158))
	print("[test] куплен двойной прыжок: ", Eco.has_upgrade("u_double"))
	get_tree().quit()


func _mini_later(kind: String) -> void:
	for i in range(40):
		await get_tree().process_frame
	Game.minigame.emit(kind)


func _wait(frames: int) -> void:
	for i in range(frames):
		await get_tree().process_frame


## Dev: сценарий для видеоролика (запускать с --write-movie --fixed-fps 30).
func _tour() -> void:
	var hud: Node = null
	await _wait(5)
	hud = get_tree().root.find_child("Counters", true, false)
	Save.d["souls"] = 40.0
	Save.d["stats"]["rebirths"] = 7.0
	Save.d["points_total"] = 14
	Save.d["coins"] = 2500.0
	var layer: Node = get_tree().root.find_child("Entities", true, false)
	var sp: RefCounted = layer.get("_spawner")
	_sim_buy_enabled = false
	await _wait(150)
	Save.d["rage"] = 1.0
	Game.start_rage()
	await _wait(180)
	Save.d["coins"] = 60000.0
	hud.call("open_panel", "shop")
	await _wait(75)
	for i in range(3):
		Eco.buy_equip(i + 1, 5)
		Sfx.play("buy")
		await _wait(12)
	(hud.get("_shop") as RefCounted).set("tab", 1)
	await _wait(60)
	Eco.buy_upgrade("u_double")
	Eco.buy_upgrade("u_magnet")
	await _wait(30)
	(hud.get("_shop") as RefCounted).set("tab", 2)
	await _wait(60)
	hud.call("close_panel")
	await _wait(10)
	sp.call("spawn_boss")
	await _wait(210)
	Game.enter_bonus(12.0, "gallery")
	await _wait(150)
	hud.call("open_panel", "ascend")
	(hud.get("_asc") as RefCounted).set("tab", 0)
	await _wait(60)
	(hud.get("_asc") as RefCounted).set("tab", 1)
	await _wait(60)
	(hud.get("_asc") as RefCounted).set("tab", 2)
	await _wait(60)
	Eco.buy_village("forge")
	Eco.buy_village("market")
	await _wait(45)
	(hud.get("_asc") as RefCounted).set("tab", 3)
	await _wait(60)
	Eco.set_dim(2)
	await _wait(30)
	hud.call("close_panel")
	await _wait(120)
	Game.minigame.emit("chests")
	await _wait(60)
	(hud.get("_mini") as RefCounted).call("_pick", hud, 1)
	await _wait(60)
	hud.call("close_panel")
	Eco.set_dim(1)
	await _wait(120)
	get_tree().quit()
