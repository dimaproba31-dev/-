extends Node2D
## HUD и модальные панели. Рисуется «вручную» (immediate mode) в пикселях арта поверх пиксельного SubViewport.
## Кнопки регистрируются во время отрисовки; ввод приходит через InputRouter.ui_handler.

const PixelFont := preload("res://scripts/hud/pixel_font.gd")
const Fmt := preload("res://scripts/data/fmt.gd")
const Kit := preload("res://scripts/ui/ui_kit.gd")
const Sprites := preload("res://scripts/gfx/sprites.gd")
const ZoneData := preload("res://scripts/world/zone_data.gd")
const ClipLayer := preload("res://scripts/ui/clip_layer.gd")
const ShopPanel := preload("res://scripts/ui/panel_shop.gd")
const AscendPanel := preload("res://scripts/ui/panel_ascend.gd")
const MiniPanel := preload("res://scripts/ui/panel_mini.gd")

const GOLD := Kit.GOLD

var view: Vector2 = Vector2(640, 360)
var c: CanvasItem                       ## куда сейчас рисуют кнопки и текст
var panel: String = ""                  ## "", "shop", "ascend"
var list_rect: Rect2 = Rect2()
var scroll: float = 0.0
var scroll_max: float = 0.0
var tree_rect: Rect2 = Rect2()
var tree_pan: Vector2 = Vector2.ZERO
var tree_drag_cb: Callable = Callable()
var list_cb: Callable = Callable()

var _btns: Array = []
var _btns_next: Array = []
var _press: Dictionary = {}
var _press_pos: Vector2 = Vector2.ZERO
var _drag: int = 0           ## 0 — нет, 1 — возможный, 2 — тащим
var _drag_acc: float = 0.0
var _toasts: Array[Dictionary] = []
var _banner: Dictionary = {}
var _shop: RefCounted
var _asc: RefCounted
var _mini: RefCounted
var _list_layer: Node2D
var _top_layer: Node2D
var _offline_open: bool = false
var _tut_t: float = 0.0
var _shard_pulse: float = 0.0
var _t: float = 0.0


func _ready() -> void:
	_shop = ShopPanel.new()
	_asc = AscendPanel.new()
	_mini = MiniPanel.new()
	Game.minigame.connect(_on_minigame)
	_list_layer = ClipLayer.new()
	_top_layer = Node2D.new()
	_top_layer.set_script(preload("res://scripts/ui/top_layer.gd"))   # скрипт — до входа в дерево, иначе _process не включается
	_top_layer.set("hud", self)
	add_child(_list_layer)
	add_child(_top_layer)
	InputRouter.ui_handler = Callable(self, "_on_input")
	InputRouter.menu_pressed.connect(func() -> void: toggle("shop"))
	InputRouter.back_pressed.connect(func() -> void: close_panel())
	Eco.toast.connect(func(text: String, col: Color) -> void: toast(text, col))
	Eco.rebirth_done.connect(_on_rebirth)
	Game.zone_changed.connect(func(_i: int, n: String) -> void: banner("ЗОНА: " + n))
	Game.rage_started.connect(func() -> void: banner("ЯРОСТЬ!", Color(1.0, 0.35, 0.25)))
	if Eco.offline_gain > 0.0:
		_offline_open = true
		Game.ui_open = true


func toast(text: String, col: Color = Kit.TEXT) -> void:
	_toasts.append({"text": text, "col": col, "t": 0.0})
	if _toasts.size() > 4:
		_toasts.pop_front()


func banner(text: String, col: Color = Kit.GOLD_L) -> void:
	_banner = {"text": text, "col": col, "t": 0.0}


func _on_rebirth(pts: int) -> void:
	close_panel()
	banner("ПЕРЕРОЖДЕНИЕ! +" + str(pts) + " ОЧК.", Color(0.8, 0.5, 1.0))
	Sfx.play("rebirth")


func _on_minigame(kind: String) -> void:
	if panel != "":
		return
	if kind == "chests":
		_mini.start()
		panel = "mini"
		scroll = 0.0
		Game.ui_open = true


func toggle(name: String) -> void:
	if panel == name:
		close_panel()
	else:
		open_panel(name)


func open_panel(name: String) -> void:
	panel = name
	scroll = 0.0
	Game.ui_open = true
	Sfx.play("click")
	if name == "shop":
		_shop.on_open(self)
	else:
		_asc.on_open(self)


func close_panel() -> void:
	if panel == "" and not _offline_open:
		return
	panel = ""
	_offline_open = false
	Game.ui_open = false
	list_rect = Rect2()
	tree_rect = Rect2()


func panel_rect() -> Rect2:
	var w: float = minf(600.0, view.x - 16.0)
	return Rect2(roundf((view.x - w) * 0.5), 14.0, w, view.y - 28.0)


# ---------------------------------------------------------------- кнопки

func btn(r: Rect2, label: String, cb: Callable, style: int = 0, enabled: bool = true, sub: String = "", icon: String = "", scale: int = 2) -> void:
	var tex: Texture2D = Sprites.icon(icon) if icon != "" else null
	var pressed: bool = not _press.is_empty() and (_press["r"] as Rect2) == r and _drag != 2
	Kit.button(c, r, label, style, enabled, pressed, sub, tex, scale)
	_btns_next.append({"r": r, "cb": cb, "en": enabled, "clip": _cur_clip()})


func _cur_clip() -> Rect2:
	if c == self or c == _top_layer:
		return Rect2()
	return list_rect if list_rect.size.x > 0.0 else tree_rect


func hit_area(r: Rect2, cb: Callable) -> void:
	_btns_next.append({"r": r, "cb": cb, "en": true, "clip": _cur_clip()})


func text(s: String, pos: Vector2, scale: int = 1, col: Color = Kit.TEXT) -> void:
	PixelFont.draw_text(c, s, pos, scale, col)


func text_c(s: String, cx: float, y: float, scale: int = 1, col: Color = Kit.TEXT) -> void:
	PixelFont.draw_text_centered(c, s, cx, y, scale, col)


func text_r(s: String, rx: float, y: float, scale: int = 1, col: Color = Kit.TEXT) -> void:
	PixelFont.draw_text_right(c, s, rx, y, scale, col)


func icon(name: String, pos: Vector2, scale: int = 1) -> void:
	var t: Texture2D = Sprites.icon(name)
	c.draw_texture_rect(t, Rect2(pos, t.get_size() * float(scale)), false)


func _on_input(kind: String, pos: Vector2, extra: Variant) -> bool:
	var modal: bool = panel != "" or _offline_open
	match kind:
		"down":
			_press = {}
			_drag = 0
			_drag_acc = 0.0
			for i in range(_btns.size() - 1, -1, -1):
				var b: Dictionary = _btns[i]
				var clip: Rect2 = b["clip"]
				if clip.size.x > 0.0 and not clip.has_point(pos):
					continue
				if bool(b["en"]) and (b["r"] as Rect2).has_point(pos):
					_press = b
					_press_pos = pos
					break
			if _press.is_empty() and not modal:
				return false
			if list_rect.has_point(pos) or tree_rect.has_point(pos):
				_drag = 1
			return true
		"move":
			if _drag == 0:
				return false
			var rel: Vector2 = extra as Vector2
			_drag_acc += rel.length()
			if _drag == 1 and _drag_acc > 3.0:
				_drag = 2
				_press = {}
			if _drag == 2:
				if tree_rect.has_point(pos) and tree_rect.size.x > 0.0:
					tree_pan += rel
				else:
					scroll = clampf(scroll - rel.y, 0.0, scroll_max)
			return true
		"up":
			var p: Dictionary = _press
			_press = {}
			_drag = 0
			if not p.is_empty() and (p["r"] as Rect2).has_point(pos):
				Sfx.play("click")
				(p["cb"] as Callable).call()
			return true
		"wheel":
			if modal:
				scroll = clampf(scroll + float(extra) * 24.0, 0.0, scroll_max)
				return true
	return false


# ---------------------------------------------------------------- цикл

func _process(delta: float) -> void:
	_t += delta
	view = Game.view_size / float(Game.PIXEL)
	for t in _toasts:
		t["t"] = float(t["t"]) + delta
	_toasts = _toasts.filter(func(t: Dictionary) -> bool: return float(t["t"]) < 3.0)
	if not _banner.is_empty():
		_banner["t"] = float(_banner["t"]) + delta
		if float(_banner["t"]) > 2.4:
			_banner = {}
	if not Save.d["tutorial_done"] and not Game.ui_open:
		_tut_t += delta
		if _tut_t > 14.0 or float(Save.d["stats"]["jumps"]) >= 6.0 and _tut_t > 4.0:
			Save.d["tutorial_done"] = true
	queue_redraw()


func _draw() -> void:
	_btns = _btns_next
	_btns_next = []
	c = self
	list_rect = Rect2()
	tree_rect = Rect2()
	list_cb = Callable()
	_draw_hud()
	if panel == "shop":
		_shop.draw(self)
	elif panel == "ascend":
		_asc.draw(self)
	elif panel == "mini":
		_mini.draw(self)
	_list_layer.set("clip_rect", list_rect if list_rect.size.x > 0.0 else tree_rect)
	_list_layer.set("draw_cb", Callable(self, "_draw_list"))


func _draw_list(layer: CanvasItem) -> void:
	c = layer
	if panel == "shop":
		_shop.draw_list(self)
	elif panel == "ascend":
		_asc.draw_list(self)
	c = self


## Верхний слой: тосты, баннер, окно офлайн-дохода (вызывается из top_layer.gd).
func draw_top(layer: CanvasItem) -> void:
	c = layer
	var y: float = 56.0
	for t in _toasts:
		var a: float = clampf(3.0 - float(t["t"]), 0.0, 0.5) * 2.0
		var col: Color = t["col"]
		col.a = a
		PixelFont.draw_text_centered(layer, String(t["text"]), view.x * 0.5, y, 1, col)
		y += 11.0
	if not _banner.is_empty():
		var bt: float = float(_banner["t"])
		var a2: float = clampf(minf(bt * 4.0, (2.4 - bt) * 3.0), 0.0, 1.0)
		var bc: Color = _banner["col"]
		bc.a = a2
		var sc: int = 3
		var ty: float = 84.0 - (1.0 - clampf(bt * 5.0, 0.0, 1.0)) * 10.0
		PixelFont.draw_text_centered(layer, String(_banner["text"]), view.x * 0.5, ty, sc, bc)
	if _offline_open:
		_draw_offline(layer)
	c = self


func _draw_offline(layer: CanvasItem) -> void:
	layer.draw_rect(Rect2(Vector2.ZERO, view), Color(0, 0, 0, 0.6))
	var r := Rect2(view.x * 0.5 - 150.0, 80.0, 300.0, 180.0)
	Kit.frame(layer, r)
	PixelFont.draw_text_centered(layer, "С ВОЗВРАЩЕНИЕМ!", r.position.x + 150.0, r.position.y + 14.0, 2, Kit.GOLD_L)
	PixelFont.draw_text_centered(layer, "ВАС НЕ БЫЛО " + Fmt.time(Eco.offline_secs), r.position.x + 150.0, r.position.y + 44.0, 1, Kit.TEXT)
	PixelFont.draw_text_centered(layer, "СНАРЯЖЕНИЕ ПРИНЕСЛО:", r.position.x + 150.0, r.position.y + 70.0, 1, Kit.DIM)
	var coin: Texture2D = Sprites.get_tex("coin", 0)
	var s: String = "+" + Fmt.num(Eco.offline_gain)
	var w: int = PixelFont.text_width(s, 2)
	var x0: float = r.position.x + 150.0 - float(w + 20) * 0.5
	layer.draw_texture(coin, Vector2(x0, r.position.y + 84.0))
	PixelFont.draw_text(layer, s, Vector2(x0 + 20.0, r.position.y + 88.0), 2, Kit.GOLD_L)
	PixelFont.draw_text_centered(layer, "ОФЛАЙН-ДОХОД: 50% ОТ ОБЫЧНОГО", r.position.x + 150.0, r.position.y + 114.0, 1, Kit.DIM)
	var br := Rect2(r.position.x + 90.0, r.position.y + 134.0, 120.0, 30.0)
	c = layer
	btn(br, "ОТЛИЧНО", func() -> void: close_panel(), Kit.S_GREEN)


# ---------------------------------------------------------------- HUD

func _draw_hud() -> void:
	var coin: Texture2D = Sprites.get_tex("coin", int(_t * 8.0))
	c.draw_texture(coin, Vector2(6, 5))
	text(Fmt.num(Eco.coins()), Vector2(30, 6), 2, Kit.GOLD_L)
	text("+" + Fmt.num(Eco.income) + "/С", Vector2(31, 24), 1, Kit.DIM)
	# осколки и прогресс очков перерождения
	var gem: Texture2D = Sprites.get_tex("gem", int(_t * 6.0))
	c.draw_texture(gem, Vector2(7, 36))
	var shards: float = float(Save.d["shards"])
	text(Fmt.num(shards), Vector2(30, 37), 1, Color(0.55, 0.8, 1.0))
	var pend: int = Eco.pending_points()
	var lo: float = Eco.shards_for_points(pend)
	var hi: float = Eco.shards_for_points(pend + 1)
	var f: float = clampf((shards - lo) / maxf(hi - lo, 1.0), 0.0, 1.0)
	Kit.bar(c, Rect2(30, 48, 90, 5), f, Color(0.5, 0.35, 0.9))
	text("ОЧКИ: " + str(pend), Vector2(124, 46), 1, Color(0.8, 0.65, 1.0))
	c.draw_texture(Sprites.icon("skull"), Vector2(6, 57), )
	text(Fmt.num(Eco.souls()), Vector2(30, 62), 1, Color(0.8, 0.6, 1.0))
	# зона и дистанция
	var zname: String = String(ZoneData.zones()[Game.zone_index]["name"])
	text_c(zname, view.x * 0.5, 6, 1, Kit.TEXT)
	text_c(Fmt.num(Game.meters()) + " М", view.x * 0.5, 17, 1, Kit.DIM)
	if Game.bonus_active:
		Kit.bar(c, Rect2(view.x * 0.5 - 40.0, 28, 80, 5), Game.bonus_left / 12.0, Color(0.85, 0.5, 1.0))
		text_c("ТИР: БЕЙ ЛЕТУЧИХ МЫШЕЙ!" if Game.bonus_kind == "gallery" else "ДОЖДЬ МОНЕТ!", view.x * 0.5, 36, 1, Color(0.9, 0.7, 1.0))
	# кнопки справа сверху
	var bx: float = view.x - 8.0
	var shop_r := Rect2(bx - 44.0, 6, 44, 36)
	btn(shop_r, "", func() -> void: toggle("shop"), Kit.S_GOLD, true, "", "bag")
	var badge: int = Eco.affordable_upgrades() + Eco.claimable_quests()
	if badge > 0:
		c.draw_rect(Rect2(shop_r.end.x - 11, shop_r.position.y - 2, 12, 12), Color(0.02, 0, 0.03))
		c.draw_rect(Rect2(shop_r.end.x - 10, shop_r.position.y - 1, 10, 10), Kit.RED)
		text_c(str(mini(badge, 9)), shop_r.end.x - 5.0, shop_r.position.y + 1.0, 1, Color.WHITE)
	var asc_r := Rect2(bx - 94.0, 6, 44, 36)
	var can_reb: bool = Eco.pending_points() >= 1 or int(Save.d["points_total"]) > 0
	if can_reb:
		btn(asc_r, "", func() -> void: toggle("ascend"), Kit.S_PURPLE, true, "", "tree")
		if Eco.points_available() > 0:
			c.draw_rect(Rect2(asc_r.end.x - 11, asc_r.position.y - 2, 12, 12), Color(0.02, 0, 0.03))
			c.draw_rect(Rect2(asc_r.end.x - 10, asc_r.position.y - 1, 10, 10), Kit.GREEN)
			text_c(str(mini(Eco.points_available(), 9)), asc_r.end.x - 5.0, asc_r.position.y + 1.0, 1, Color.WHITE)
	_draw_rage()
	_draw_fast_attack()
	_draw_char_switch()
	_draw_tutorial()
	if Game.rage_active:
		var a: float = 0.10 + 0.05 * sin(_t * 12.0)
		c.draw_rect(Rect2(0, 0, view.x, 3), Color(1, 0.2, 0.1, a * 3.0))
		c.draw_rect(Rect2(0, view.y - 3, view.x, 3), Color(1, 0.2, 0.1, a * 3.0))


func _draw_rage() -> void:
	var rg: float = float(Save.d["rage"])
	var r := Rect2(view.x - 60.0, view.y - 60.0, 52, 52)
	var ready: bool = rg >= 1.0 and not Game.rage_active
	var fill: float = Game.rage_left / maxf(Eco.rage_duration(), 0.01) if Game.rage_active else rg
	c.draw_rect(r, Color(0.02, 0.0, 0.03))
	c.draw_rect(r.grow(-1.0), Color(0.14, 0.04, 0.08))
	var h: float = (r.size.y - 4.0) * clampf(fill, 0.0, 1.0)
	var col: Color = Color(1.0, 0.55, 0.15) if (ready or Game.rage_active) else Color(0.75, 0.2, 0.18)
	if ready:
		col = col.lerp(Color(1, 0.9, 0.4), 0.5 + 0.5 * sin(_t * 9.0))
	c.draw_rect(Rect2(r.position.x + 2.0, r.end.y - 2.0 - h, r.size.x - 4.0, h), col)
	var ic: Texture2D = Sprites.icon("flame")
	c.draw_texture_rect(ic, Rect2(r.position + Vector2(8, 8), ic.get_size() * 2.0 - Vector2(2, 2)), false)
	c.draw_rect(Rect2(r.position, Vector2(r.size.x, 1)), GOLD)
	c.draw_rect(Rect2(r.position.x, r.end.y - 1.0, r.size.x, 1.0), GOLD)
	c.draw_rect(Rect2(r.position, Vector2(1, r.size.y)), GOLD)
	c.draw_rect(Rect2(r.end.x - 1.0, r.position.y, 1.0, r.size.y), GOLD)
	text_c("ЯРОСТЬ", r.position.x + r.size.x * 0.5, r.position.y - 9.0, 1, Kit.GOLD_L if ready else Kit.DIM)
	if panel == "" or panel == "mini":
		pass
	if panel == "":
		hit_area(r, func() -> void: Game.start_rage())


## Кнопка «быстрые удары»: видна только в бою с боссом, включается и выключается нажатием.
func _draw_fast_attack() -> void:
	if not Game.boss_lock:
		return
	var r := Rect2(view.x - 124.0, view.y - 60.0, 52, 52)
	var on: bool = Game.fast_attack
	c.draw_rect(r, Color(0.02, 0.0, 0.03))
	c.draw_rect(r.grow(-1.0), Color(0.45, 0.12, 0.06) if on else Color(0.14, 0.04, 0.08))
	if on:
		c.draw_rect(r.grow(-3.0), Color(1.0, 0.55, 0.15, 0.35 + 0.2 * sin(_t * 10.0)))
	var ic: Texture2D = Sprites.icon("sword")
	c.draw_texture_rect(ic, Rect2(r.position + Vector2(8, 8), ic.get_size() * 2.0 - Vector2(2, 2)), false)
	c.draw_rect(Rect2(r.position, Vector2(r.size.x, 1)), GOLD)
	c.draw_rect(Rect2(r.position.x, r.end.y - 1.0, r.size.x, 1.0), GOLD)
	c.draw_rect(Rect2(r.position, Vector2(1, r.size.y)), GOLD)
	c.draw_rect(Rect2(r.end.x - 1.0, r.position.y, 1.0, r.size.y), GOLD)
	text_c("БЫСТРО", r.position.x + r.size.x * 0.5, r.position.y - 9.0, 1, Kit.GOLD_L if on else Kit.DIM)
	if panel == "":
		hit_area(r, func() -> void:
			Game.fast_attack = not Game.fast_attack
			Sfx.play("click"))


## Переключатель персонажа: Странник / Дух косы.
func _draw_char_switch() -> void:
	if panel != "" or Game.boss_lock or Game.hero == null:
		return
	var r := Rect2(6.0, 76.0, 60.0, 14.0)
	c.draw_rect(r, Color(0.02, 0.0, 0.03, 0.85))
	c.draw_rect(Rect2(r.position, Vector2(r.size.x, 1)), GOLD)
	var spirit: bool = int(Save.d.get("char", 1)) == 1
	text_c("ДУХ КОСЫ" if spirit else "СТРАННИК", r.position.x + r.size.x * 0.5, r.position.y + 4.0, 1, Kit.GOLD_L)
	hit_area(r, func() -> void:
		Game.hero.call("set_character", 0 if spirit else 1)
		Save.save_game()
		Sfx.play("click"))


func _draw_tutorial() -> void:
	if bool(Save.d["tutorial_done"]) or Game.ui_open:
		return
	var a: float = clampf(_tut_t * 1.5, 0.0, 1.0) * clampf((14.0 - _tut_t) * 0.8, 0.0, 1.0)
	var col := Color(1, 1, 1, a)
	text_c("ТАП - ПРЫЖОК", view.x * 0.5, 120.0, 2, Color(1.0, 0.9, 0.5, a))
	text_c("ТАП ПО ВРАГУ - ВЫСТРЕЛ / МЕЧ БЬЁТ САМ", view.x * 0.5, 142.0, 1, col)
	text_c("ЗАБИРАЙ МОНЕТЫ, ПОКУПАЙ СНАРЯЖЕНИЕ В СУМКЕ", view.x * 0.5, 154.0, 1, col)
