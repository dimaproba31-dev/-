extends RefCounted
## Встроенный пиксельный шрифт 5×7: цифры, русский и латинский алфавит (заглавные), знаки.
## Все глифы собираются в атлас-текстуры при первом обращении; текст рисуется по одной
## текстурной области на букву (быстро, без внешних файлов шрифта).

const SPEC: String = """
AА|01110_10001_10001_11111_10001_10001_10001
Б|11111_10000_10000_11110_10001_10001_11110
BВ|11110_10001_10001_11110_10001_10001_11110
Г|11111_10000_10000_10000_10000_10000_10000
Д|00111_01001_01001_01001_01001_11111_10001
EЕ|11111_10000_10000_11110_10000_10000_11111
Ё|01010_11111_10000_11110_10000_10000_11111
Ж|10101_10101_10101_01110_10101_10101_10101
З|01110_10001_00001_00110_00001_10001_01110
И|10001_10001_10011_10101_11001_10001_10001
Й|01010_10001_10011_10101_11001_10001_10001
KК|10001_10010_10100_11000_10100_10010_10001
Л|00111_01001_01001_01001_01001_01001_10001
MМ|10001_11011_10101_10101_10001_10001_10001
HН|10001_10001_10001_11111_10001_10001_10001
OО|01110_10001_10001_10001_10001_10001_01110
П|11111_10001_10001_10001_10001_10001_10001
PР|11110_10001_10001_11110_10000_10000_10000
CС|01110_10001_10000_10000_10000_10001_01110
TТ|11111_00100_00100_00100_00100_00100_00100
У|10001_10001_10001_01111_00001_10001_01110
Ф|00100_01110_10101_10101_01110_00100_00100
XХ|10001_10001_01010_00100_01010_10001_10001
Ц|10010_10010_10010_10010_10010_11111_00001
Ч|10001_10001_10001_01111_00001_00001_00001
Ш|10101_10101_10101_10101_10101_10101_11111
Щ|10101_10101_10101_10101_10101_11111_00001
Ъ|11000_01000_01000_01110_01001_01001_01110
Ы|10001_10001_10001_11001_10101_10101_11001
Ь|10000_10000_10000_11110_10001_10001_11110
Э|01110_10001_00001_00111_00001_10001_01110
Ю|10010_10101_10101_11101_10101_10101_10010
Я|01111_10001_10001_01111_00101_01001_10001
D|11110_10001_10001_10001_10001_10001_11110
F|11111_10000_11110_10000_10000_10000_10000
G|01110_10001_10000_10111_10001_10001_01111
I|01110_00100_00100_00100_00100_00100_01110
J|00111_00010_00010_00010_00010_10010_01100
L|10000_10000_10000_10000_10000_10000_11111
N|10001_11001_10101_10011_10001_10001_10001
Q|01110_10001_10001_10001_10101_10010_01101
R|11110_10001_10001_11110_10100_10010_10001
S|01111_10000_10000_01110_00001_00001_11110
U|10001_10001_10001_10001_10001_10001_01110
V|10001_10001_10001_10001_10001_01010_00100
W|10001_10001_10001_10101_10101_11011_10001
Y|10001_10001_01010_00100_00100_00100_00100
Z|11111_00001_00010_00100_01000_10000_11111
0|01110_10001_10011_10101_11001_10001_01110
1|00100_01100_00100_00100_00100_00100_01110
2|01110_10001_00001_00010_00100_01000_11111
3|11110_00001_00001_01110_00001_00001_11110
4|00010_00110_01010_10010_11111_00010_00010
5|11111_10000_11110_00001_00001_10001_01110
6|00110_01000_10000_11110_10001_10001_01110
7|11111_00001_00010_00100_01000_01000_01000
8|01110_10001_10001_01110_10001_10001_01110
9|01110_10001_10001_01111_00001_00010_01100
.|00_00_00_00_00_11_11
,|00_00_00_00_11_01_10
:|0_1_1_0_1_1_0
!|1_1_1_1_1_0_1
?|01110_10001_00001_00110_00100_00000_00100
-|00000_00000_00000_11111_00000_00000_00000
+|00000_00100_00100_11111_00100_00100_00000
/|00001_00001_00010_00100_01000_10000_10000
%|11001_11010_00010_00100_01000_01011_10011
(|00010_00100_01000_01000_01000_00100_00010
)|01000_00100_00010_00010_00010_00100_01000
=|00000_00000_11111_00000_11111_00000_00000
>|10000_01000_00100_00010_00100_01000_10000
<|00001_00010_00100_01000_00100_00010_00001
*|00000_10101_01110_11111_01110_10101_00000
×|00000_10001_01010_00100_01010_10001_00000
'|1_1_0_0_0_0_0
"""

const GLYPH_H: int = 7
const SPACE_W: int = 3

static var _glyphs: Dictionary = {}     # символ -> Array[String] строки
static var _cells: Dictionary = {}      # символ -> Rect2 в атласе (с полем 1 px)
static var _fill: ImageTexture
static var _outline: ImageTexture


static func _ensure() -> void:
	if not _glyphs.is_empty():
		return
	for line in SPEC.split("\n", false):
		var parts: PackedStringArray = line.split("|")
		if parts.size() != 2:
			continue
		var rows: Array = Array(parts[1].split("_"))
		for i in range(parts[0].length()):
			_glyphs[parts[0][i]] = rows
	var aw: int = 512
	var x: int = 0
	var y: int = 0
	var cell_h: int = GLYPH_H + 2
	var total: int = 0
	for ch in _glyphs.keys():
		total += String((_glyphs[ch] as Array)[0]).length() + 2
	var ah: int = (int(ceil(float(total) / float(aw))) + 2) * cell_h
	var fill_img: Image = Image.create_empty(aw, ah, false, Image.FORMAT_RGBA8)
	var out_img: Image = Image.create_empty(aw, ah, false, Image.FORMAT_RGBA8)
	for ch in _glyphs.keys():
		var rows2: Array = _glyphs[ch]
		var gw: int = String(rows2[0]).length()
		if x + gw + 2 > aw:
			x = 0
			y += cell_h
		_cells[ch] = Rect2(x, y, gw + 2, cell_h)
		for ry in range(GLYPH_H):
			var row: String = rows2[ry]
			for rx in range(gw):
				if row[rx] != "1":
					continue
				fill_img.set_pixel(x + 1 + rx, y + 1 + ry, Color.WHITE)
				for oy in range(-1, 2):
					for ox in range(-1, 2):
						out_img.set_pixel(x + 1 + rx + ox, y + 1 + ry + oy, Color.WHITE)
		x += gw + 2
	_fill = ImageTexture.create_from_image(fill_img)
	_outline = ImageTexture.create_from_image(out_img)


static func glyph_width(ch: String) -> int:
	_ensure()
	if ch == " ":
		return SPACE_W
	if not _glyphs.has(ch):
		return 0
	return String((_glyphs[ch] as Array)[0]).length()


## Ширина текста в пикселях арта при масштабе scale.
static func text_width(text: String, scale: int = 1) -> int:
	_ensure()
	var up: String = text.to_upper()
	var w: int = 0
	for i in range(up.length()):
		var gw: int = glyph_width(up[i])
		if gw > 0:
			w += (gw + 1) * scale
	return maxi(0, w - scale)


## Рисует текст с обводкой. pos — левый верх (единицы CanvasItem). outline.a = 0 отключает обводку.
static func draw_text(ci: CanvasItem, text: String, pos: Vector2, scale: int = 1, color: Color = Color.WHITE, outline: Color = Color(0.05, 0.02, 0.06)) -> void:
	_ensure()
	var up: String = text.to_upper()
	var passes: int = 2 if outline.a > 0.0 else 1
	for pass_i in range(passes):
		var tex: Texture2D = _outline if (pass_i == 0 and passes == 2) else _fill
		var mod: Color = outline if (pass_i == 0 and passes == 2) else color
		var cx: float = pos.x
		for i in range(up.length()):
			var ch: String = up[i]
			if ch == " ":
				cx += float((SPACE_W + 1) * scale)
				continue
			if not _cells.has(ch):
				continue
			var r: Rect2 = _cells[ch]
			ci.draw_texture_rect_region(tex, Rect2(Vector2(cx - float(scale), pos.y - float(scale)), r.size * float(scale)), r, mod)
			cx += (r.size.x - 1.0) * float(scale)


static func draw_text_centered(ci: CanvasItem, text: String, center_x: float, y: float, scale: int = 1, color: Color = Color.WHITE, outline: Color = Color(0.05, 0.02, 0.06)) -> void:
	draw_text(ci, text, Vector2(floorf(center_x - float(text_width(text, scale)) * 0.5), y), scale, color, outline)


static func draw_text_right(ci: CanvasItem, text: String, right_x: float, y: float, scale: int = 1, color: Color = Color.WHITE, outline: Color = Color(0.05, 0.02, 0.06)) -> void:
	draw_text(ci, text, Vector2(right_x - float(text_width(text, scale)), y), scale, color, outline)


## Перенос по словам под заданную ширину (в пикселях арта).
static func wrap(text: String, max_w: int, scale: int = 1) -> Array[String]:
	var lines: Array[String] = []
	var cur: String = ""
	for word in text.split(" ", false):
		var trial: String = word if cur == "" else cur + " " + word
		if text_width(trial, scale) <= max_w or cur == "":
			cur = trial
		else:
			lines.append(cur)
			cur = word
	if cur != "":
		lines.append(cur)
	return lines


## Рисует спрайт из строк; palette: символ → Color, '.' пусто.
static func draw_sprite(ci: CanvasItem, rows: Array, palette: Dictionary, pos: Vector2, scale: int = 1) -> void:
	for y in range(rows.size()):
		var row: String = rows[y]
		for x in range(row.length()):
			var ch: String = row[x]
			if ch == ".":
				continue
			ci.draw_rect(Rect2(pos + Vector2(x * scale, y * scale), Vector2(scale, scale)), palette[ch])
