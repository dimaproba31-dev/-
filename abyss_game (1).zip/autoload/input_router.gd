extends Node
## Единая точка ввода. Клавиатура, мышь и сенсорный экран превращаются в сигналы и в вызовы UI.
## UI регистрирует ui_handler(kind, pos_px, extra) -> bool: true — событие съедено интерфейсом.
## Координаты для UI — в пикселях арта, для игры — логические.

signal jump_pressed
signal jump_released
signal shoot_pressed
signal rage_pressed
signal menu_pressed
signal back_pressed
signal pointer_pressed(pos: Vector2)    ## нажатие мимо интерфейса (логические координаты)

var ui_handler: Callable = Callable()
var _ui_captured: bool = false
var _touch_index: int = -1
var _holding_jump: bool = false


func _key_jump(ev: InputEventKey) -> bool:
	return ev.physical_keycode == KEY_SPACE or ev.physical_keycode == KEY_W or ev.physical_keycode == KEY_UP


func _input(event: InputEvent) -> void:
	if event is InputEventKey:
		var k := event as InputEventKey
		if k.echo:
			return
		if _key_jump(k):
			if k.pressed:
				jump_pressed.emit()
			else:
				jump_released.emit()
		elif k.pressed:
			match k.physical_keycode:
				KEY_X, KEY_Z, KEY_J:
					shoot_pressed.emit()
				KEY_R, KEY_SHIFT:
					rage_pressed.emit()
				KEY_ESCAPE:
					back_pressed.emit()
				KEY_B, KEY_TAB:
					menu_pressed.emit()
		return
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_LEFT:
			_pointer(mb.pressed, mb.position)
		elif mb.pressed and (mb.button_index == MOUSE_BUTTON_WHEEL_UP or mb.button_index == MOUSE_BUTTON_WHEEL_DOWN):
			var dir: float = -1.0 if mb.button_index == MOUSE_BUTTON_WHEEL_UP else 1.0
			_call_ui("wheel", mb.position, dir)
	elif event is InputEventMouseMotion:
		var mm := event as InputEventMouseMotion
		if mm.button_mask & MOUSE_BUTTON_MASK_LEFT:
			_call_ui("move", mm.position, mm.relative / float(Game.PIXEL))
	elif event is InputEventScreenTouch:
		var st := event as InputEventScreenTouch
		if st.pressed and _touch_index == -1:
			_touch_index = st.index
			_pointer(true, st.position)
		elif not st.pressed and st.index == _touch_index:
			_touch_index = -1
			_pointer(false, st.position)
	elif event is InputEventScreenDrag:
		var sd := event as InputEventScreenDrag
		if sd.index == _touch_index:
			_call_ui("move", sd.position, sd.relative / float(Game.PIXEL))


func _pointer(pressed: bool, pos: Vector2) -> void:
	if pressed:
		_ui_captured = _call_ui("down", pos, null)
		if not _ui_captured:
			pointer_pressed.emit(pos)
			_holding_jump = true
	else:
		if _ui_captured:
			_call_ui("up", pos, null)
		_ui_captured = false
		if _holding_jump:
			_holding_jump = false
			jump_released.emit()


func _call_ui(kind: String, pos: Vector2, extra: Variant) -> bool:
	if ui_handler.is_valid():
		return bool(ui_handler.call(kind, pos / float(Game.PIXEL), extra))
	return false
