extends Node

const PetData := preload("res://scripts/data/pet_data.gd")
## Экономика и мета-прогресс: доход, цены, улучшения, перерождение, задания, достижения.
## Всё считается из Save.d; результаты кэшируются в recalc().

const GameData := preload("res://scripts/data/game_data.gd")
const SkillData := preload("res://scripts/data/skill_data.gd")
const Fmt := preload("res://scripts/data/fmt.gd")

signal toast(text: String, color: Color)
signal rebirth_done(points: int)
signal changed

var income: float = 0.0          ## пассивный доход, монет/с
var m: Dictionary = {}           ## суммы бонусов по ключам
var auto_interval: float = 0.0   ## интервал авто-лука, 0 — выключен
var permanent_mult: float = 1.0  ## бонус очков и достижений
var offline_gain: float = 0.0
var offline_secs: float = 0.0

var _acc: float = 0.0


func _ready() -> void:
	ensure_quests()
	recalc()
	_apply_offline()


func _process(delta: float) -> void:
	var gain: float = income * delta
	if gain > 0.0:
		add_coins(gain, false)
	_acc += delta
	if _acc >= 0.5:
		_acc = 0.0
		ensure_quests()
		recalc()


# ---------------------------------------------------------------- расчёты

func level(i: int) -> int:
	return int((Save.d["equip"] as Array)[i])


static func milestone_mult(lv: int) -> float:
	var mult: float = 1.0
	for ms in GameData.MILESTONES:
		if lv >= ms:
			mult *= 2.0
	return mult


func item_income(i: int) -> float:
	var lv: int = level(i)
	var e: Dictionary = GameData.EQUIPMENT[i]
	return float(e["base_income"]) * float(lv) * milestone_mult(lv) * income_mult()


const GOLD_HARD: float = 0.6   ## множитель сложности добычи золота


func income_mult() -> float:
	return dim_data()["income"] * (1.0 + (float(m.get("income_pct", 0.0)) + float(m.get("all_pct", 0.0))) / 100.0) * permanent_mult * GOLD_HARD


func recalc() -> void:
	m.clear()
	auto_interval = 0.0
	for id in Save.d["skills"]:
		var n: Dictionary = SkillData.get_node_data(String(id))
		if n.is_empty() or String(n["key"]) == "":
			continue
		_add_effect(String(n["key"]), float(n["val"]))
	for id in Save.d["upg"]:
		for u in GameData.UPGRADES:
			if u["id"] == id:
				_add_effect(String(u["key"]), float(u["val"]))
	for b in GameData.VILLAGE:
		var lv: int = village_level(String(b["id"]))
		if lv > 0:
			_add_effect(String(b["key"]), float(b["per"]) * float(lv))
	var pi: int = int(Save.d["pet"])
	if pi >= 0 and pi < (Save.d["pets"] as Array).size():
		var pr: int = int(((Save.d["pets"] as Array)[pi] as Array)[1])
		var pb: float = float(PetData.RARITIES[pr]["bonus"])
		_add_effect("coin_pct", pb)
		_add_effect("income_pct", pb)
	var tiers: int = ach_tiers_total()
	permanent_mult = 1.0 + 0.02 * float(int(Save.d["points_total"])) + 0.02 * float(tiers)
	var total: float = 0.0
	for i in range(GameData.EQUIPMENT.size()):
		total += item_income(i)
	income = total
	changed.emit()


func _add_effect(key: String, val: float) -> void:
	if key == "auto_bolt":
		auto_interval = val if auto_interval == 0.0 else minf(auto_interval, val)
	elif key == "double_jump":
		m[key] = 1.0
	else:
		m[key] = float(m.get(key, 0.0)) + val


func zone_number() -> int:
	return int(floor(Game.distance / Game.ZoneData.ZONE_LENGTH))


func zone_mult() -> float:
	return 1.0 + 0.15 * float(zone_number())


func coin_value() -> float:
	var v: float = float(dim_data()["coin"]) * (1.0 + income * 0.2) * (1.0 + float(m.get("coin_pct", 0.0)) / 100.0) * zone_mult() * (1.0 + 0.02 * float(int(Save.d["points_total"])) + 0.02 * float(ach_tiers_total())) * GOLD_HARD
	if Game.rage_active:
		v *= 2.0 * (1.0 + float(m.get("rage_coin", 0.0)) / 100.0)
	return v


func shard_mult() -> float:
	return (1.0 + float(m.get("shard_pct", 0.0)) / 100.0) * float(dim_data()["shard"])


func hit_damage() -> float:
	var power: float = float(level(0) + level(5))
	return (10.0 + 2.0 * power) * (1.0 + float(m.get("dmg_pct", 0.0)) / 100.0)


func shoot_cooldown() -> float:
	return 0.22 * maxf(0.2, 1.0 - float(m.get("shoot_cd_pct", 0.0)) / 100.0)


func melee_range() -> float:
	return 70.0 + float(m.get("melee_range", 0.0))


func magnet_radius() -> float:
	return 30.0 + float(m.get("magnet", 0.0))


func has_double_jump() -> bool:
	return float(m.get("double_jump", 0.0)) > 0.0


func jump_mult() -> float:
	return 1.0 + float(m.get("jump_pct", 0.0)) / 100.0


func speed_mult() -> float:
	return 1.0 + float(m.get("speed_pct", 0.0)) / 100.0


func rage_duration() -> float:
	return 10.0 + float(m.get("rage_dur", 0.0))


func rage_gain_mult() -> float:
	return 1.0 + float(m.get("rage_gain", 0.0)) / 100.0


func boss_mult() -> float:
	return 1.0 + float(m.get("boss_pct", 0.0)) / 100.0


func chest_weight() -> float:
	return 1.0 + float(m.get("chest_pct", 0.0)) / 100.0


func portal_weight() -> float:
	return 1.0 + float(m.get("portal_pct", 0.0)) / 100.0


func offline_cap_hours() -> float:
	return 4.0 + float(m.get("offline_hours", 0.0))


# ---------------------------------------------------------------- деревня, души, измерения

func dim_data() -> Dictionary:
	return GameData.DIMENSIONS[clampi(int(Save.d["dim"]), 0, GameData.DIMENSIONS.size() - 1)]


func dim_unlocked(i: int) -> bool:
	return float(Save.d["stats"]["rebirths"]) >= float(GameData.DIMENSIONS[i]["need"])


func set_dim(i: int) -> bool:
	if i < 0 or i >= GameData.DIMENSIONS.size() or not dim_unlocked(i):
		return false
	Save.d["dim"] = i
	recalc()
	return true


func souls() -> float:
	return float(Save.d["souls"])


func add_souls(v: float) -> void:
	v *= float(dim_data()["soul"])
	Save.d["souls"] = souls() + v


func village_level(id: String) -> int:
	return int((Save.d["village"] as Dictionary).get(id, 0))


func village_cost(b: Dictionary) -> float:
	return roundf(float(b["base"]) * pow(float(b["growth"]), float(village_level(String(b["id"])))))


func buy_village(id: String) -> bool:
	for b in GameData.VILLAGE:
		if b["id"] == id:
			var lv: int = village_level(id)
			var cost: float = village_cost(b)
			if lv >= int(b["max"]) or souls() < cost:
				return false
			Save.d["souls"] = souls() - cost
			(Save.d["village"] as Dictionary)[id] = lv + 1
			recalc()
			return true
	return false


# ---------------------------------------------------------------- деньги и статистика

func add_coins(v: float, count_stat: bool = true) -> void:
	Save.d["coins"] = minf(float(Save.d["coins"]) + v, 1e300)
	var st: Dictionary = Save.d["stats"]
	st["coins_total"] = float(st["coins_total"]) + v


func add_shards(v: float) -> void:
	Save.d["shards"] = float(Save.d["shards"]) + v
	var st: Dictionary = Save.d["stats"]
	st["shards"] = float(st["shards"]) + v


func coins() -> float:
	return float(Save.d["coins"])


func event(key: String, amount: float = 1.0) -> void:
	var st: Dictionary = Save.d["stats"]
	var stat_key: String = key
	match key:
		"kill": stat_key = "kills"
		"boss": stat_key = "bosses"
		"chest": stat_key = "chests"
		"portal": stat_key = "portals"
		"buy": stat_key = "items"
		"jump": stat_key = "jumps"
	if st.has(stat_key):
		st[stat_key] = float(st[stat_key]) + amount
	var q: Dictionary = Save.d["quests"]
	for group in ["daily", "weekly"]:
		for entry in q[group]:
			var tpl: Dictionary = _template(String(entry["tpl"]))
			if not tpl.is_empty() and tpl["event"] == key and not entry["claimed"]:
				entry["prog"] = minf(float(entry["prog"]) + amount, float(entry["target"]))


# ---------------------------------------------------------------- снаряжение

func item_cost(i: int, n: int) -> float:
	var e: Dictionary = GameData.EQUIPMENT[i]
	var g: float = float(e["growth"])
	return float(e["base_cost"]) * pow(g, float(level(i))) * (pow(g, float(n)) - 1.0) / (g - 1.0)


func max_affordable(i: int) -> int:
	var e: Dictionary = GameData.EQUIPMENT[i]
	var g: float = float(e["growth"])
	var first: float = float(e["base_cost"]) * pow(g, float(level(i)))
	if coins() < first:
		return 0
	var n: int = int(floor(log(1.0 + coins() * (g - 1.0) / first) / log(g)))
	while n > 0 and item_cost(i, n) > coins():
		n -= 1
	return maxi(n, 0)


## n = -1 — «Макс». Возвращает число купленных уровней.
func buy_equip(i: int, n: int) -> int:
	var count: int = max_affordable(i) if n < 0 else n
	if count < 1:
		return 0
	var cost: float = item_cost(i, count)
	if cost > coins():
		return 0
	Save.d["coins"] = coins() - cost
	(Save.d["equip"] as Array)[i] = level(i) + count
	event("buy", float(count))
	recalc()
	return count


# ---------------------------------------------------------------- улучшения

func has_upgrade(id: String) -> bool:
	return (Save.d["upg"] as Array).has(id)


func buy_upgrade(id: String) -> bool:
	for u in GameData.UPGRADES:
		if u["id"] == id:
			if has_upgrade(id) or coins() < float(u["cost"]):
				return false
			Save.d["coins"] = coins() - float(u["cost"])
			(Save.d["upg"] as Array).append(id)
			recalc()
			return true
	return false


func affordable_upgrades() -> int:
	var c: int = 0
	for u in GameData.UPGRADES:
		if not has_upgrade(u["id"]) and coins() >= float(u["cost"]):
			c += 1
	return c


# ---------------------------------------------------------------- очки и перерождение

func points_available() -> int:
	return int(Save.d["points_total"]) - int(Save.d["points_spent"])


func pending_points() -> int:
	var p: float = sqrt(float(Save.d["shards"]) / 4.0) * (1.0 + float(m.get("points_pct", 0.0)) / 100.0)
	return int(floor(p))


## Осколков, нужных для следующего очка.
func shards_for_points(p: int) -> float:
	var mult: float = 1.0 + float(m.get("points_pct", 0.0)) / 100.0
	var x: float = float(p) / mult
	return x * x * 4.0


func has_skill(id: String) -> bool:
	return id == "ROOT" or (Save.d["skills"] as Array).has(id)


func can_buy_skill(id: String) -> bool:
	var n: Dictionary = SkillData.get_node_data(id)
	if n.is_empty() or has_skill(id) or points_available() < int(n["cost"]):
		return false
	for p in n["parents"]:
		if has_skill(String(p)):
			return true
	return false


func buy_skill(id: String) -> bool:
	if not can_buy_skill(id):
		return false
	var n: Dictionary = SkillData.get_node_data(id)
	Save.d["points_spent"] = int(Save.d["points_spent"]) + int(n["cost"])
	(Save.d["skills"] as Array).append(id)
	recalc()
	return true


func rebirth() -> int:
	var pts: int = pending_points()
	if pts < 1:
		return 0
	Save.d["points_total"] = int(Save.d["points_total"]) + pts
	add_souls(float(pts) * 1.5 + 2.0)
	var st: Dictionary = Save.d["stats"]
	st["rebirths"] = float(st["rebirths"]) + 1.0
	Save.d["last_income"] = income
	Save.d["coins"] = 0.0
	Save.d["shards"] = 0.0
	Save.d["equip"] = [0, 0, 0, 0, 0, 0, 0, 0]
	Save.d["upg"] = []
	Save.d["rage"] = 0.0
	Game.reset_run()
	recalc()
	var start_secs: float = float(m.get("start_coins", 0.0))
	if start_secs > 0.0:
		Save.d["coins"] = float(Save.d["last_income"]) * start_secs * 0.1
	Save.save_game()
	rebirth_done.emit(pts)
	return pts


# ---------------------------------------------------------------- достижения

func ach_tier(a: Dictionary) -> int:
	var v: float = float((Save.d["stats"] as Dictionary).get(a["stat"], 0.0))
	var t: int = 0
	for th in a["tiers"]:
		if v >= float(th):
			t += 1
	return t


func ach_tiers_total() -> int:
	var t: int = 0
	for a in GameData.ACHIEVEMENTS:
		t += ach_tier(a)
	return t


# ---------------------------------------------------------------- задания

func _template(id: String) -> Dictionary:
	for t in GameData.QUEST_TEMPLATES:
		if t["id"] == id:
			return t
	return {}


func ensure_quests() -> void:
	var now: float = Time.get_unix_time_from_system()
	var day: int = int(now / 86400.0)
	var week: int = int((now - 4.0 * 86400.0) / 604800.0)
	var q: Dictionary = Save.d["quests"]
	if int(q["day"]) != day or (q["daily"] as Array).is_empty():
		q["day"] = day
		q["daily"] = _gen_quests(3, "daily")
	if int(q["week"]) != week or (q["weekly"] as Array).is_empty():
		q["week"] = week
		q["weekly"] = _gen_quests(2, "weekly")


func _gen_quests(count: int, kind: String) -> Array:
	var pool: Array = GameData.QUEST_TEMPLATES.duplicate()
	pool.shuffle()
	var out: Array = []
	for i in range(count):
		var t: Dictionary = pool[i]
		var rng_range: Array = t[kind]
		var target: int = randi_range(int(rng_range[0]), int(rng_range[1]))
		if target >= 100:
			target = int(round(float(target) / 10.0)) * 10
		elif target >= 20:
			target = int(round(float(target) / 5.0)) * 5
		out.append({"tpl": t["id"], "target": target, "prog": 0.0, "claimed": false})
	return out


func quest_text(entry: Dictionary) -> String:
	var t: Dictionary = _template(String(entry["tpl"]))
	return String(t["text"]) % Fmt.num(float(entry["target"]))


func quest_reward(group: String) -> Dictionary:
	return {"points": 1 if group == "daily" else 3, "coin_secs": 600.0 if group == "daily" else 3600.0}


func quest_done(entry: Dictionary) -> bool:
	return float(entry["prog"]) >= float(entry["target"])


func claim_quest(group: String, idx: int) -> bool:
	var arr: Array = Save.d["quests"][group]
	if idx < 0 or idx >= arr.size():
		return false
	var entry: Dictionary = arr[idx]
	if entry["claimed"] or not quest_done(entry):
		return false
	entry["claimed"] = true
	var rw: Dictionary = quest_reward(group)
	Save.d["points_total"] = int(Save.d["points_total"]) + int(rw["points"])
	add_coins(maxf(income, 10.0) * float(rw["coin_secs"]))
	recalc()
	return true


func secs_to_daily() -> float:
	var now: float = Time.get_unix_time_from_system()
	return (float(Save.d["quests"]["day"]) + 1.0) * 86400.0 - now


func secs_to_weekly() -> float:
	var now: float = Time.get_unix_time_from_system()
	return (float(Save.d["quests"]["week"]) + 1.0) * 604800.0 + 4.0 * 86400.0 - now


func claimable_quests() -> int:
	var c: int = 0
	for group in ["daily", "weekly"]:
		for e in Save.d["quests"][group]:
			if not e["claimed"] and quest_done(e):
				c += 1
	return c


# ---------------------------------------------------------------- офлайн

func _apply_offline() -> void:
	var last: float = float(Save.d["last_time"])
	if last <= 0.0 or not Save.loaded_existing:
		return
	var secs: float = Time.get_unix_time_from_system() - last
	if secs < 60.0:
		return
	secs = minf(secs, offline_cap_hours() * 3600.0)
	offline_secs = secs
	offline_gain = income * secs * 0.5
	if offline_gain > 0.0:
		add_coins(offline_gain)
