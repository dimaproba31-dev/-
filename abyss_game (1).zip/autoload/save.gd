extends Node
## Хранение прогресса в user://abyss_save.json. Данные лежат в словаре d.
## Автосохранение раз в 15 секунд, при сворачивании и закрытии игры.

const PATH: String = "user://abyss_save.json"
const VERSION: int = 1

var d: Dictionary = {}
var loaded_existing: bool = false
var disabled: bool = false   ## dev: не писать на диск
var _timer: float = 0.0


static func defaults() -> Dictionary:
	return {
		"v": VERSION,
		"coins": 0.0,
		"shards": 0.0,
		"points_total": 0,
		"points_spent": 0,
		"souls": 0.0,
		"village": {},
		"dim": 0,
		"equip": [0, 0, 0, 0, 0, 0, 0, 0],
		"pets": [],
		"pet": -1,
		"upg": [],
		"skills": [],
		"stats": {"kills": 0.0, "coins_total": 0.0, "distance_m": 0.0, "bosses": 0.0, "rebirths": 0.0, "shards": 0.0,
				"chests": 0.0, "portals": 0.0, "items": 0.0, "rage": 0.0, "jumps": 0.0, "coin_pick": 0.0},
		"quests": {"day": -1, "week": -1, "daily": [], "weekly": []},
		"settings": {"sound": true},
		"rage": 0.0,
		"distance": 0.0,
		"last_time": 0.0,
		"last_income": 0.0,
		"tutorial_done": false,
	}


func _ready() -> void:
	load_game()


func _process(delta: float) -> void:
	_timer += delta
	if _timer >= 15.0:
		_timer = 0.0
		save_game()


func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED or what == NOTIFICATION_APPLICATION_FOCUS_OUT:
		save_game()


func load_game() -> void:
	d = defaults()
	if FileAccess.file_exists(PATH):
		var f: FileAccess = FileAccess.open(PATH, FileAccess.READ)
		if f != null:
			var parsed: Variant = JSON.parse_string(f.get_as_text())
			if parsed is Dictionary:
				_merge(d, parsed as Dictionary)
				loaded_existing = true
	# JSON хранит числа как float — приводим целочисленные поля
	var eq: Array = d["equip"]
	for i in range(eq.size()):
		eq[i] = int(eq[i])
	while eq.size() < 8:
		eq.append(0)
	d["points_total"] = int(d["points_total"])
	d["points_spent"] = int(d["points_spent"])


func save_game() -> void:
	if disabled:
		return
	d["last_time"] = Time.get_unix_time_from_system()
	d["distance"] = Game.distance
	var f: FileAccess = FileAccess.open(PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(d))


func reset_all() -> void:
	d = defaults()
	Game.reset_run()
	save_game()


## Рекурсивно переносит значения из src в dst, сохраняя новые поля по умолчанию.
func _merge(dst: Dictionary, src: Dictionary) -> void:
	for k in src.keys():
		if dst.has(k) and dst[k] is Dictionary and src[k] is Dictionary:
			_merge(dst[k], src[k])
		else:
			dst[k] = src[k]
