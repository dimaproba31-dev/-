extends Node
## Глобальное состояние забега («Game»): скорость мира, дистанция, палитра зоны, ярость, бонус-уровень.

const ZoneData := preload("res://scripts/world/zone_data.gd")

signal zone_changed(index: int, zone_name: String)
signal rage_started
signal rage_ended
signal minigame(kind: String)

const BASE_SPEED: float = 300.0        ## базовая скорость мира, px/с
const MAX_BONUS_SPEED: float = 160.0   ## прибавка скорости с дистанцией
const ROAD_Y: float = 560.0            ## уровень земли (стопы героя) в логических координатах
const PIXEL: int = 2                   ## 1 пиксель арта = 2 логических px

var boss_lock: bool = false   ## босс на экране: мир стоит, герой дерётся
var sprint: bool = false
var fast_attack: bool = false   ## кнопка «быстрые удары» в бою с боссом
var sprint_touch: bool = false
var speed: float = BASE_SPEED
var target_speed: float = BASE_SPEED
var distance: float = 0.0
var elapsed: float = 0.0
var running: bool = true
var zone_index: int = 0
var palette: Dictionary = {}
var view_size: Vector2 = Vector2(1280, 720)   ## логический размер видимой области (задаёт main.gd)

var rage_active: bool = false
var rage_left: float = 0.0
var bonus_kind: String = "rain"
var bonus_active: bool = false
var bonus_left: float = 0.0
var bonus_t: float = 0.0                       ## плавный коэффициент перехода в бонус-уровень 0..1
var hero: Node2D = null
var base_ts: float = 1.0
var shake: float = 0.0
var _hs_id: int = 0
var ui_open: bool = false                      ## открыт ли полноэкранный интерфейс

var _dist_acc: float = 0.0


func _ready() -> void:
	palette = ZoneData.blend(0.0)


func hitstop(dur: float) -> void:
	_hs_id += 1
	var my: int = _hs_id
	Engine.time_scale = base_ts * 0.06
	await get_tree().create_timer(dur, true, false, true).timeout
	if my == _hs_id:
		Engine.time_scale = base_ts


func add_shake(a: float) -> void:
	shake = maxf(shake, a)


func _process(delta: float) -> void:
	shake = move_toward(shake, 0.0, 14.0 * delta / maxf(Engine.time_scale, 0.1))
	elapsed += delta
	if not running:
		return
	if rage_active:
		rage_left -= delta
		if rage_left <= 0.0:
			rage_active = false
			rage_ended.emit()
	if bonus_active:
		bonus_left -= delta
		if bonus_left <= 0.0:
			bonus_active = false
	bonus_t = move_toward(bonus_t, 1.0 if bonus_active else 0.0, delta * 1.5)
	var boost: float = 1.0
	if rage_active:
		boost = 1.45
	if sprint:
		boost = maxf(boost, 1.5)
	if bonus_active:
		boost = maxf(boost, 1.25)
	target_speed = (BASE_SPEED + minf(distance * 0.004, MAX_BONUS_SPEED)) * Eco.speed_mult() * boost
	if boss_lock:
		target_speed = 0.0
	speed = move_toward(speed, target_speed, (900.0 if boss_lock else 260.0) * delta)
	distance += speed * delta
	_dist_acc += speed * delta / 10.0
	if _dist_acc >= 10.0:
		Eco.event("distance_m", _dist_acc)
		_dist_acc = 0.0
	palette = ZoneData.blend(distance)
	if bonus_t > 0.0:
		var bonus_pal: Dictionary = ZoneData.zones()[3]
		for k in palette.keys():
			var a: Variant = palette[k]
			var b: Variant = bonus_pal[k]
			if a is Color:
				palette[k] = (a as Color).lerp(b as Color, bonus_t * 0.85)
			elif a is float:
				palette[k] = lerpf(a as float, b as float, bonus_t)
	_apply_tint()
	var zi: int = int(floor(distance / ZoneData.ZONE_LENGTH)) % ZoneData.zones().size()
	if zi != zone_index:
		zone_index = zi
		zone_changed.emit(zi, String(ZoneData.zones()[zi]["name"]))


func start_rage() -> bool:
	if rage_active or float(Save.d["rage"]) < 1.0:
		return false
	Save.d["rage"] = 0.0
	rage_active = true
	rage_left = Eco.rage_duration()
	Eco.event("rage", 1.0)
	rage_started.emit()
	return true


func enter_bonus(seconds: float, kind: String = "rain") -> void:
	bonus_kind = kind
	bonus_active = true
	bonus_left = seconds


func reset_run() -> void:
	distance = 0.0
	speed = BASE_SPEED
	zone_index = 0
	rage_active = false
	rage_left = 0.0
	bonus_active = false
	bonus_left = 0.0


func meters() -> float:
	return distance / 10.0


## Окраска мира в зависимости от выбранного измерения (перестановка цветовых каналов).
func _apply_tint() -> void:
	var t: int = int(Eco.dim_data()["tint"])
	if t == 0:
		return
	for k in palette.keys():
		var v: Variant = palette[k]
		if v is Color:
			var c: Color = v
			var n: Color = c
			match t:
				1: n = Color(c.g, c.r * 1.05, c.b * 0.8, c.a)
				2: n = Color(c.b * 0.9, c.g * 1.0, c.r * 1.1, c.a)
				3: n = Color(c.r * 0.75, c.g * 0.35, c.r * 0.8 + c.b * 0.2, c.a)
			palette[k] = n
