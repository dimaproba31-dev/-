extends Node
## Процедурные звуковые эффекты (никаких аудиофайлов): короткие тона и шум, собранные в AudioStreamWAV.
## Sfx.play("coin") — проиграть. Звук отключается в настройках (Save.d.settings.sound).

const RATE: int = 22050
const POOL: int = 10

var _streams: Dictionary = {}
var _players: Array[AudioStreamPlayer] = []
var _last: Dictionary = {}
var _next: int = 0


func _ready() -> void:
	for i in range(POOL):
		var p := AudioStreamPlayer.new()
		p.volume_db = -6.0
		add_child(p)
		_players.append(p)
	_build()


func _build() -> void:
	_streams["coin"] = _seq([_tone(988.0, 988.0, 0.04, "square", 0.22), _tone(1319.0, 1319.0, 0.08, "square", 0.22)])
	_streams["gem"] = _seq([_tone(1200.0, 1500.0, 0.05, "sine", 0.35), _tone(1800.0, 2100.0, 0.09, "sine", 0.3)])
	_streams["jump"] = _seq([_tone(280.0, 620.0, 0.13, "square", 0.22)])
	_streams["jump2"] = _seq([_tone(420.0, 900.0, 0.12, "square", 0.22)])
	_streams["slash"] = _seq([_tone(1200.0, 300.0, 0.09, "noise", 0.3)])
	_streams["kill"] = _seq([_tone(300.0, 90.0, 0.1, "square", 0.25), _tone(200.0, 60.0, 0.08, "noise", 0.25)])
	_streams["shoot"] = _seq([_tone(1100.0, 380.0, 0.08, "square", 0.2)])
	_streams["hit"] = _seq([_tone(260.0, 120.0, 0.07, "noise", 0.3)])
	_streams["boss_die"] = _seq([_tone(400.0, 80.0, 0.25, "square", 0.3), _tone(300.0, 50.0, 0.3, "noise", 0.3), _tone(600.0, 1200.0, 0.2, "sine", 0.3)])
	_streams["chest"] = _seq([_tone(523.0, 523.0, 0.06, "square", 0.2), _tone(659.0, 659.0, 0.06, "square", 0.2), _tone(784.0, 784.0, 0.06, "square", 0.2), _tone(1046.0, 1046.0, 0.14, "square", 0.22)])
	_streams["portal"] = _seq([_tone(180.0, 1100.0, 0.5, "sine", 0.35)])
	_streams["rage"] = _seq([_tone(120.0, 420.0, 0.35, "square", 0.28), _tone(420.0, 840.0, 0.25, "square", 0.25)])
	_streams["buy"] = _seq([_tone(660.0, 660.0, 0.05, "square", 0.2), _tone(990.0, 990.0, 0.09, "square", 0.2)])
	_streams["error"] = _seq([_tone(160.0, 130.0, 0.14, "square", 0.25)])
	_streams["click"] = _seq([_tone(700.0, 600.0, 0.03, "square", 0.15)])
	_streams["rebirth"] = _seq([_tone(262.0, 262.0, 0.1, "square", 0.25), _tone(330.0, 330.0, 0.1, "square", 0.25), _tone(392.0, 392.0, 0.1, "square", 0.25), _tone(523.0, 1046.0, 0.4, "sine", 0.35)])
	_streams["claim"] = _seq([_tone(784.0, 784.0, 0.07, "square", 0.2), _tone(1046.0, 1046.0, 0.07, "square", 0.2), _tone(1318.0, 1318.0, 0.16, "square", 0.22)])


func play(name: String, pitch: float = 1.0) -> void:
	if not bool((Save.d.get("settings", {}) as Dictionary).get("sound", true)):
		return
	if not _streams.has(name):
		return
	var now: float = Time.get_ticks_msec() / 1000.0
	if now - float(_last.get(name, -1.0)) < 0.035:
		return
	_last[name] = now
	var p: AudioStreamPlayer = _players[_next]
	_next = (_next + 1) % POOL
	p.stream = _streams[name]
	p.pitch_scale = pitch
	p.play()


func _tone(f0: float, f1: float, dur: float, wave: String, vol: float) -> PackedByteArray:
	var n: int = int(float(RATE) * dur)
	var data := PackedByteArray()
	data.resize(n * 2)
	var phase: float = 0.0
	for i in range(n):
		var t: float = float(i) / float(n)
		phase += lerpf(f0, f1, t) / float(RATE)
		var s: float = 0.0
		match wave:
			"square":
				s = 1.0 if fmod(phase, 1.0) < 0.5 else -1.0
			"sine":
				s = sin(TAU * phase)
			"noise":
				s = randf() * 2.0 - 1.0
		var env: float = (1.0 - t) * minf(1.0, float(i) / 120.0)
		data.encode_s16(i * 2, int(clampf(s * env * vol, -1.0, 1.0) * 32767.0))
	return data


func _seq(parts: Array) -> AudioStreamWAV:
	var all := PackedByteArray()
	for p in parts:
		all.append_array(p as PackedByteArray)
	var w := AudioStreamWAV.new()
	w.format = AudioStreamWAV.FORMAT_16_BITS
	w.mix_rate = RATE
	w.stereo = false
	w.data = all
	return w
