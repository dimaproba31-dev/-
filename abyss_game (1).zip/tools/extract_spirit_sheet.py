from PIL import Image
import numpy as np, json
from scipy import ndimage as ndi
src=Image.open('/mnt/user-data/attachments/ea372b1f-c3da-5741-82ca-a46268ac9bbd/6df0a3e8-image.png').convert('RGB')
a=np.array(src).astype(int)
B={'idle':(22,157,[13,208,360,508,657,804]),
'fly':(184,301,[14,203,361,515,674,845,1009,1171,1339,1520]),
'attack':(333,444,[14,168,340,515,675,839,1035,1206,1367]),
'heavy':(476,595,[13,181,337,489,640,797,1020,1202,1362,1528]),
'hit':(619,731,[14,176,324,470,632]),
'skill':(761,872,[13,176,340,467,594,743,883,1028,1181,1352,1525]),
'death':(903,1012,[14,186,355,531,696,863,1037,1195,1352,1521])}
CW,CH=256,176
LX=18   # левый отступ кадра в ячейке
BOT=168 # нижняя линия кадров
out={}
for k,(y0,y1,xs) in B.items():
    n=len(xs)-1
    strip=Image.new('RGBA',(CW*n,CH),(0,0,0,0))
    for i in range(n):
        c=a[y0:y1, xs[i]+3:xs[i+1]-2]
        br=c.mean(2); sat=c.max(2)-c.min(2)
        bgc=(br>208)&(sat<22)
        # заливка фона от границы
        lab,_=ndi.label(bgc)
        edge=set(np.unique(np.concatenate([lab[0],lab[-1],lab[:,0],lab[:,-1]])))-{0}
        bg=np.isin(lab,list(edge))
        fg=~bg
        fg=ndi.binary_opening(fg,iterations=1)
        l2,m=ndi.label(fg)
        if m:
            sz=ndi.sum(fg,l2,range(1,m+1)); keepl=[]
            for j,sl in enumerate(ndi.find_objects(l2)):
                hh=sl[0].stop-sl[0].start; ww=sl[1].stop-sl[1].start
                if sz[j]<12: continue
                if (sl[0].stop<=26 and (ww>25 or hh<10)) or (sl[0].start==0 and ww>25 and hh<24): continue   # плашка-подпись листа
                keepl.append(j+1)
            fg=np.isin(l2,keepl)
        # полупрозрачная кромка: пиксель рядом с фоном светлеет -> снизить альфа
        rgba=np.zeros(c.shape[:2]+(4,),np.uint8); rgba[...,:3]=c; rgba[...,3]=fg*255
        im=Image.fromarray(rgba)
        h,w=c.shape[:2]
        ox=i*CW+LX; oy=BOT-h
        strip.paste(im,(ox,oy))
    strip.save(f'/home/claude/abyss/art/spirit/{k}.png'); out[k]=n
    print(k,n)
json.dump({"cell":[CW,CH],"pivot":[LX+85,BOT+10],"frames":out,
 "fps":{"idle":6,"fly":12},
 "strike_frame":{"attack":5,"heavy":5,"skill":7},"tip":[150,-70],"mid":[120,-55],"scale":0.7},open('/home/claude/abyss/art/spirit/spirit.json','w'))
