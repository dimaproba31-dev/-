extends Node
## Dev: выгружает кадры процедурного духа в ленты 192x192 (проверка загрузчика PNG).
const V := preload("res://scripts/hero/spirit_visual.gd")
func _ready() -> void:
	var v: Node2D = V.new()
	add_child(v)
	for i in range(30): v.call("advance", 1.0/60.0, 300.0)
	for a in [["idle",6],["fly",8],["attack",8],["heavy",10],["hit",4],["skill",10],["death",8]]:
		var strip := Image.create_empty(192 * a[1], 192, false, Image.FORMAT_RGBA8)
		for i in range(a[1]):
			v.call("preview", a[0], i)
			var cellimg := Image.create_empty(192, 192, false, Image.FORMAT_RGBA8)
			cellimg.blend_rect(v.get("_img"), Rect2i(0,0,V.W,V.H), Vector2i(24,10))
			cellimg.blend_rect(v.get("_fx_img"), Rect2i(0,0,V.W,V.H), Vector2i(24,10))
			strip.blit_rect(cellimg, Rect2i(0,0,192,192), Vector2i(192*i,0))
		strip.save_png(OS.get_environment("OUT") + "/" + a[0] + ".png")
	get_tree().quit()
