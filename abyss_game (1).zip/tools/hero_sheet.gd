extends Node
## Dev: контактный лист поз героя -> /tmp/claude-0/shots/hero_sheet.png
## godot --headless --path . res://tools/hero_sheet.tscn

const Visual := preload("res://scripts/hero/hero_visual.gd")

var cells: Array = []


func _make() -> Node2D:
	var v: Node2D = Visual.new()
	add_child(v)
	return v


func _snap(v: Node2D, label: String) -> void:
	var base := Image.create_empty(Visual.W, Visual.H, false, Image.FORMAT_RGBA8)
	base.fill(Color(0.35, 0.12, 0.12))
	for y in range(Visual.H - 14, Visual.H):
		for x in range(Visual.W):
			base.set_pixel(x, y, Color(0.25, 0.1, 0.1))
	var img: Image = v.get("_img")
	var fx: Image = v.get("_fx_img")
	base.blend_rect(img, Rect2i(0, 0, Visual.W, Visual.H), Vector2i.ZERO)
	for y in range(Visual.H):
		for x in range(Visual.W):
			var c: Color = fx.get_pixel(x, y)
			if c.a > 0.0:
				var o: Color = base.get_pixel(x, y)
				base.set_pixel(x, y, Color(minf(o.r + c.r * c.a, 1.0), minf(o.g + c.g * c.a, 1.0), minf(o.b + c.b * c.a, 1.0), 1.0))
	cells.append(base)


func _run(v: Node2D, n: int, speed: float = 300.0) -> void:
	for i in range(n):
		v.call("advance", 1.0 / 60.0, speed)


func _ready() -> void:
	# бег
	var v: Node2D = _make()
	v.set("sword_lv", int(OS.get_environment("SWL")) if OS.get_environment("SWL") != "" else 0)
	_run(v, 40)
	for i in range(6):
		_run(v, 2)
		_snap(v, "run")
	v.queue_free()
	v = _make()
	v.set("sprint", true)
	_run(v, 60, 450.0)
	for i in range(6):
		_run(v, 2, 450.0)
		_snap(v, "sprint")
	v.queue_free()
	# воздух
	var vals: Array = [-800.0, -300.0, 0.0, 500.0]
	for vv in vals:
		v = _make()
		v.set("on_ground", false)
		v.set("vy", vv)
		_run(v, 30)
		_snap(v, "air")
		v.queue_free()
	# сальто
	v = _make()
	_run(v, 20)
	v.set("on_ground", false)
	v.set("vy", -500.0)
	v.call("double_jumped")
	for i in range(6):
		_run(v, 4)
		_snap(v, "flip")
	v.queue_free()
	# атаки
	for kind in range(3):
		v = _make()
		_run(v, 40)
		v.call("start_attack", kind, 1.0)
		var steps: int = 12 if kind < 2 else 14
		for i in range(steps):
			_run(v, 1 if i < 5 else 2)
			_snap(v, "atk")
		v.queue_free()
	# выстрел и ярость
	v = _make()
	_run(v, 40)
	v.call("cast")
	_run(v, 2)
	_snap(v, "cast")
	v.set("rage", true)
	_run(v, 30)
	_snap(v, "rage")
	v.queue_free()
	var cols: int = 9
	var rows: int = int(ceil(float(cells.size()) / float(cols)))
	var sheet := Image.create_empty(cols * Visual.W, rows * Visual.H, false, Image.FORMAT_RGBA8)
	for i in range(cells.size()):
		sheet.blit_rect(cells[i], Rect2i(0, 0, Visual.W, Visual.H), Vector2i((i % cols) * Visual.W, (i / cols) * Visual.H))
	DirAccess.make_dir_recursive_absolute("/tmp/claude-0/shots")
	sheet.save_png("/tmp/claude-0/shots/hero_sheet.png")
	print("[sheet] ", cells.size(), " cells")
	get_tree().quit()
