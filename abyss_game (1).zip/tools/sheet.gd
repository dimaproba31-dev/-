extends Node2D
## Dev-инструмент: рисует контактный лист спрайтов/иконок и сохраняет скриншот (godot --path . res://tools/sheet.tscn).
const Sprites := preload("res://scripts/gfx/sprites.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")

func _ready() -> void:
	for i in range(6):
		await get_tree().process_frame
	await RenderingServer.frame_post_draw
	get_viewport().get_texture().get_image().save_png("/tmp/claude-0/shots/sheet.png")
	get_tree().quit()

func _draw() -> void:
	draw_rect(Rect2(0, 0, 1280, 720), Color(0.25, 0.1, 0.12))
	var x: float = 10.0
	var y: float = 10.0
	var s: float = 4.0
	for name in Sprites.FRAMES.keys():
		for f in range(Sprites.frame_count(name)):
			var t: Texture2D = Sprites.get_tex(name, f)
			draw_texture_rect(t, Rect2(x, y, t.get_width() * s, t.get_height() * s), false)
			x += t.get_width() * s + 8.0
			if x > 1180.0:
				x = 10.0
				y += 130.0
	x = 10.0
	y += 140.0
	for n in ["sword","shield","armor","helm","boots","bow","ring","amulet","magnet","wing","flame","clover","star","potion","scroll","trophy","gear","close","up","dots","bag","tree","skull","bolt","clock","check","lock"]:
		var t2: Texture2D = Sprites.icon(n)
		draw_texture_rect(t2, Rect2(x, y, t2.get_width() * 4.0, t2.get_height() * 4.0), false)
		x += 84.0
		if x > 1200.0:
			x = 10.0
			y += 84.0
	PixelFont.draw_text(self, "ОСКОЛКИ БЕЗДНЫ: ЭТАП 2. АБВГДЕЁЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯ 0123456789 +-/%:.,!? ABC QRSTUVWXYZ", Vector2(10, 650), 3, Color.WHITE)
	PixelFont.draw_text(self, "Привет, мир! Купить x10 — ёжик, щука, ъ/ы/ь; Qa Qi KMBT", Vector2(10, 690), 2, Color(1, 0.9, 0.4))
