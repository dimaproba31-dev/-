extends Node
## Dev: лист кадров Духа косы -> /tmp/claude-0/shots/spirit_sheet.png (строка = анимация)
const Visual := preload("res://scripts/hero/spirit_visual.gd")
const ANIMS := [["idle", 6], ["fly", 8], ["attack", 8], ["heavy", 10], ["hit", 4], ["skill", 10], ["death", 8]]

func _ready() -> void:
	var v: Node2D = Visual.new()
	add_child(v)
	for i in range(40):
		v.call("advance", 1.0 / 60.0, 300.0)
	var sheet := Image.create_empty(10 * Visual.W, ANIMS.size() * Visual.H, false, Image.FORMAT_RGBA8)
	sheet.fill(Color(0.35, 0.12, 0.12))
	for r in range(ANIMS.size()):
		var name: String = ANIMS[r][0]
		for i in range(int(ANIMS[r][1])):
			v.call("preview", name, i)
			var base := Image.create_empty(Visual.W, Visual.H, false, Image.FORMAT_RGBA8)
			base.fill(Color(0.18, 0.1, 0.16))
			base.blend_rect(v.get("_img"), Rect2i(0, 0, Visual.W, Visual.H), Vector2i.ZERO)
			var fx: Image = v.get("_fx_img")
			for y in range(Visual.H):
				for x in range(Visual.W):
					var c: Color = fx.get_pixel(x, y)
					if c.a > 0.0:
						var o: Color = base.get_pixel(x, y)
						base.set_pixel(x, y, Color(minf(o.r + c.r * c.a, 1.0), minf(o.g + c.g * c.a, 1.0), minf(o.b + c.b * c.a, 1.0), 1.0))
			sheet.blit_rect(base, Rect2i(0, 0, Visual.W, Visual.H), Vector2i(i * Visual.W, r * Visual.H))
	DirAccess.make_dir_recursive_absolute("/tmp/claude-0/shots")
	sheet.save_png("/tmp/claude-0/shots/spirit_sheet.png")
	print("[sheet] done")
	get_tree().quit()
