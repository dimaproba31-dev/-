extends Node
## Лист кадров босса: godot --headless --path . res://tools/boss_sheet.tscn
const Sprites := preload("res://scripts/gfx/sprites.gd")

func _ready() -> void:
	var out := Image.create(156 * 7, 128, false, Image.FORMAT_RGBA8)
	out.fill(Color(0.35, 0.18, 0.2))
	for f in range(7):
		var im: Image = Sprites.get_tex("boss", f, 0).get_image()
		out.blend_rect(im, Rect2i(0, 0, im.get_width(), im.get_height()), Vector2i(156 * f, 0))
	out.save_png("/tmp/claude-0/shots/boss_sheet.png")
	get_tree().quit()
