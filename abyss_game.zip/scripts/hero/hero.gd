extends Node2D
## Герой: физика прыжка (двойной прыжок, переменная высота), автоатака тремя связками, выстрел, события для эффектов.
## Бежит «на месте»: движется мир, а не он.

enum State { RUN, IDLE }

signal state_changed(new_state: int)
signal strike(kind: int, rect: Rect2)

const GRAVITY: float = 3000.0
const JUMP_V: float = 1000.0

@export var screen_x_ratio: float = 0.22
@export var min_x: float = 170.0

var state: int = State.RUN
var vy: float = 0.0
var ground_y: float = 0.0
var y_f: float = 0.0
var on_ground: bool = true
var jumps_left: int = 1
var combo: int = 0

var _jump_held: bool = false
var _jump_buffer: float = 0.0
var _attack_cd: float = 0.0
var _combo_t: float = 0.0
var _fx: Node2D

@onready var visual: Node2D = $Visual
@onready var embers: CPUParticles2D = $FeetEmbers


func _ready() -> void:
	ground_y = Game.ROAD_Y
	y_f = ground_y
	position.y = ground_y
	Game.hero = self
	_fx = get_node_or_null("../Fx") as Node2D
	_setup_embers()
	InputRouter.jump_pressed.connect(request_jump)
	InputRouter.jump_released.connect(_on_release)
	visual.connect("strike", _on_visual_strike)
	_pet = preload("res://scripts/hero/pet.gd").new()
	_pet.z_index = 6
	add_child.call_deferred(_pet)
	_pet.set_as_top_level(true)


var _pet: Node2D


func _process(delta: float) -> void:
	_sync_pet()
	var px: float = float(Game.PIXEL)
	var dash_off: float = 0.0
	if int(visual.get("_atk_kind")) == 3:
		var f: float = clampf(float(visual.get("_atk_t")) / maxf(0.01, float(visual.get("_atk_dur"))), 0.0, 1.0)
		dash_off = 120.0 * smoothstep(0.1, 0.34, f) * (1.0 - smoothstep(0.62, 0.98, f))
		if _fx != null and dash_off > 10.0:
			_fx.call("ash", position + Vector2(-30.0, -40.0), 2, 14.0)
	position.x = floorf((maxf(min_x, Game.view_size.x * screen_x_ratio) + dash_off) / px) * px
	# угольки от раскалённого клинка: чем круче меч, тем гуще
	var swlv: int = Eco.level(0)
	if _fx != null and swlv >= 5 and Game.running and randf() < 0.05 + 0.02 * minf(float(swlv) / 20.0, 5.0):
		_fx.call("ash", position + (visual.get("blade_mid_local") as Vector2), 1, 14.0)
	var was_air: bool = not on_ground
	var old_y: float = y_f
	_physics(delta)
	position.y = roundf(y_f / px) * px
	if was_air and on_ground:
		visual.call("landed")
		if _fx != null:
			_fx.call("dust", Vector2(position.x, ground_y), 8)
		Sfx.play("click", 0.6)
	_attack_cd = maxf(0.0, _attack_cd - delta)
	_combo_t += delta
	var running: bool = state == State.RUN and Game.running
	visual.set("on_ground", on_ground)
	visual.set("vy", vy)
	Game.sprint = Input.is_key_pressed(KEY_SHIFT) or Game.sprint_touch
	visual.set("rage", Game.rage_active)
	visual.set("sprint", Game.sprint)
	visual.set("sword_lv", Eco.level(0))
	visual.set("shadow_dy", ground_y - position.y)
	visual.set("hero_dy_px", (y_f - old_y) / px)
	var world_speed: float = Game.speed if running else 0.0
	visual.call("advance", delta, world_speed)
	embers.emitting = running and on_ground
	var s: float = Game.speed
	embers.initial_velocity_min = s * 0.8
	embers.initial_velocity_max = s * 1.35
	var glow: Color = Game.palette["glow"]
	embers.color = Color(glow.r, glow.g, glow.b, 0.9)


func request_jump() -> void:
	if not Game.running or Game.ui_open:
		return
	_jump_buffer = 0.12
	_jump_held = true


func _on_release() -> void:
	_jump_held = false
	if not on_ground and vy < -450.0:
		vy = -450.0   # короткий тап — невысокий прыжок


func _physics(dt: float) -> void:
	_jump_buffer = maxf(0.0, _jump_buffer - dt)
	if _jump_buffer > 0.0:
		var max_j: int = 2 if Eco.has_double_jump() else 1
		if on_ground:
			jumps_left = max_j - 1
			_do_jump(1.0, false)
		elif jumps_left > 0:
			jumps_left -= 1
			_do_jump(0.9, true)
	if not on_ground:
		vy += GRAVITY * dt
		y_f += vy * dt
		if y_f >= ground_y:
			y_f = ground_y
			vy = 0.0
			on_ground = true


func _do_jump(f: float, double: bool) -> void:
	_jump_buffer = 0.0
	if on_ground and _fx != null:
		_fx.call("dust", Vector2(position.x, ground_y), 6)
	on_ground = false
	vy = -JUMP_V * f * Eco.jump_mult()
	Eco.event("jump", 1.0)
	if double:
		visual.call("double_jumped")
		if _fx != null:
			_fx.call("ring", position + Vector2(0, -60), Color(0.6, 0.85, 1.0))
		Sfx.play("jump2")
	else:
		visual.call("jumped")
		Sfx.play("jump")


# ---------------------------------------------------------------- бой

func can_attack() -> bool:
	return _attack_cd <= 0.0 and Game.running


func begin_attack() -> void:
	if not can_attack():
		return
	if _combo_t > 0.75:
		combo = 0
	var speed: float = 1.35 if Game.rage_active else 1.0
	var kind: int = combo
	if randf() < (0.3 if Game.rage_active else 0.2):
		kind = 3
	visual.call("start_attack", kind, speed)
	var dur: float = (0.52 if kind == 2 else (0.5 if kind == 3 else 0.36)) / speed
	_attack_cd = dur * 0.66
	_combo_t = 0.0
	Sfx.play("slash", 0.9 + float(kind) * 0.12)
	if kind != 3:
		combo = (combo + 1) % 3


func _on_visual_strike(kind: int) -> void:
	if _fx != null:
		_fx.call("ash", position + (visual.get("blade_tip_local") as Vector2), 12, 18.0)
	strike.emit(kind, strike_rect(kind))


## Зона, в которой враги получают удар в момент прохода клинка.
func strike_rect(kind: int) -> Rect2:
	var reach: float = 100.0 + (Eco.melee_range() - 70.0) * 0.8
	match kind:
		1:
			return Rect2(position + Vector2(-20.0, -290.0), Vector2(reach + 10.0, 330.0))
		2:
			return Rect2(position + Vector2(-90.0, -240.0), Vector2(reach + 110.0, 280.0))
	if kind == 3:
		return Rect2(position + Vector2(-20.0, -230.0), Vector2(reach + 90.0, 260.0))
	return Rect2(position + Vector2(-10.0, -230.0), Vector2(reach, 260.0))


## Зона, где появление врага запускает взмах.
func trigger_rect() -> Rect2:
	var reach: float = 100.0 + (Eco.melee_range() - 70.0) * 0.8
	return Rect2(position + Vector2(10.0, -190.0), Vector2(reach + 45.0, 215.0))


func cast() -> Vector2:
	visual.call("cast")
	return position + (visual.call("cast_point") as Vector2) + Vector2(12.0, 0.0)


func hand_pos() -> Vector2:
	return position + Vector2(40.0, -90.0)


func body_rect() -> Rect2:
	return Rect2(position + Vector2(-22.0, -96.0), Vector2(44.0, 96.0))


func melee_rect() -> Rect2:
	return trigger_rect()


func start_swing() -> void:
	begin_attack()


func set_state(new_state: int) -> void:
	if state == new_state:
		return
	state = new_state
	state_changed.emit(new_state)


func _setup_embers() -> void:
	var g := Gradient.new()
	g.offsets = PackedFloat32Array([0.0, 0.2, 1.0])
	g.colors = PackedColorArray([Color(1, 1, 1, 0), Color(1.0, 0.85, 0.55, 1.0), Color(0.7, 0.15, 0.05, 0.0)])
	var img: Image = Image.create_empty(Game.PIXEL, Game.PIXEL, false, Image.FORMAT_RGBA8)
	img.fill(Color.WHITE)
	embers.texture = ImageTexture.create_from_image(img)
	embers.color_ramp = g
	embers.amount = 26
	embers.lifetime = 0.55
	embers.local_coords = false
	embers.direction = Vector2(-1.0, -0.35)
	embers.spread = 35.0
	embers.gravity = Vector2(0.0, 340.0)
	embers.scale_amount_min = 1.0
	embers.scale_amount_max = 2.0
	var m := CanvasItemMaterial.new()
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	embers.material = m


func _sync_pet() -> void:
	if _pet == null or not is_instance_valid(_pet):
		return
	var idx: int = int(Save.d["pet"])
	var pets: Array = Save.d["pets"]
	_pet.visible = idx >= 0 and idx < pets.size()
	if _pet.visible:
		var pr: Array = pets[idx]
		if int(_pet.get("species")) != int(pr[0]) or int(_pet.get("rarity")) != int(pr[1]):
			_pet.call("set_pet", int(pr[0]), int(pr[1]))
