extends Node2D
## Герой «Теневой клинок»: каждый кадр поза считается скелетом с IK (ноги, руки), растеризуется по пикселям,
## получает 3 тона и обводку. Плащ, шарф и капюшон — верёв-симуляция. Атаки — три связки с шлейфом клинка.
## Начало координат узла — точка касания земли; герой смотрит вправо.

signal strike(kind: int)      ## момент, когда клинок проходит через цель

const K: float = 0.56          ## единицы тела -> пиксели арта
const S: float = K / 0.72      ## масштаб «абсолютных» толщин
const W: int = 176
const H: int = 168
const OX: int = 72
const OY: int = 140

const M_ARMOR: int = 1
const M_ARMOR_D: int = 2
const M_ARMOR_L: int = 3
const M_CLOAK: int = 4
const M_SCARF: int = 5
const M_HOOD: int = 6
const M_BOOT: int = 7
const M_STEEL: int = 8
const M_GOLD: int = 9
const M_EYE: int = 10
const M_LEATHER: int = 11
const M_CLOTH_IN: int = 12
const M_FACE: int = 13  ## (занят маской)
const M_SKIN: int = 14
const M_HAIR: int = 15
const M_COAT: int = 16
const M_PANTS: int = 17
const M_SHIRT: int = 18
const M_DARK: int = 20      ## плоские цвета деталей лица
const M_WHITE: int = 21
const M_IRIS: int = 22
const M_LIP: int = 23
const M_RUNE: int = 24
const M_FULLER: int = 25
const M_MASK: int = 13
const M_BONE: int = 19

const OUTLINE := Color(0.025, 0.01, 0.04)

# --- состояние, которое задаёт герой
var on_ground: bool = true
var vy: float = 0.0
var rage: bool = false
var shadow_dy: float = 0.0       ## расстояние до земли (логические px), для тени
var hero_dy_px: float = 0.0      ## сдвиг героя по вертикали за кадр (px арта) — для инерции ткани

# --- анимация
var phase: float = 0.0
var sprint: bool = false
var _stand_k: float = 0.0
var sword_lv: int = 0
var blade_tip_local: Vector2 = Vector2.ZERO
var blade_mid_local: Vector2 = Vector2.ZERO
var _spk: float = 0.0
var _t: float = 0.0
var _land_t: float = 0.0
var _cast_t: float = 0.0
var _flip_t: float = -1.0
var _atk_kind: int = -1
var _atk_t: float = 0.0
var _atk_dur: float = 0.36
var _atk_struck: bool = false
var _atk_speed: float = 1.0

var _ids: PackedByteArray = PackedByteArray()
var _img: Image
var _tex: ImageTexture
var _fx_img: Image
var _fx_tex: ImageTexture
var _pal: Dictionary = {}
var _pal_rage: Dictionary = {}
var _bx0: int = 0
var _bx1: int = 0
var _by0: int = 0
var _by1: int = 0

var _scarf: Array = []
var _cape_a: Array = []
var _cape_b: Array = []
var _hood: Array = []
var _trail: Array = []           ## выборки клинка: {t, b, tip}
var _ghosts: Array = []          ## призрачные копии: {tex, age, x, y}
var _ghost_pool: Array[ImageTexture] = []
var _ghost_acc: float = 0.0
var _fxn: Node2D
var _cast_pt: Vector2 = Vector2.ZERO   ## точка руки при выстреле, px холста
var _last_sk: Dictionary = {}


func _ready() -> void:
	_ids.resize(W * H)
	_img = Image.create_empty(W, H, false, Image.FORMAT_RGBA8)
	_tex = ImageTexture.create_from_image(_img)
	_fx_img = Image.create_empty(W, H, false, Image.FORMAT_RGBA8)
	_fx_tex = ImageTexture.create_from_image(_fx_img)
	_pal = {
		M_ARMOR: [Color(0.03, 0.03, 0.06), Color(0.10, 0.10, 0.16), Color(0.34, 0.36, 0.52)],
		M_ARMOR_D: [Color(0.01, 0.01, 0.03), Color(0.05, 0.05, 0.09), Color(0.16, 0.17, 0.26)],
		M_ARMOR_L: [Color(0.10, 0.10, 0.18), Color(0.26, 0.28, 0.42), Color(0.62, 0.65, 0.84)],
		M_CLOAK: [Color(0.03, 0.01, 0.05), Color(0.11, 0.04, 0.15), Color(0.26, 0.10, 0.32)],
		M_SCARF: [Color(0.14, 0.02, 0.04), Color(0.34, 0.05, 0.09), Color(0.62, 0.12, 0.16)],
		M_HOOD: [Color(0.06, 0.03, 0.10), Color(0.15, 0.09, 0.24), Color(0.32, 0.22, 0.48)],
		M_BOOT: [Color(0.02, 0.02, 0.03), Color(0.08, 0.08, 0.12), Color(0.27, 0.28, 0.38)],
		M_STEEL: [Color(0.55, 0.56, 0.66), Color(0.90, 0.92, 1.0), Color(1.0, 1.0, 1.0)],
		M_GOLD: [Color(0.28, 0.18, 0.04), Color(0.62, 0.45, 0.12), Color(0.95, 0.78, 0.34)],
		M_EYE: [Color(0.2, 0.8, 1.0), Color(0.55, 0.95, 1.0), Color(0.9, 1.0, 1.0)],
		M_LEATHER: [Color(0.07, 0.03, 0.02), Color(0.18, 0.09, 0.05), Color(0.36, 0.20, 0.10)],
		M_CLOTH_IN: [Color(0.12, 0.02, 0.04), Color(0.28, 0.04, 0.08), Color(0.50, 0.10, 0.14)],
		M_SKIN: [Color(0.03, 0.03, 0.06), Color(0.12, 0.12, 0.18), Color(0.36, 0.38, 0.54)],
		M_HAIR: [Color(0.03, 0.03, 0.06), Color(0.11, 0.11, 0.17), Color(0.36, 0.38, 0.54)],
		M_COAT: [Color(0.02, 0.02, 0.04), Color(0.08, 0.08, 0.13), Color(0.28, 0.30, 0.44)],
		M_PANTS: [Color(0.02, 0.02, 0.04), Color(0.07, 0.07, 0.11), Color(0.22, 0.23, 0.34)],
		M_MASK: [Color(0.0, 0.0, 0.02), Color(0.02, 0.02, 0.05), Color(0.08, 0.08, 0.14)],
		M_BONE: [Color(0.28, 0.18, 0.04), Color(0.62, 0.46, 0.12), Color(0.96, 0.80, 0.36)],
		M_SHIRT: [Color(0.55, 0.10, 0.0), Color(1.0, 0.45, 0.08), Color(1.0, 0.90, 0.5)],
	}
	_pal_rage = _pal.duplicate()
	_pal_rage[M_STEEL] = [Color(0.45, 0.10, 0.03), Color(1.0, 0.55, 0.2), Color(1.0, 0.98, 0.8)]
	_pal_rage[M_SHIRT] = [Color(1.0, 0.45, 0.1), Color(1.0, 0.85, 0.4), Color(1.0, 1.0, 0.9)]
	_pal_rage[M_EYE] = [Color(1.0, 0.2, 0.1), Color(1.0, 0.5, 0.2), Color(1.0, 0.9, 0.5)]
	_pal_rage[M_SCARF] = [Color(0.8, 0.12, 0.05), Color(1.0, 0.45, 0.1), Color(1.0, 0.85, 0.4)]
	_pal_rage[M_ARMOR_L] = [Color(0.30, 0.10, 0.08), Color(0.62, 0.28, 0.18), Color(1.0, 0.75, 0.45)]
	for i in range(6):
		_ghost_pool.append(ImageTexture.create_from_image(Image.create_empty(W, H, false, Image.FORMAT_RGBA8)))
	_init_chain(_scarf, 8)
	_init_chain(_cape_a, 10)
	_init_chain(_cape_b, 10)
	_init_chain(_hood, 6)
	_fxn = Node2D.new()
	var mat := CanvasItemMaterial.new()
	mat.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	_fxn.material = mat
	add_child(_fxn)
	_fxn.draw.connect(_draw_fx)
	_render_all(_pose_loco())


# ====================================================================== управление

func jumped() -> void:
	_land_t = 0.0
	_flip_t = -1.0


func double_jumped() -> void:
	_flip_t = 0.0


func landed() -> void:
	_land_t = 0.14
	_flip_t = -1.0


func cast() -> void:
	_cast_t = 0.3


func attacking() -> bool:
	return _atk_kind >= 0


func start_attack(kind: int, speed: float = 1.0) -> void:
	_atk_kind = kind
	_atk_t = 0.0
	_atk_struck = false
	_atk_speed = speed
	_atk_dur = (0.52 if kind == 2 else (0.5 if kind == 3 else 0.36)) / speed


## Положение точки выстрела (рука), логические px относительно узла героя.
func cast_point() -> Vector2:
	return (_cast_pt - Vector2(OX, OY)) * float(Game.PIXEL)


# ====================================================================== цикл

func advance(delta: float, world_speed: float) -> void:
	_t += delta
	var sp: float = world_speed / 300.0
	_stand_k = move_toward(_stand_k, 1.0 if world_speed < 25.0 else 0.0, delta * 6.0)
	_spk = move_toward(_spk, 1.0 if (sprint or rage) else 0.0, delta * 5.0)
	phase += delta * sp * 14.0 * (1.0 + 0.3 * _spk) * (1.0 + 0.14 * sin(phase * 2.0 - 0.3))
	_land_t = maxf(0.0, _land_t - delta)
	_cast_t = maxf(0.0, _cast_t - delta)
	if _flip_t >= 0.0:
		_flip_t += delta
		if _flip_t > 0.46:
			_flip_t = -1.0
	var pose: Dictionary
	# атака считается мелкими шагами, чтобы шлейф клинка был гладким
	if _atk_kind >= 0:
		var steps: int = clampi(int(ceil(delta * 240.0)), 1, 6)
		var sub: float = delta / float(steps)
		for i in range(steps):
			_atk_t += sub
			pose = _pose_full()
			var f: float = _atk_t / _atk_dur
			var sk: Dictionary = _skeleton(pose)
			_trail.append({"t": _t, "b": sk["blade_b"], "tip": sk["blade_t"]})
			if not _atk_struck and f >= _strike_frac():
				_atk_struck = true
				strike.emit(_atk_kind)
			if _atk_t >= _atk_dur:
				_atk_kind = -1
				break
	if pose.is_empty():
		pose = _pose_full()
	while _trail.size() > 0 and _t - float(_trail[0]["t"]) > 0.17:
		_trail.pop_front()
	_sim_cloth(delta, world_speed, pose)
	_render_all(pose)
	_update_ghosts(delta, world_speed)
	queue_redraw()
	_fxn.queue_redraw()


func _strike_frac() -> float:
	match _atk_kind:
		0: return 0.34
		1: return 0.36
		3: return 0.42
		_: return 0.34


# ====================================================================== позы

static func _P(o: Dictionary) -> Dictionary:
	var d: Dictionary = {"hx": 0.0, "hy": -41.0, "lean": 0.28, "head": 0.0, "ff": Vector2(8, 0), "fb": Vector2(-8, 0),
		"hf": Vector2(16, 11), "hb": Vector2(8, 12), "sw": 1.8, "hp": 0.0, "rot": 0.0}
	for k in o:
		d[k] = o[k]
	return d


static func _mix(a: Dictionary, b: Dictionary, t: float) -> Dictionary:
	var out: Dictionary = {}
	for k in a:
		var va: Variant = a[k]
		var vb: Variant = b[k]
		if va is Vector2:
			out[k] = (va as Vector2).lerp(vb as Vector2, t)
		else:
			out[k] = lerpf(float(va), float(vb), t)
	return out


static func _ease(u: float, e: int) -> float:
	match e:
		1: return 1.0 - pow(1.0 - u, 3.0)
		2: return u * u * u
		3: return u * u * (3.0 - 2.0 * u)
	return u


func _foot(s: float, k: float) -> Vector2:
	var duty: float = lerpf(0.42, 0.34, k)
	var x0: float = lerpf(11.0, 16.0, k)
	var x1: float = lerpf(-13.0, -34.0, k)
	if s < duty:
		var t: float = s / duty
		return Vector2(lerpf(x0, x1, t), -4.0 * pow(maxf(0.0, t - 0.7) / 0.3, 2.0))
	var u: float = (s - duty) / (1.0 - duty)
	var e: float = clampf(pow(u, 1.5) * (3.0 - 2.0 * u), 0.0, 1.0)
	var lift: float = lerpf(9.0, 26.0, k) * sin(clampf(u * 1.1, 0.0, 1.0) * PI)
	return Vector2(lerpf(x1, x0, e), -4.0 - lift + 4.0 * u)


func _pose_run(th: float) -> Dictionary:
	var s0: float = fposmod(th / TAU, 1.0)
	var c2: float = cos(th * 2.0 - 0.5)
	var s1: float = sin(th)
	var br: float = sin(_t * 3.2)
	var k: float = _spk
	var run: Dictionary = _P({
		"ff": _foot(s0, 0.0), "fb": _foot(fposmod(s0 + 0.5, 1.0), 0.0),
		"hy": -51.0 - 2.6 * sin(_t * 3.0) - 0.8 * c2, "hx": 0.4 * sin(th * 2.0 - 0.5),
		"lean": 0.32 + 0.03 * sin(_t * 3.0 + 0.4) + 0.01 * br,
		"hb": Vector2(1.0 + 3.0 * s1, 9.0 - 2.0 * cos(th)),
		"hf": Vector2(15.0, 9.0 + 1.2 * cos(th * 2.0 - 0.5)),
		"sw": 1.34 + 0.03 * sin(th * 2.0 - 0.6),
		"head": -0.2,
	})
	if k <= 0.001:
		return run
	var spr: Dictionary = _P({
		"ff": _foot(s0, 1.0), "fb": _foot(fposmod(s0 + 0.5, 1.0), 1.0),
		"hy": -35.0 - 2.4 * c2, "hx": 5.0 + 1.5 * sin(th * 2.0 - 0.5),
		"lean": 1.05 + 0.04 * sin(th * 2.0 + 0.4),
		"hb": Vector2(-4.0 + 9.0 * s1, 7.0 - 3.0 * cos(th)),
		"hf": Vector2(12.0 - 2.0 * s1, 9.0 + 2.0 * cos(th * 2.0 - 0.5)),
		"sw": 1.35 + 0.06 * sin(th * 2.0 - 0.6),
		"head": -0.55,
	})
	return _mix(run, spr, k)


## Боевая стойка, когда мир стоит (бой с боссом): ноги на земле, лёгкое дыхание.
func _pose_idle() -> Dictionary:
	var br: float = sin(_t * 3.4)
	return _P({
		"ff": Vector2(15, 0), "fb": Vector2(-13, 0),
		"hy": -44.0 + 0.8 * br, "lean": 0.2 + 0.015 * br,
		"hb": Vector2(7, 10), "hf": Vector2(17, 10 + 0.8 * br),
		"sw": 1.5 + 0.04 * br, "head": -0.08,
	})


func _pose_air() -> Dictionary:
	var rise: Dictionary = _P({"hy": -44.0, "lean": 0.12, "ff": Vector2(12, -22), "fb": Vector2(-10, -10), "hf": Vector2(10, -6), "hb": Vector2(-6, -8), "sw": 2.2, "head": -0.1})
	var apex: Dictionary = _P({"hy": -44.0, "lean": 0.18, "ff": Vector2(11, -14), "fb": Vector2(-6, -14), "hf": Vector2(10, -8), "hb": Vector2(-8, -6), "sw": 2.4})
	var fall: Dictionary = _P({"hy": -46.0, "lean": 0.22, "ff": Vector2(9, -3), "fb": Vector2(-9, -1), "hf": Vector2(8, -14), "hb": Vector2(-10, -14), "sw": 2.7, "head": 0.1})
	var t: float = clampf((vy + 700.0) / 1400.0, 0.0, 1.0)
	if t < 0.5:
		return _mix(rise, apex, t * 2.0)
	return _mix(apex, fall, (t - 0.5) * 2.0)


func _pose_loco() -> Dictionary:
	var p: Dictionary
	if on_ground:
		p = _pose_run(phase)
		if _stand_k > 0.001:
			p = _mix(p, _pose_idle(), _stand_k)
		if _land_t > 0.0:
			var w: float = clampf(_land_t / 0.14, 0.0, 1.0)
			var crouch: Dictionary = _P({"hy": -31.0, "lean": 0.58, "ff": Vector2(14, 0), "fb": Vector2(-16, 0), "hf": Vector2(10, 8), "hb": Vector2(12, 10), "sw": 1.9})
			p = _mix(p, crouch, w * w * 0.95)
	else:
		p = _pose_air()
		if _flip_t >= 0.0:
			var pr: float = clampf(_flip_t / 0.46, 0.0, 1.0)
			var tuck: Dictionary = _P({"hy": -40.0, "lean": 0.55, "ff": Vector2(8, -26), "fb": Vector2(2, -22), "hf": Vector2(8, 4), "hb": Vector2(10, 6), "sw": 1.6})
			p = _mix(p, tuck, sin(pr * PI) * 0.9)
			p["rot"] = (pr * pr * (3.0 - 2.0 * pr)) * TAU
	return p


func _pose_full() -> Dictionary:
	var loco: Dictionary = _pose_loco()
	var p: Dictionary = loco
	if _atk_kind >= 0:
		var f: float = clampf(_atk_t / _atk_dur, 0.0, 1.0)
		var a: Dictionary = _attack_pose(_atk_kind, f)
		var wb: float = clampf(f / 0.12, 0.0, 1.0) * clampf((1.0 - f) / 0.22, 0.0, 1.0)
		wb = wb * wb * (3.0 - 2.0 * wb)
		a["sw"] = float(loco["sw"]) + wrapf(float(a["sw"]) - float(loco["sw"]), -PI, PI) if wb < 0.999 else float(a["sw"])
		if not on_ground:
			# в воздухе ноги остаются «воздушными», меняется только корпус и руки
			var keep_f: Vector2 = loco["ff"]
			var keep_b: Vector2 = loco["fb"]
			var mixed: Dictionary = _mix(loco, a, wb)
			mixed["ff"] = keep_f
			mixed["fb"] = keep_b
			mixed["hy"] = float(loco["hy"])
			p = mixed
		else:
			p = _mix(loco, a, wb)
	if _cast_t > 0.0:
		var cw: float = clampf(_cast_t / 0.3, 0.0, 1.0)
		cw = minf(1.0, (1.0 - cw) * 6.0 + 0.0) if cw > 0.8 else cw / 0.8
		p["hb"] = (p["hb"] as Vector2).lerp(Vector2(25, -3), cw)
		p["lean"] = float(p["lean"]) + 0.05 * cw
	return p


func _kf(frames: Array, f: float) -> Dictionary:
	for i in range(frames.size() - 1):
		var f0: float = frames[i][0]
		var f1: float = frames[i + 1][0]
		if f <= f1 or i == frames.size() - 2:
			var u: float = clampf((f - f0) / maxf(f1 - f0, 0.0001), 0.0, 1.0)
			return _mix(frames[i][1], frames[i + 1][1], _ease(u, int(frames[i + 1][2])))
	return frames[frames.size() - 1][1]


func _attack_pose(kind: int, f: float) -> Dictionary:
	var run0: Dictionary = _P({"hy": -40.0, "ff": Vector2(10, 0), "fb": Vector2(-14, 0), "hf": Vector2(16, 11), "sw": 1.8})
	var frames: Array
	if kind == 0:
		# рубящий: замах плечом назад, локоть согнут, удар вниз-вперёд, задняя рука уходит назад
		frames = [
			[0.0, run0, 0],
			[0.22, _P({"hx": -4.0, "hy": -39.0, "lean": 0.08, "ff": Vector2(6, 0), "fb": Vector2(-18, 0), "hf": Vector2(-9, -11), "hb": Vector2(16, 2), "sw": 4.0, "head": -0.05}), 1],
			[0.36, _P({"hx": 5.0, "hy": -36.0, "lean": 0.46, "ff": Vector2(20, 0), "fb": Vector2(-15, 0), "hf": Vector2(17, -6), "hb": Vector2(-8, 8), "sw": 1.95}), 2],
			[0.46, _P({"hx": 9.0, "hy": -35.0, "lean": 0.58, "ff": Vector2(23, 0), "fb": Vector2(-14, 0), "hf": Vector2(19, 12), "hb": Vector2(-13, 6), "sw": 0.5, "head": 0.05}), 1],
			[0.75, _P({"hx": 7.0, "hy": -36.0, "lean": 0.5, "ff": Vector2(22, 0), "fb": Vector2(-14, 0), "hf": Vector2(17, 11), "hb": Vector2(-9, 9), "sw": 0.4}), 3],
			[1.0, run0, 3],
		]
	elif kind == 1:
		# восходящий: присед, подсечка снизу вверх, плечо ведёт руку
		frames = [
			[0.0, run0, 0],
			[0.22, _P({"hx": -5.0, "hy": -32.0, "lean": 0.58, "ff": Vector2(14, 0), "fb": Vector2(-19, 0), "hf": Vector2(-6, 14), "hb": Vector2(12, 5), "sw": -0.7}), 1],
			[0.38, _P({"hx": 5.0, "hy": -43.0, "lean": 0.12, "ff": Vector2(19, -3), "fb": Vector2(-12, -7), "hf": Vector2(14, -2), "hb": Vector2(-5, 9), "sw": 1.9}), 2],
			[0.48, _P({"hx": 8.0, "hy": -48.0, "lean": -0.06, "ff": Vector2(17, -6), "fb": Vector2(-9, -14), "hf": Vector2(10, -19), "hb": Vector2(-10, 8), "sw": 3.0, "head": -0.1}), 1],
			[0.78, _P({"hx": 7.0, "hy": -45.0, "lean": 0.05, "ff": Vector2(14, -2), "fb": Vector2(-8, -6), "hf": Vector2(9, -14), "hb": Vector2(-9, 9), "sw": 3.15}), 3],
			[1.0, run0, 3],
		]
	elif kind == 3:
		# рывок: отклон назад, выпад вперёд мечом на вытянутой руке, возврат
		frames = [
			[0.0, run0, 0],
			[0.16, _P({"hx": -7.0, "hy": -33.0, "lean": 0.1, "ff": Vector2(8, 0), "fb": Vector2(-20, 0), "hf": Vector2(-6, 8), "hb": Vector2(10, 6), "sw": 2.4}), 1],
			[0.32, _P({"hx": 12.0, "hy": -32.0, "lean": 1.0, "ff": Vector2(30, -2), "fb": Vector2(-30, -6), "hf": Vector2(20, 2), "hb": Vector2(-10, 6), "sw": 1.57, "head": -0.5}), 2],
			[0.5, _P({"hx": 16.0, "hy": -31.0, "lean": 1.05, "ff": Vector2(32, -1), "fb": Vector2(-32, -5), "hf": Vector2(21, 2), "hb": Vector2(-12, 6), "sw": 1.55, "head": -0.5}), 1],
			[0.8, _P({"hx": 8.0, "hy": -38.0, "lean": 0.6, "ff": Vector2(18, 0), "fb": Vector2(-16, 0), "hf": Vector2(17, 8), "hb": Vector2(-4, 10), "sw": 1.7}), 3],
			[1.0, run0, 3],
		]
	else:
		# вращение: тело закручивается, обе руки у корпуса
		frames = [
			[0.0, run0, 0],
			[0.18, _P({"hx": -6.0, "hy": -34.0, "lean": 0.38, "ff": Vector2(10, 0), "fb": Vector2(-18, 0), "hf": Vector2(-8, 5), "hb": Vector2(8, 5), "sw": -0.3}), 1],
			[0.28, _P({"hx": 5.0, "hy": -42.0, "lean": 0.3, "ff": Vector2(17, -6), "fb": Vector2(-13, -9), "hf": Vector2(3, 0), "hb": Vector2(-3, 6), "sw": 1.5, "hp": 1.0}), 2],
			[0.40, _P({"hx": 11.0, "hy": -43.0, "lean": 0.33, "ff": Vector2(19, -7), "fb": Vector2(-11, -11), "hf": Vector2(3, 0), "hb": Vector2(-3, 6), "sw": 4.7, "hp": 1.0}), 0],
			[0.52, _P({"hx": 13.0, "hy": -40.0, "lean": 0.42, "ff": Vector2(22, -2), "fb": Vector2(-10, -6), "hf": Vector2(3, 0), "hb": Vector2(-3, 6), "sw": 6.4, "hp": 1.0}), 1],
			[0.75, _P({"hx": 10.0, "hy": -37.0, "lean": 0.48, "ff": Vector2(21, 0), "fb": Vector2(-13, 0), "hf": Vector2(14, 8), "hb": Vector2(-8, 10), "sw": 6.5, "hp": 0.4}), 3],
			[1.0, _P({"hy": -40.0, "ff": Vector2(10, 0), "fb": Vector2(-14, 0), "sw": 8.08}), 3],
		]
	return _kf(frames, f)


# ====================================================================== скелет

static func _dir(a: float) -> Vector2:
	return Vector2(sin(a), cos(a))


static func _rot(v: Vector2, a: float) -> Vector2:
	var c: float = cos(a)
	var s: float = sin(a)
	return Vector2(v.x * c - v.y * s, v.x * s + v.y * c)


## Двухзвенный IK. pref: +1 — сустав вниз/назад (локоть), -1 — вперёд (колено).
static func _ik(base: Vector2, target: Vector2, l1: float, l2: float, knee: bool) -> Vector2:
	var d: Vector2 = target - base
	var dist: float = clampf(d.length(), absf(l1 - l2) + 0.5, l1 + l2 - 0.1)
	if d.length() < 0.001:
		return base + Vector2(0, l1)
	var dn: Vector2 = d.normalized()
	var cosa: float = clampf((l1 * l1 + dist * dist - l2 * l2) / (2.0 * l1 * dist), -1.0, 1.0)
	var ang: float = acos(cosa)
	var m1: Vector2 = base + _rot(dn, ang) * l1
	var m2: Vector2 = base + _rot(dn, -ang) * l1
	if knee:
		return m1 if m1.x > m2.x else m2
	return m1 if m1.y > m2.y else m2


func _skeleton(p: Dictionary) -> Dictionary:
	var lean: float = p["lean"]
	var hip: Vector2 = Vector2(float(p["hx"]), float(p["hy"]))
	var chest: Vector2 = hip + Vector2(sin(lean), -cos(lean)) * 29.0
	var neck: Vector2 = chest + Vector2(sin(lean + 0.08), -cos(lean + 0.08)) * 4.0
	var head: Vector2 = neck + Vector2(sin(lean + 0.1 + float(p["head"])), -cos(lean + 0.1 + float(p["head"]))) * 8.0
	var sh_f: Vector2 = chest + _rot(Vector2(3.0, 4.5), lean)
	var sh_b: Vector2 = chest + _rot(Vector2(-4.0, 4.5), lean)
	var sw: float = p["sw"]
	var hf: Vector2 = p["hf"]
	var hp: float = p["hp"]
	if hp > 0.0:
		hf = hf.lerp(_dir(sw) * 11.0 + Vector2(0, -2), clampf(hp, 0.0, 1.0))
	var hand_f: Vector2 = sh_f + hf
	var hand_b: Vector2 = sh_b + (p["hb"] as Vector2)
	var hip_f: Vector2 = hip + Vector2(2.5, 1.0)
	var hip_b: Vector2 = hip + Vector2(-2.5, 1.0)
	var foot_f: Vector2 = p["ff"]
	var foot_b: Vector2 = p["fb"]
	foot_f.x += float(p["hx"])
	foot_b.x += float(p["hx"])
	var sk: Dictionary = {
		"hip": hip, "chest": chest, "neck": neck, "head": head,
		"sh_f": sh_f, "sh_b": sh_b, "hand_f": hand_f, "hand_b": hand_b,
		"el_f": _ik(sh_f, hand_f, 15.0, 14.0, false), "el_b": _ik(sh_b, hand_b, 15.0, 14.0, false),
		"hip_f": hip_f, "hip_b": hip_b, "foot_f": foot_f, "foot_b": foot_b,
		"kn_f": _ik(hip_f, foot_f, 24.0, 24.0, true), "kn_b": _ik(hip_b, foot_b, 24.0, 24.0, true),
		"sw": sw, "lean": lean, "rot": p["rot"],
	}
	sk["blade_b"] = _to_canvas(hand_f + _dir(sw) * 6.0, sk)
	sk["blade_t"] = _to_canvas(hand_f + _dir(sw) * 44.0, sk)
	return sk


func _to_canvas(u: Vector2, sk: Dictionary) -> Vector2:
	var r: float = sk["rot"]
	if absf(r) > 0.001:
		var pivot: Vector2 = (sk["hip"] as Vector2) + Vector2(0, -12)
		u = pivot + _rot(u - pivot, r)
	return Vector2(float(OX), float(OY)) + u * K


# ====================================================================== ткань

func _init_chain(ch: Array, n: int) -> void:
	ch.clear()
	for i in range(n):
		ch.append({"p": Vector2(float(OX) - float(i) * 4.0, float(OY) - 55.0), "o": Vector2(float(OX) - float(i) * 4.0, float(OY) - 55.0)})


func _step_chain(ch: Array, anchor: Vector2, seg: float, wind: float, grav: float, flutter: float, shift_y: float, h: float) -> void:
	(ch[0] as Dictionary)["p"] = anchor
	(ch[0] as Dictionary)["o"] = anchor
	for i in range(1, ch.size()):
		var c: Dictionary = ch[i]
		var p: Vector2 = c["p"]
		var o: Vector2 = c["o"]
		p.y -= shift_y
		o.y -= shift_y
		var v: Vector2 = (p - o) * 0.9
		c["o"] = p
		var acc := Vector2(-wind, grav + sin(_t * 11.0 + float(i) * 1.4) * flutter)
		c["p"] = p + v + acc * h * h
	for it in range(3):
		for i in range(1, ch.size()):
			var cp: Vector2 = (ch[i] as Dictionary)["p"]
			cp.x = minf(cp.x, anchor.x + 0.5)   # ткань не бывает впереди точки крепления
			(ch[i] as Dictionary)["p"] = cp
			var a: Vector2 = (ch[i - 1] as Dictionary)["p"]
			var b: Vector2 = (ch[i] as Dictionary)["p"]
			var d: Vector2 = b - a
			var l: float = d.length()
			if l > 0.001:
				(ch[i] as Dictionary)["p"] = a + d / l * seg


func _sim_cloth(delta: float, world_speed: float, pose: Dictionary) -> void:
	var sk: Dictionary = _skeleton(pose)
	_last_sk = sk
	var steps: int = clampi(int(ceil(delta * 60.0)), 1, 4)
	var h: float = delta / float(steps)
	var wind: float = 900.0 + world_speed * 5.0
	if not on_ground:
		wind *= 0.7
	var neck_c: Vector2 = _to_canvas((sk["neck"] as Vector2) + Vector2(-2, 0), sk)
	var back_c: Vector2 = _to_canvas((sk["chest"] as Vector2) + _rot(Vector2(-6, 4), float(sk["lean"])), sk)
	var waist_c: Vector2 = _to_canvas((sk["hip"] as Vector2) + _rot(Vector2(-5, -4), float(sk["lean"])), sk)
	var head_c: Vector2 = _to_canvas((sk["head"] as Vector2) + Vector2(-7, -3), sk)
	var shift: float = hero_dy_px
	for s in range(steps):
		_step_chain(_scarf, neck_c + Vector2(-1, 1) * S, 4.6 * S, wind * 1.0, 260.0, 380.0, shift if s == 0 else 0.0, h)
		_step_chain(_cape_a, back_c, 6.4 * S, wind * 1.7, 90.0, 260.0, shift if s == 0 else 0.0, h)
		_step_chain(_cape_b, waist_c, 6.2 * S, wind * 1.5, 160.0, 320.0, shift if s == 0 else 0.0, h)
		_step_chain(_hood, head_c, 3.6 * S, wind * 0.9, 240.0, 300.0, shift if s == 0 else 0.0, h)


# ====================================================================== растеризация

func _put(x: int, y: int, id: int) -> void:
	if x < 0 or y < 0 or x >= W or y >= H:
		return
	_ids[y * W + x] = id
	if x < _bx0:
		_bx0 = x
	if x > _bx1:
		_bx1 = x
	if y < _by0:
		_by0 = y
	if y > _by1:
		_by1 = y


func _disc(c: Vector2, r_in: float, id: int) -> void:
	var r: float = r_in * S
	var x0: int = int(floor(c.x - r))
	var x1: int = int(ceil(c.x + r))
	var y0: int = int(floor(c.y - r))
	var y1: int = int(ceil(c.y + r))
	var r2: float = r * r
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			var dx: float = float(x) + 0.5 - c.x
			var dy: float = float(y) + 0.5 - c.y
			if dx * dx + dy * dy <= r2:
				_put(x, y, id)


func _line(a: Vector2, b: Vector2, w: float, id: int) -> void:
	var n: int = maxi(1, int(a.distance_to(b) * 2.0))
	for i in range(n + 1):
		_disc(a.lerp(b, float(i) / float(n)), w * 0.5, id)


func _limb(a: Vector2, b: Vector2, w0: float, w1: float, id: int) -> void:
	var n: int = maxi(1, int(a.distance_to(b) * 1.5))
	for i in range(n + 1):
		var f: float = float(i) / float(n)
		_disc(a.lerp(b, f), lerpf(w0, w1, f) * 0.5, id)


func _poly(pts: PackedVector2Array, id: int) -> void:
	var n: int = pts.size()
	if n < 3:
		return
	var ymin: float = pts[0].y
	var ymax: float = pts[0].y
	for p in pts:
		ymin = minf(ymin, p.y)
		ymax = maxf(ymax, p.y)
	for y in range(int(floor(ymin)), int(ceil(ymax)) + 1):
		var yc: float = float(y) + 0.5
		var xs: Array[float] = []
		for i in range(n):
			var p: Vector2 = pts[i]
			var q: Vector2 = pts[(i + 1) % n]
			if (p.y <= yc and q.y > yc) or (q.y <= yc and p.y > yc):
				xs.append(p.x + (yc - p.y) / (q.y - p.y) * (q.x - p.x))
		xs.sort()
		var k: int = 0
		while k + 1 < xs.size():
			for x in range(int(round(xs[k])), int(round(xs[k + 1]))):
				_put(x, y, id)
			k += 2


## Лента ткани между цепью и смещённой копией (ширина меняется вдоль цепи).
func _strip(ch: Array, w0: float, w1: float, id: int, side: Vector2 = Vector2(0, 1)) -> void:
	var n: int = ch.size()
	var up := PackedVector2Array()
	var dn := PackedVector2Array()
	for i in range(n):
		var p: Vector2 = (ch[i] as Dictionary)["p"]
		var dirv: Vector2
		if i < n - 1:
			dirv = (ch[i + 1] as Dictionary)["p"] - p
		else:
			dirv = p - (ch[i - 1] as Dictionary)["p"]
		var nrm: Vector2 = dirv.normalized().orthogonal()
		var w: float = lerpf(w0, w1, float(i) / float(n - 1)) * 0.5 * S
		up.append(p + nrm * w)
		dn.append(p - nrm * w)
	for i in range(n - 1):
		_poly(PackedVector2Array([up[i], up[i + 1], dn[i + 1], dn[i]]), id)


func _cv(u: Vector2, sk: Dictionary) -> Vector2:
	return _to_canvas(u, sk)


func _boot(foot: Vector2, shin_dir: Vector2, sk: Dictionary, id: int) -> void:
	var ang: float = atan2(shin_dir.x, shin_dir.y) * 0.6
	var fwd: Vector2 = _rot(Vector2(1, 0), -ang)
	var dn: Vector2 = _rot(Vector2(0, 1), -ang)
	var heel: Vector2 = foot - fwd * 4.5
	var toe: Vector2 = foot + fwd * 9.5
	_poly(PackedVector2Array([_cv(heel - dn * 6.0, sk), _cv(foot - dn * 6.0 + fwd * 3.0, sk), _cv(toe, sk), _cv(toe + dn * 3.0, sk), _cv(heel + dn * 3.0, sk)]), id)


func _render_all(p: Dictionary) -> void:
	_ids.fill(0)
	_bx0 = W
	_bx1 = 0
	_by0 = H
	_by1 = 0
	var sk: Dictionary = _skeleton(p)
	_last_sk = sk
	var lean: float = sk["lean"]
	var hip: Vector2 = sk["hip"]
	var chest: Vector2 = sk["chest"]
	var neck: Vector2 = sk["neck"]
	var head: Vector2 = sk["head"]
	var fwd_n: Vector2 = (chest - hip).normalized().orthogonal()   # поперёк торса

	# --- плащ (короткий, за спиной)
	var cape := PackedVector2Array()
	for i in range(_cape_a.size()):
		cape.append((_cape_a[i] as Dictionary)["p"])
	for i in range(_cape_b.size() - 1, -1, -1):
		cape.append((_cape_b[i] as Dictionary)["p"] + Vector2(0, (7.0 + float(i) * 2.6) * S))
	_poly(cape, M_COAT)
	var cape_in := PackedVector2Array()
	for i in range(_cape_a.size()):
		cape_in.append(((_cape_a[i] as Dictionary)["p"] as Vector2).lerp((_cape_b[i] as Dictionary)["p"], 0.35) + Vector2(0, 1.0))
	for i in range(_cape_b.size() - 1, -1, -1):
		cape_in.append(((_cape_b[i] as Dictionary)["p"] as Vector2) + Vector2(0, (2.5 + float(i) * 1.4) * S))
	_poly(cape_in, M_ARMOR_D)

	# --- дальние: рука и нога
	var hb: Vector2 = _cv(sk["hand_b"], sk)
	var elb: Vector2 = _cv(sk["el_b"], sk)
	_limb(_cv(sk["sh_b"], sk), elb, 7.6, 6.6, M_COAT)
	_limb(elb, hb, 6.2, 5.4, M_SKIN)
	_limb(elb.lerp(hb, 0.5), hb.lerp(elb, 0.12), 5.8, 5.4, M_LEATHER)
	_disc(hb, 2.8, M_SKIN)
	_cast_pt = hb
	# --- куртка с полами, торс, воротник, ремень
	var skirt_sw: float = 3.0 * sin(phase + 0.6) if on_ground else -4.0
	_poly(PackedVector2Array([_cv(hip + fwd_n * 8.5, sk), _cv(hip - fwd_n * 8.5, sk), _cv(hip - fwd_n * 8.0 + Vector2(-6.0 + skirt_sw, 15.0), sk), _cv(hip + Vector2(skirt_sw * 0.5, 17.0), sk), _cv(hip + fwd_n * 8.0 + Vector2(5.0 + skirt_sw, 14.0), sk)]), M_COAT)
	var w0: float = 8.6
	var w1: float = 11.5
	_poly(PackedVector2Array([_cv(hip + fwd_n * w0, sk), _cv(chest + fwd_n * w1, sk), _cv(chest - fwd_n * w1, sk), _cv(hip - fwd_n * w0, sk)]), M_COAT)
	var mid: Vector2 = hip.lerp(chest, 0.7)
	_poly(PackedVector2Array([_cv(hip + fwd_n * 9.0, sk), _cv(hip - fwd_n * 9.0, sk), _cv(hip - fwd_n * 11.0 + Vector2(-5.0 + skirt_sw, 26.0), sk), _cv(hip + fwd_n * 11.0 + Vector2(6.0 + skirt_sw, 25.0), sk)]), M_COAT)
	_line(_cv(chest - fwd_n * 6.0, sk), _cv(hip + fwd_n * 3.0, sk), 1.0, M_ARMOR_L)
	_line(_cv(hip.lerp(chest, 0.1) - fwd_n * w0, sk), _cv(hip.lerp(chest, 0.1) + fwd_n * w0, sk), 2.6, M_LEATHER)
	_disc(_cv(hip.lerp(chest, 0.1) + fwd_n * 1.5, sk), 1.4, M_RUNE)
	_line(_cv(chest.lerp(hip, 0.35), sk), _cv(hip.lerp(chest, 0.1), sk), 1.0, M_ARMOR_D)

	# --- шея и голова: глухой шлем, корона, тлеющие глаза
	var nk: Vector2 = _cv(neck, sk)
	var hc: Vector2 = _cv(head, sk)
	_limb(_cv(chest, sk), hc, 4.8, 4.4, M_ARMOR_D)
	_strip(_hood, 2.6, 0.8, M_COAT)   # плюмаж / лоскут за шлемом
	var hx: int = int(round(hc.x))
	var hy: int = int(round(hc.y))
	# голова странника: тень под широкой шляпой-кэса, светящиеся глаза, тлеющее кольцо
	_disc(Vector2(hc.x + 0.5, hc.y + 1.5), 7.4, M_MASK)
	_poly(PackedVector2Array([Vector2(hx - 5, hy + 4), Vector2(hx + 7, hy + 4), Vector2(hx + 5, hy + 9), Vector2(hx - 3, hy + 9)]), M_MASK)
	for ang in range(-70, 90, 4):
		var ra: float = deg_to_rad(float(ang))
		_put(hx - 2 + int(round(cos(ra + PI) * 10.0)), hy + 1 + int(round(sin(ra + PI) * 10.0)), M_WHITE)
	var angry: bool = _atk_kind >= 0 or rage
	_put(hx + 5, hy + 1, M_WHITE)
	_put(hx + 5, hy + 2, M_WHITE)
	_put(hx + 8, hy + 1, M_WHITE)
	if angry:
		_put(hx + 6, hy + 1, M_RUNE)
		_put(hx + 4, hy + 1, M_RUNE)
	# шляпа: конус + широкие поля
	_poly(PackedVector2Array([Vector2(hx - 11, hy - 3), Vector2(hx + 3, hy - 14), Vector2(hx + 16, hy - 3)]), M_HAIR)
	_line(Vector2(hx - 11, hy - 3), Vector2(hx + 3, hy - 14), 1.0, M_ARMOR_L)
	_line(Vector2(hx - 15, hy - 2), Vector2(hx + 20, hy - 2), 2.6, M_HAIR)
	_line(Vector2(hx - 13, hy - 3), Vector2(hx + 18, hy - 3), 1.0, M_ARMOR_L)
	_put(hx + 3, hy - 15, M_BONE)
	# --- шарф: обмотка и хвост
	_line(nk + Vector2(-3, 2) * S, nk + Vector2(5, 3) * S, 3.0, M_SCARF)
	_strip(_scarf, 3.6, 1.2, M_SCARF)

	# --- длинный халат вместо ног: парит над землёй, подол вьётся
	var fl: float = 2.2 * sin(phase * 2.0 + 0.5) + 1.2 * sin(_t * 7.0)
	var back: float = -5.0 - 2.0 * _spk * 3.0
	var rl: float = 36.0
	var hem_c: Vector2 = hip + Vector2(back, rl)
	var mid_c: Vector2 = hip.lerp(hem_c, 0.55)
	_poly(PackedVector2Array([_cv(hip + fwd_n * 10.0, sk), _cv(hip - fwd_n * 11.0, sk),
		_cv(mid_c + Vector2(-12.0 + fl * 0.5, 0.0), sk), _cv(hem_c + Vector2(-13.0, -2.0 + fl), sk), _cv(hem_c + Vector2(-6.0, 3.0 - fl), sk),
		_cv(hem_c + Vector2(1.0, 1.0 + fl), sk), _cv(hem_c + Vector2(7.0, 2.0 - fl), sk), _cv(mid_c + Vector2(9.0, 0.0), sk)]), M_COAT)
	_line(_cv(hip + fwd_n * 3.0, sk), _cv(hem_c + Vector2(2.0, -2.0), sk), 1.0, M_ARMOR_L)
	_line(_cv(hip - fwd_n * 6.0, sk), _cv(hem_c + Vector2(-8.0, -1.0), sk), 1.0, M_ARMOR_D)

	# --- ближняя рука с мечом: рукав, голое предплечье с наручем, ладонь
	var shf: Vector2 = _cv(sk["sh_f"], sk)
	var elf: Vector2 = _cv(sk["el_f"], sk)
	var hdf: Vector2 = _cv(sk["hand_f"], sk)
	_limb(shf, elf, 8.6, 7.4, M_COAT)
	_limb(elf, hdf, 7.0, 6.0, M_SKIN)
	_limb(elf.lerp(hdf, 0.45), hdf.lerp(elf, 0.12), 6.6, 6.2, M_LEATHER)
	_disc(elf, 3.0, M_COAT)
	_disc(hdf, 3.2, M_SKIN)
	var sdir: Vector2 = _dir(float(sk["sw"]))
	var gp: Vector2 = Vector2.ZERO
	var tip: Vector2 = Vector2.ZERO
	var b0: Vector2 = _cv((sk["hand_f"] as Vector2) - sdir * 5.0, sk)
	var b1: Vector2 = _cv((sk["hand_f"] as Vector2) + sdir * 3.0, sk)
	_line(b0, b1, 2.8, M_LEATHER)
	_disc(b0, 1.9, M_GOLD)
	_disc(hdf, 2.2, M_SKIN)
	# --- коса: длинное древко с красными обмотками, шипастая втулка, изогнутое лезвие
	var hp0: Vector2 = (sk["hand_f"] as Vector2)
	var dn: Vector2 = _rot(sdir, PI * 0.5)
	if dn.y < 0.0:
		dn = -dn
	var head_u: Vector2 = hp0 + sdir * 40.0
	var back_c: Vector2 = _cv(hp0 - sdir * 26.0, sk)
	var head_c: Vector2 = _cv(head_u, sk)
	gp = head_c
	_line(back_c, head_c, 3.4, M_ARMOR_L)
	_line(back_c, head_c, 1.0, M_ARMOR_D)
	for t in [0.18, 0.34, 0.56]:
		var wp: Vector2 = back_c.lerp(head_c, t)
		_line(wp - Vector2(1.0, 0.0), wp + Vector2(1.0, 1.0), 3.8, M_SCARF)
	# красный наконечник на заднем конце
	_poly(PackedVector2Array([back_c + Vector2(2.0, -2.0), back_c + Vector2(2.0, 2.0), _cv(hp0 - sdir * 34.0, sk)]), M_SCARF)
	# лезвие
	var outer := PackedVector2Array()
	var inner := PackedVector2Array()
	for i in range(0, 11):
		var t: float = float(i) / 10.0
		var ie: Vector2 = head_u + sdir * (40.0 * t) + dn * (30.0 * t * t)
		var wdt: float = 13.0 * pow(1.0 - t, 0.85) + 0.4
		inner.append(_cv(ie, sk))
		outer.append(_cv(ie - dn * wdt - sdir * 0.0, sk))
	var blade := PackedVector2Array()
	blade.append_array(outer)
	for i in range(inner.size() - 1, -1, -1):
		blade.append(inner[i])
	_poly(blade, M_STEEL)
	for i in range(0, inner.size() - 1):
		_line(inner[i], inner[i + 1], 1.3, M_RUNE)
	tip = _cv(head_u + sdir * 40.0 + dn * 30.0, sk)
	var mid_t: Vector2 = _cv(head_u + sdir * 24.0 + dn * 12.0, sk)
	blade_tip_local = (tip - Vector2(float(OX), float(OY))) * float(Game.PIXEL)
	blade_mid_local = (mid_t - Vector2(float(OX), float(OY))) * float(Game.PIXEL)
	# шипастая втулка
	for k in range(8):
		var ang: float = float(k) * TAU / 8.0 + 0.2
		var d: Vector2 = Vector2(cos(ang), sin(ang))
		_line(head_c + d * 4.0, head_c + d * 9.0, 2.2, M_STEEL)
	_disc(head_c, 5.0, M_ARMOR_L)
	_disc(head_c, 3.0, M_SCARF)
	_put(int(round(head_c.x)), int(round(head_c.y)), M_RUNE)
	_disc(hdf, 2.2, M_SKIN)
	_bake(sk)
	_render_fx(sk)


func _bake(sk: Dictionary) -> void:
	var pal: Dictionary = _pal_rage if rage else _pal
	_img.fill(Color(0, 0, 0, 0))
	var x0: int = maxi(_bx0 - 1, 0)
	var x1: int = mini(_bx1 + 1, W - 1)
	var y0: int = maxi(_by0 - 1, 0)
	var y1: int = mini(_by1 + 1, H - 1)
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			var id: int = _ids[y * W + x]
			if id == 0:
				var near: bool = false
				if x > 0 and _ids[y * W + x - 1] != 0:
					near = true
				elif x < W - 1 and _ids[y * W + x + 1] != 0:
					near = true
				elif y > 0 and _ids[(y - 1) * W + x] != 0:
					near = true
				elif y < H - 1 and _ids[(y + 1) * W + x] != 0:
					near = true
				if near:
					_img.set_pixel(x, y, OUTLINE)
				continue
			if id >= M_DARK:
				var flat: Color = Color(0.09, 0.04, 0.10)
				if id == M_WHITE:
					flat = Color(0.97, 0.97, 1.0)
				elif id == M_IRIS:
					flat = Color(1.0, 0.35, 0.1) if rage else Color(0.25, 0.7, 0.95)
				elif id == M_LIP:
					flat = Color(0.62, 0.22, 0.26)
				elif id == M_FULLER:
					flat = Color(0.40, 0.47, 0.62)
				elif id == M_RUNE:
					flat = Color(1.0, 0.97, 0.7) if rage else Color(1.0, 0.52, 0.10)
				_img.set_pixel(x, y, flat)
				continue
			var tri: Array = pal[id]
			var up: int = _ids[(y - 1) * W + x] if y > 0 else 0
			var dn: int = _ids[(y + 1) * W + x] if y < H - 1 else 0
			var lf: int = _ids[y * W + x - 1] if x > 0 else 0
			var col: Color = tri[1]
			if up != id:
				col = tri[2]
			elif dn != id or lf != id:
				col = tri[0]
			_img.set_pixel(x, y, col)
	_tex.update(_img)


# ====================================================================== эффекты (аддитивный слой)

func _fxp(x: int, y: int, c: Color) -> void:
	if x < 0 or y < 0 or x >= W or y >= H:
		return
	var o: Color = _fx_img.get_pixel(x, y)
	if c.a > o.a:
		_fx_img.set_pixel(x, y, c)


func _fx_poly(pts: PackedVector2Array, c: Color) -> void:
	var n: int = pts.size()
	var ymin: float = pts[0].y
	var ymax: float = pts[0].y
	for p in pts:
		ymin = minf(ymin, p.y)
		ymax = maxf(ymax, p.y)
	for y in range(int(floor(ymin)), int(ceil(ymax)) + 1):
		var yc: float = float(y) + 0.5
		var xs: Array[float] = []
		for i in range(n):
			var p: Vector2 = pts[i]
			var q: Vector2 = pts[(i + 1) % n]
			if (p.y <= yc and q.y > yc) or (q.y <= yc and p.y > yc):
				xs.append(p.x + (yc - p.y) / (q.y - p.y) * (q.x - p.x))
		xs.sort()
		var k: int = 0
		while k + 1 < xs.size():
			for x in range(int(round(xs[k])), int(round(xs[k + 1]))):
				_fxp(x, y, c)
			k += 2


func _trail_color(age: float) -> Color:
	if age < 0.22:
		return Color(1.0, 1.0, 0.92, 0.95)
	if age < 0.45:
		return Color(1.0, 0.86, 0.45, 0.8)
	if age < 0.72:
		return Color(1.0, 0.52, 0.2, 0.6)
	return Color(0.8, 0.18, 0.12, 0.4)


## Ступень сияния меча по уровню «Клинка Рассвета».
func _sword_tier() -> int:
	var lv: int = sword_lv
	if lv < 5:
		return 0
	if lv < 15:
		return 1
	if lv < 35:
		return 2
	if lv < 70:
		return 3
	if lv < 120:
		return 4
	return 5


## Светлое сияние вдоль клинка и извивающиеся лучи-«щупальца».
func _sword_glow(sk: Dictionary) -> void:
	var tier: int = _sword_tier()
	if tier == 0:
		return
	var b: Vector2 = sk["blade_b"]
	var t: Vector2 = sk["blade_t"]
	var axis: Vector2 = t - b
	var perp: Vector2 = axis.orthogonal().normalized()
	var col: Vector3 = Vector3(1.0, 0.92, 0.6) if rage else Vector3(1.0, 0.55, 0.15)
	# ореол
	var halo: float = 2.2 + 0.9 * float(tier)
	for i in range(14):
		var p: Vector2 = b.lerp(t, float(i) / 13.0)
		for dy in range(-6, 7):
			for dx in range(-6, 7):
				var d: float = sqrt(float(dx * dx + dy * dy))
				if d <= halo:
					var a: float = (1.0 - d / halo) * (0.16 + 0.03 * float(tier)) * (0.8 + 0.2 * sin(_t * 7.0 + float(i)))
					_fxp(int(p.x) + dx, int(p.y) + dy, Color(col.x, col.y, col.z, a))
	# лучи
	var n: int = 2 + tier * 2
	var length: int = 8 + tier * 4
	for k in range(n):
		var u: float = 0.25 + 0.75 * float(k) / float(maxi(n - 1, 1))
		var pos: Vector2 = b.lerp(t, u)
		var side: float = 1.0 if k % 2 == 0 else -1.0
		var dir: Vector2 = (perp * side * 0.9 + axis.normalized() * 0.5).normalized()
		var ph: float = _t * (3.0 + 0.4 * float(k % 3)) + float(k) * 1.9
		for s in range(length):
			var f: float = float(s) / float(length)
			var a2: float = (1.0 - f) * 0.9
			var w: int = 1 if f < 0.6 else 0
			for ox in range(-w, w + 1):
				_fxp(int(pos.x) + ox, int(pos.y), Color(col.x, col.y, col.z, a2 * (0.55 if ox != 0 else 1.0)))
				if f < 0.35:
					_fxp(int(pos.x) + ox, int(pos.y) + 1, Color(col.x, col.y, col.z, a2 * 0.5))
			dir = dir.rotated(sin(ph + f * 5.5) * 0.28)
			pos += dir * 1.0
	# яркое ядро у острия
	for dy in range(-2, 3):
		for dx in range(-2, 3):
			if absi(dx) + absi(dy) <= 2:
				_fxp(int(t.x) + dx, int(t.y) + dy, Color(1, 1, 1, 0.9 - 0.25 * float(absi(dx) + absi(dy))))


func _render_fx(sk: Dictionary) -> void:
	_fx_img.fill(Color(0, 0, 0, 0))
	var n: int = _trail.size()
	for i in range(n - 1):
		var a: Dictionary = _trail[i]
		var b: Dictionary = _trail[i + 1]
		var age: float = (_t - float(b["t"])) / 0.16
		if age >= 1.0:
			continue
		var c: Color = _trail_color(age)
		var b0: Vector2 = a["b"]
		var t0: Vector2 = a["tip"]
		var b1: Vector2 = b["b"]
		var t1: Vector2 = b["tip"]
		# клинок «размазан» по всей длине: от рукояти до острия
		_fx_poly(PackedVector2Array([b0.lerp(t0, 0.5), t0, t1, b1.lerp(t1, 0.5)]), c)
	_sword_glow(sk)
	# вспышка на конце руки при выстреле
	if _cast_t > 0.0:
		var f: float = clampf(_cast_t / 0.3, 0.0, 1.0)
		var cp: Vector2 = _cast_pt + Vector2(3, 0)
		var r: float = 2.0 + 5.0 * f
		for y in range(-8, 9):
			for x in range(-8, 9):
				var d: float = sqrt(float(x * x + y * y))
				if d <= r:
					var c2: Color = Color(1, 1, 1, 0.95) if d < r * 0.4 else (Color(0.5, 0.9, 1.0, 0.8) if d < r * 0.75 else Color(0.2, 0.5, 1.0, 0.55))
					_fxp(int(cp.x) + x, int(cp.y) + y, c2)
	# аура ярости
	if rage:
		var base: Vector2 = Vector2(float(OX), float(OY)) + (sk["hip"] as Vector2) * K
		for i in range(7):
			var ph: float = _t * 7.0 + float(i) * 1.7
			var hgt: float = 12.0 + 10.0 * (0.5 + 0.5 * sin(ph * 1.3)) + float(i % 3) * 4.0
			var bx: float = base.x - 12.0 + float(i) * 4.0 + sin(ph) * 2.0
			var by: float = base.y + 14.0
			for j in range(int(hgt)):
				var f2: float = float(j) / hgt
				var wd: int = int((1.0 - f2) * 3.0)
				var col: Color = Color(1.0, 0.85 - f2 * 0.5, 0.3 - f2 * 0.2, 0.55 * (1.0 - f2))
				for xx in range(-wd, wd + 1):
					_fxp(int(bx) + xx, int(by) - j - int(sin(ph + f2 * 3.0) * 2.0), col)


func _update_ghosts(delta: float, world_speed: float) -> void:
	var want: bool = rage or _atk_kind == 2 or _atk_kind == 3 or _flip_t >= 0.0
	_ghost_acc += delta
	if want and _ghost_acc >= 0.045:
		_ghost_acc = 0.0
		var tex: ImageTexture = _ghost_pool[0]
		_ghost_pool.pop_front()
		_ghost_pool.append(tex)
		tex.update(_img)
		_ghosts.append({"tex": tex, "age": 0.0, "x": 0.0, "y": 0.0})
		if _ghosts.size() > 5:
			_ghosts.pop_front()
	for g in _ghosts:
		g["age"] = float(g["age"]) + delta
		g["x"] = float(g["x"]) - world_speed * delta
	_ghosts = _ghosts.filter(func(g: Dictionary) -> bool: return float(g["age"]) < 0.26)


# ====================================================================== вывод

func _draw() -> void:
	var px: float = float(Game.PIXEL)
	# тень остаётся на дороге, уменьшаясь с высотой
	var k: float = clampf(1.0 - shadow_dy / 420.0, 0.35, 1.0)
	for i in range(3):
		var w: float = (26.0 - float(i) * 7.0) * px * k
		draw_rect(Rect2(-w * 0.5 - 2.0, shadow_dy + 2.0 + float(i) * px, w, px), Color(0, 0, 0, 0.38 * k))
	draw_texture_rect(_tex, Rect2(-float(OX) * px, -float(OY) * px, float(W) * px, float(H) * px), false)
	# отражение на полу: полосами с затуханием вниз
	if shadow_dy < 40.0:
		var step: int = 12
		for b in range(6):
			var src_bottom: float = float(OY) - float(b * step)
			var src := Rect2(0.0, src_bottom - float(step), float(W), float(step))
			var dst_y: float = shadow_dy + 3.0 + float(b * step) * px
			var dst := Rect2(-float(OX) * px, dst_y + float(step) * px, float(W) * px, -float(step) * px)
			draw_texture_rect_region(_tex, dst, src, Color(0.7, 0.6, 0.9, 0.26 * (1.0 - float(b) / 6.0)))


func _draw_fx() -> void:
	var px: float = float(Game.PIXEL)
	for g in _ghosts:
		var a: float = (1.0 - float(g["age"]) / 0.26) * 0.38
		var col: Color = Color(1.0, 0.7, 0.3, a) if rage else Color(0.85, 0.35, 0.12, a)
		_fxn.draw_texture_rect(g["tex"], Rect2(-float(OX) * px + float(g["x"]), -float(OY) * px, float(W) * px, float(H) * px), false, col)
	_fxn.draw_texture_rect(_fx_tex, Rect2(-float(OX) * px, -float(OY) * px, float(W) * px, float(H) * px), false)


func _process(_d: float) -> void:
	if _fx_tex != null:
		_fx_tex.update(_fx_img)
