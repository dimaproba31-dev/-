extends Node2D
## Слой объектов дороги: обновляет, рисует и сталкивает с героем монеты, врагов, боссов, сундуки, разломы и снаряды.

const Sprites := preload("res://scripts/gfx/sprites.gd")
const Entity := preload("res://scripts/play/entity.gd")
const Rewards := preload("res://scripts/play/rewards.gd")
const Spawner := preload("res://scripts/play/spawner.gd")
const PixelFont := preload("res://scripts/hud/pixel_font.gd")
const Fmt := preload("res://scripts/data/fmt.gd")

signal boss_changed(boss: RefCounted)   ## null — босса нет

const TABLE: Dictionary = {
	"coin": {"tex": "coin", "half": Vector2(24, 24), "fps": 10.0},
	"gem": {"tex": "gem", "half": Vector2(16, 24), "fps": 6.0},
	"worm": {"tex": "worm", "half": Vector2(30, 18), "fps": 9.0, "approach": 70.0},
	"golem": {"tex": "golem", "half": Vector2(28, 34), "fps": 4.0, "approach": 35.0},
	"bat": {"tex": "bat", "half": Vector2(30, 22), "fps": 12.0},
	"skull": {"tex": "skull", "half": Vector2(24, 30), "fps": 8.0},
	"chest": {"tex": "chest", "half": Vector2(32, 26), "fps": 10.0},
	"boss": {"tex": "boss", "half": Vector2(62, 116), "fps": 4.0},
	"wave": {"tex": "wave", "half": Vector2(22, 40), "fps": 12.0},
	"portal": {"tex": "portal", "half": Vector2(26, 48), "fps": 10.0},
	"bolt": {"tex": "bolt", "half": Vector2(12, 8), "fps": 1.0},
}
const BOSS_NAMES: Array[String] = ["Палач Бездны", "Палач пепла", "Лавовый палач", "Палач разлома"]

@export var fx_path: NodePath

var list: Array = []
var corpses: Array = []
var fx: Node2D
var boss: RefCounted = null
var boss_corpses: Array[Dictionary] = []

var _spawner: RefCounted
var _shoot_cd: float = 0.0
var _auto_t: float = 1.0
var _tap_jump_block: float = 0.0


func _ready() -> void:
	fx = get_node(fx_path) as Node2D
	_spawner = Spawner.new(self)
	InputRouter.pointer_pressed.connect(_on_pointer)
	InputRouter.shoot_pressed.connect(_on_shoot_key)
	InputRouter.rage_pressed.connect(_on_rage)
	Game.rage_started.connect(func() -> void: Sfx.play("rage"))
	if Game.hero != null:
		Game.hero.connect("strike", _on_strike)
	else:
		call_deferred("_late_connect")


func _late_connect() -> void:
	if Game.hero != null:
		Game.hero.connect("strike", _on_strike)


func has_kind(kind: String) -> bool:
	for e in list:
		if e.kind == kind and e.alive:
			return true
	return false


func spawn(kind: String, pos: Vector2, variant: int = 0) -> RefCounted:
	var e: RefCounted = Entity.new()
	var def: Dictionary = TABLE[kind]
	e.kind = kind
	e.tex = def["tex"]
	e.half = def["half"]
	e.fps = float(def["fps"])
	e.approach = float(def.get("approach", 0.0))
	e.pos = pos
	e.base_y = pos.y
	e.variant = variant
	e.phase = randf() * TAU
	e.t = randf() * 2.0
	list.append(e)
	return e


func spawn_ground(kind: String, x: float) -> RefCounted:
	var tex: Texture2D = Sprites.get_tex(String(TABLE[kind]["tex"]), 0)
	var e: RefCounted = spawn(kind, Vector2(x, 0))
	e.pos.y = Game.ROAD_Y + 6.0 - float(tex.get_height()) * float(Game.PIXEL) * 0.5
	e.base_y = e.pos.y
	return e


func spawn_burst(pos: Vector2, kind: String, n: int, value_each: float) -> void:
	for i in range(n):
		var e: RefCounted = spawn(kind, pos)
		var a: float = randf() * TAU
		e.vel = Vector2(cos(a), sin(a) - 0.4) * randf_range(180.0, 420.0)
		e.magnet = true
		e.delay = 0.35 + randf() * 0.15
		e.value = value_each
		e.scroll = 0.0


func boss_started(e: RefCounted) -> void:
	boss = e
	boss_changed.emit(e)
	fx.popup("БОСС!", Vector2(Game.view_size.x * 0.5, 240.0), Color(1.0, 0.3, 0.25), 6)


# ---------------------------------------------------------------- ввод

func _on_pointer(pos: Vector2) -> void:
	if not Game.running:
		return
	if try_shoot_at(pos):
		return
	if Game.hero != null:
		Game.hero.call("request_jump")


func _on_shoot_key() -> void:
	var t: RefCounted = _pick_target()
	if t != null:
		_fire(t)


func _on_rage() -> void:
	Game.start_rage()


func try_shoot_at(pos: Vector2) -> bool:
	var best: RefCounted = null
	var best_d: float = 1e9
	for e in list:
		if not e.alive or not (e.is_enemy() or e.kind == "boss"):
			continue
		var r := Rect2(e.pos - e.half - Vector2(40, 40), e.half * 2.0 + Vector2(80, 80))
		if r.has_point(pos):
			var d: float = e.pos.distance_to(pos)
			if d < best_d:
				best_d = d
				best = e
	if best == null:
		return false
	_fire(best)
	return true


func _pick_target() -> RefCounted:
	var hero: Node2D = Game.hero
	if hero == null:
		return null
	var best: RefCounted = null
	var best_score: float = 1e9
	for e in list:
		if not e.alive or not (e.is_enemy() or e.kind == "boss") or e.pos.x < hero.position.x + 20.0 or e.pos.x > Game.view_size.x + 40.0:
			continue
		var weight: float = 0.0 if e.kind == "boss" else (1000.0 if e.kind == "worm" or e.kind == "golem" else 400.0)
		var score: float = weight + e.pos.x
		if score < best_score:
			best_score = score
			best = e
	return best


func _fire(target: RefCounted) -> bool:
	if _shoot_cd > 0.0 or Game.hero == null:
		return false
	_shoot_cd = Eco.shoot_cooldown()
	var b: RefCounted = spawn("bolt", Game.hero.call("cast"))
	b.target = target
	b.scroll = 0.0
	b.life = 1.2
	Sfx.play("shoot", 0.95 + randf() * 0.1)
	return true


# ---------------------------------------------------------------- обновление

func _process(delta: float) -> void:
	var hero: Node2D = Game.hero
	if hero == null or not Game.running:
		queue_redraw()
		return
	_spawner.update(delta)
	_shoot_cd = maxf(0.0, _shoot_cd - delta)
	if Eco.auto_interval > 0.0:
		_auto_t -= delta
		if _auto_t <= 0.0:
			var t: RefCounted = _pick_target()
			if t != null and _fire(t):
				_auto_t = Eco.auto_interval
			else:
				_auto_t = 0.15
	if hero.call("can_attack"):
		var trig: Rect2 = hero.call("trigger_rect")
		for e in list:
			if e.alive and e.is_enemy() and _rect(e).intersects(trig):
				hero.call("begin_attack")
				break
	var body: Rect2 = hero.call("body_rect")
	var melee: Rect2 = hero.call("melee_rect")
	var snapshot: Array = list.duplicate()
	for e in snapshot:
		_update(e, delta, hero, body, melee)
	var alive_list: Array = []
	for e in list:
		if e.alive:
			alive_list.append(e)
	list = alive_list
	Game.boss_lock = boss != null and boss.alive and boss.state <= 1
	if boss != null and not boss.alive:
		boss = null
		boss_changed.emit(null)
	for c in corpses:
		c["age"] = float(c["age"]) + delta
		c["vel"] = (c["vel"] as Vector2) + Vector2(0, 1500.0 * delta)
		c["pos"] = (c["pos"] as Vector2) + (c["vel"] as Vector2) * delta
		c["rot"] = float(c["rot"]) + float(c["spin"]) * delta
	for bc in boss_corpses:
		bc["age"] = float(bc["age"]) + delta
		if randf() < 0.6:
			fx.burst((bc["pos"] as Vector2) + Vector2(randf_range(-60, 60), randf_range(-100, 100)), Color(0.7, 0.35, 1.0), 2, 200.0)
	boss_corpses = boss_corpses.filter(func(b: Dictionary) -> bool: return float(b["age"]) < 1.6)
	corpses = corpses.filter(func(c: Dictionary) -> bool: return float(c["age"]) < 0.6)
	queue_redraw()


func _rect(e: RefCounted) -> Rect2:
	return Rect2(e.pos - e.half, e.half * 2.0)


func _update(e: RefCounted, dt: float, hero: Node2D, body: Rect2, melee: Rect2) -> void:
	if not e.alive:
		return
	e.t += dt
	e.flash = maxf(0.0, e.flash - dt)
	e.delay = maxf(0.0, e.delay - dt)
	var view: Vector2 = Game.view_size
	e.pos.x -= Game.speed * e.scroll * dt
	match e.kind:
		"coin", "gem":
			_update_pickup(e, dt, hero, body)
		"worm", "golem":
			e.pos.x -= e.approach * dt
		"bat":
			e.pos.x -= (300.0 if e.tag == "gallery" else 110.0) * dt
			e.pos.y = e.base_y + sin(e.t * 4.0 + e.phase) * 26.0
		"skull":
			e.pos.x -= 70.0 * dt
			e.pos.y = e.base_y + sin(e.t * 2.2 + e.phase) * 60.0
		"chest":
			e.pos.x -= 45.0 * dt
			e.pos.y = e.base_y + sin(e.t * 3.0 + e.phase) * 16.0
		"portal":
			if _rect(e).intersects(body):
				e.alive = false
				var gallery: bool = randf() < 0.4
				Game.enter_bonus(12.0, "gallery" if gallery else "rain")
				Eco.event("portal", 1.0)
				fx.popup("ТИР! СТРЕЛЯЙ!" if gallery else "РАЗЛОМ!", Vector2(view.x * 0.5, 240.0), Color(0.85, 0.5, 1.0), 6)
				Sfx.play("portal")
		"bolt":
			_update_bolt(e, dt)
		"wave":
			_update_wave(e, dt, hero)
		"boss":
			_update_boss(e, dt, melee)
	if e.kind != "boss" and e.pos.x < -220.0:
		e.alive = false


func _update_pickup(e: RefCounted, dt: float, hero: Node2D, body: Rect2) -> void:
	if e.vel != Vector2.ZERO:
		e.pos += e.vel * dt
		e.vel *= pow(0.03, dt)
	var hc: Vector2 = body.get_center()
	var d: float = e.pos.distance_to(hc)
	var pull: bool = (e.magnet and e.delay <= 0.0) or d < Eco.magnet_radius() + 60.0 * float(1 if Eco.magnet_radius() > 40.0 else 0)
	if e.magnet and e.delay <= 0.0 or (Eco.magnet_radius() > 40.0 and d < Eco.magnet_radius()):
		var dir: Vector2 = (hc - e.pos).normalized()
		e.pos += dir * (760.0 + Game.speed) * dt
	if _rect(e).intersects(body.grow(8.0)):
		e.alive = false
		if e.kind == "coin":
			Rewards.pick_coin(fx, e)
		else:
			Rewards.pick_gem(fx, e)
	elif pull and false:
		pass


func _hit_by_melee(e: RefCounted, hero: Node2D) -> void:
	hero.call("start_swing")
	Sfx.play("slash")
	damage(e, Eco.hit_damage())


func damage(e: RefCounted, dmg: float, melee: bool = false) -> void:
	if not e.alive:
		return
	if e.kind == "boss":
		e.hp -= dmg
		e.flash = 0.09
		fx.popup(Fmt.num(dmg), e.pos + Vector2(randf_range(-40, 40), -70), Color(1.0, 0.95, 0.7), 2)
		fx.burst(e.pos + Vector2(randf_range(-30, 30), randf_range(-20, 30)), Color(1.0, 0.5, 0.3), 5)
		Sfx.play("hit")
		if e.hp <= 0.0:
			_boss_die(e)
		return
	e.alive = false
	_make_corpse(e, melee)
	fx.ash(e.pos, 22, 26.0)
	if e.kind == "chest":
		_open_chest(e)
	else:
		var crit: bool = melee and randf() < 0.15
		Rewards.kill_enemy(fx, e, crit)


func _make_corpse(e: RefCounted, melee: bool) -> void:
	var dir: float = 1.0 if melee else 0.4
	corpses.append({"tex": e.tex, "variant": e.variant, "frame": int(e.t * e.fps), "pos": e.pos,
		"vel": Vector2(randf_range(380.0, 640.0) * dir, randf_range(-520.0, -300.0)), "rot": 0.0,
		"spin": randf_range(8.0, 16.0) * (1.0 if randf() < 0.5 else -1.0), "age": 0.0})
	fx.impact(e.pos, e.kind == "golem")


## Момент прохода клинка: все враги в зоне удара получают урон; тряска и «заморозка» усиливают ощущение.
func _on_strike(kind: int, rect: Rect2) -> void:
	var hits: int = 0
	for e in list.duplicate():
		if not e.alive or not (e.is_enemy() or e.kind == "boss"):
			continue
		if _rect(e).intersects(rect):
			var dmg: float = Eco.hit_damage() * (1.5 if kind == 2 else 1.0)
			damage(e, dmg, true)
			hits += 1
	if hits > 0:
		Game.hitstop(0.035 + 0.012 * float(mini(hits, 3)))
		Game.add_shake(1.5 + float(mini(hits, 4)) * 0.6 + (1.5 if kind == 2 else 0.0))
		Sfx.play("kill", 0.9 + randf() * 0.2)
	elif kind == 2:
		Game.add_shake(0.8)


func _open_chest(e: RefCounted) -> void:
	var cv: float = Eco.coin_value()
	spawn_burst(e.pos, "coin", 12, cv * 2.5)
	spawn_burst(e.pos, "gem", 2, 5.0 * (1.0 + float(Eco.zone_number()) * 0.5))
	Eco.event("chest", 1.0)
	Eco.add_souls(1.0)
	Rewards.charge_rage(0.05)
	if randf() < 0.35:
		Game.call_deferred("emit_signal", "minigame", "chests")
	fx.popup("СУНДУК!", e.pos + Vector2(0, -40), Color(1.0, 0.9, 0.3), 4)
	fx.burst(e.pos, Color(1.0, 0.8, 0.2), 14)
	Sfx.play("chest")


func _boss_die(e: RefCounted) -> void:
	e.alive = false
	boss_corpses.append({"pos": e.pos, "variant": e.variant, "age": 0.0})
	Game.add_shake(22.0)
	var reward: float = (Eco.income * 40.0 + Eco.coin_value() * 60.0) * Eco.boss_mult()
	spawn_burst(e.pos, "coin", 24, reward / 24.0)
	spawn_burst(e.pos, "gem", 8, 10.0 * (1.0 + float(Eco.zone_number()) * 0.5))
	Eco.event("boss", 1.0)
	var souls: float = 3.0 + float(Eco.zone_number())
	Eco.add_souls(souls)
	fx.popup("+" + Fmt.num(souls * float(Eco.dim_data()["soul"])) + " ДУШ", e.pos + Vector2(0, -120), Color(0.8, 0.6, 1.0), 3)
	Rewards.charge_rage(0.25)
	fx.popup("+" + Fmt.num(reward), e.pos + Vector2(0, -80), Color(1.0, 0.85, 0.25), 5)
	fx.burst(e.pos, Color(1.0, 0.4, 0.2), 30, 420.0)
	fx.ash(e.pos, 60, 70.0)
	Sfx.play("boss_die")
	for other in list:
		if other.is_enemy():
			other.alive = false
			fx.burst(other.pos, Color(1.0, 0.7, 0.3), 6)


func _update_bolt(e: RefCounted, dt: float) -> void:
	e.life -= dt
	if e.life <= 0.0:
		e.alive = false
		return
	var tgt: RefCounted = e.target
	if tgt != null and tgt.alive:
		var dir: Vector2 = (tgt.pos - e.pos)
		e.vel = dir.normalized() * 2100.0
		if dir.length() < 30.0 + minf(tgt.half.x, 50.0) * 0.5:
			e.alive = false
			damage(tgt, Eco.hit_damage())
			return
	elif e.vel == Vector2.ZERO:
		e.vel = Vector2(2100.0, 0.0)
	e.pos += e.vel * dt
	fx.trail(e.pos, Color(1.0, 0.55, 0.15))


func _update_wave(e: RefCounted, dt: float, hero: Node2D) -> void:
	e.pos.x -= 560.0 * dt
	e.life -= dt
	if e.life <= 0.0 or e.pos.x < -60.0:
		e.alive = false
		return
	if not e.hit_done and absf(e.pos.x - hero.position.x) < 36.0:
		var airborne: bool = not bool(hero.get("on_ground")) or float(hero.position.y) < Game.ROAD_Y - 40.0
		if not airborne:
			e.hit_done = true
			Game.add_shake(14.0)
			Game.hitstop(0.08)
			Save.d["rage"] = maxf(0.0, float(Save.d["rage"]) - 0.2)
			fx.popup("УДАР ВОЛНЫ!", hero.position + Vector2(0, -230), Color(1.0, 0.45, 0.25), 4)
			fx.burst(hero.position + Vector2(0, -60), Color(1.0, 0.5, 0.2), 14, 380.0)
			Sfx.play("hit")


func _update_boss(e: RefCounted, dt: float, melee: Rect2) -> void:
	var view: Vector2 = Game.view_size
	var hx: float = Game.hero.position.x if Game.hero != null else 256.0
	var stand_x: float = hx + 175.0
	e.pos.x += Game.speed * dt   # босс не едет вместе с миром
	e.pos.y = Game.ROAD_Y - 118.0
	e.act_t += dt
	match e.state:
		0:
			e.pos.x = move_toward(e.pos.x, stand_x, 380.0 * dt)
			e.frame = 2 + int(e.t * 5.0) % 2
			if absf(e.pos.x - stand_x) < 2.0:
				e.state = 1
				e.act = 0
				e.act_t = 0.0
				Game.add_shake(10.0)
		1:
			e.life -= dt
			e.pos.x = stand_x + sin(e.t * 0.8) * 14.0
			match e.act:
				0:
					e.frame = int(e.t * 3.0) % 2
					if e.act_t > 1.5:
						e.act = 1
						e.act_t = 0.0
				1:
					e.frame = 4 if e.cycles % 3 != 2 else 6
					if e.act_t > 0.8:
						e.act = 2
						e.act_t = 0.0
						e.hit_done = false
				2:
					e.frame = 5
					if not e.hit_done:
						e.hit_done = true
						Game.add_shake(12.0)
						Sfx.play("hit")
						if e.cycles % 3 != 2:
							var w: RefCounted = spawn("wave", Vector2(e.pos.x - 110.0, Game.ROAD_Y - 38.0))
							w.scroll = 0.0
							w.life = 1.6
						else:
							for k in range(2):
								var m: RefCounted = spawn("skull", e.pos + Vector2(-80.0 - float(k) * 50.0, -60.0))
								m.base_y = m.pos.y
						fx.burst(e.pos + Vector2(-90.0, 100.0), Color(1.0, 0.55, 0.2), 14, 340.0)
					if e.act_t > 0.3:
						e.act = 3
						e.act_t = 0.0
				3:
					e.frame = 0
					if e.act_t > 0.6:
						e.act = 0
						e.act_t = 0.0
						e.cycles += 1
			if _rect(e).intersects(melee) and e.t - e.last_hit > 0.35:
				e.last_hit = e.t
				damage(e, Eco.hit_damage() * 0.6)
			if e.life <= 0.0:
				e.state = 2
				fx.popup("Палач ушёл", Vector2(view.x * 0.5, 240.0), Color(0.8, 0.8, 0.9), 4)
		2:
			e.frame = 2 + int(e.t * 6.0) % 2
			e.pos.x += 420.0 * dt
			if e.pos.x > view.x + 260.0:
				e.alive = false


# ---------------------------------------------------------------- рисование

func _draw() -> void:
	var px: float = float(Game.PIXEL)
	_draw_corpses()
	_draw_boss_corpses()
	for e in list:
		var tex: Texture2D = Sprites.get_tex(e.tex, e.frame if e.frame >= 0 else int(e.t * e.fps), e.variant)
		var size: Vector2 = Vector2(tex.get_width(), tex.get_height()) * px
		var p: Vector2 = e.pos - size * 0.5
		p = Vector2(roundf(p.x / px) * px, roundf(p.y / px) * px)
		var mod: Color = Color(1, 1, 1, 1) if e.flash <= 0.0 else (Color(1.5, 1.35, 1.35, 1) if e.kind == "boss" else Color(2.4, 2.4, 2.4, 1))
		if e.kind == "bolt":
			var ang: float = e.vel.angle() if e.vel != Vector2.ZERO else 0.0
			draw_set_transform(e.pos, ang, Vector2.ONE)
			draw_texture_rect(tex, Rect2(-size * 0.5, size), false)
			draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)
			continue
		draw_texture_rect(tex, Rect2(p, size), false, mod)
		if e.kind == "boss":
			_draw_boss_bar(e, p, size)
		if e.kind == "chest" or e.kind == "portal":
			pass


func _draw_boss_corpses() -> void:
	var px: float = float(Game.PIXEL)
	for bc in boss_corpses:
		var tex: Texture2D = Sprites.get_tex("boss", 0, int(bc["variant"]))
		var size: Vector2 = Vector2(tex.get_width(), tex.get_height()) * px
		var age: float = bc["age"]
		var slices: int = 16
		var sh: float = float(tex.get_height()) / float(slices)
		for i in range(slices):
			# рассыпается сверху вниз
			var vanish: float = 0.2 + float(i) * 0.07
			if age > vanish:
				continue
			var shake: float = sin(age * 60.0 + float(i)) * 3.0 * (age / vanish)
			var rise: float = -age * 20.0 * float(slices - i) / float(slices)
			var src := Rect2(0.0, float(i) * sh, float(tex.get_width()), sh)
			var dst := Rect2((bc["pos"] as Vector2) - size * 0.5 + Vector2(shake, float(i) * sh * px + rise), Vector2(size.x, sh * px))
			var flash: float = 1.0 + 2.0 * clampf(1.0 - age * 3.0, 0.0, 1.0)
			draw_texture_rect_region(tex, dst, src, Color(flash, flash, flash, clampf((vanish - age) / 0.25, 0.0, 1.0)))


func _draw_corpses() -> void:
	var px: float = float(Game.PIXEL)
	for c in corpses:
		var tex: Texture2D = Sprites.get_tex(String(c["tex"]), int(c["frame"]), int(c["variant"]))
		var size: Vector2 = Vector2(tex.get_width(), tex.get_height()) * px
		var age: float = c["age"]
		var a: float = clampf(1.0 - (age - 0.3) / 0.3, 0.0, 1.0)
		var col: Color = Color(3, 3, 3, a) if age < 0.07 else Color(1.2, 0.9, 0.9, a)
		draw_set_transform(c["pos"], float(c["rot"]), Vector2.ONE)
		draw_texture_rect(tex, Rect2(-size * 0.5, size), false, col)
	draw_set_transform(Vector2.ZERO, 0.0, Vector2.ONE)


func _draw_boss_bar(e: RefCounted, p: Vector2, size: Vector2) -> void:
	var px: float = float(Game.PIXEL)
	var w: float = 80.0 * px
	var x: float = roundf((p.x + size.x * 0.5 - w * 0.5) / px) * px
	var y: float = roundf((p.y - 22.0) / px) * px
	draw_rect(Rect2(x - px, y - px, w + px * 2.0, px * 6.0), Color(0.05, 0.0, 0.05))
	draw_rect(Rect2(x, y, w, px * 4.0), Color(0.3, 0.05, 0.08))
	draw_rect(Rect2(x, y, w * clampf(e.hp / e.max_hp, 0.0, 1.0), px * 4.0), Color(0.9, 0.18, 0.2))
	draw_rect(Rect2(x, y, w * clampf(e.hp / e.max_hp, 0.0, 1.0), px), Color(1.0, 0.5, 0.45))
	var nm: String = BOSS_NAMES[e.variant % BOSS_NAMES.size()]
	PixelFont.draw_text_centered(self, nm, x + w * 0.5, y - px * 8.0, 2, Color(1.0, 0.9, 0.8))
