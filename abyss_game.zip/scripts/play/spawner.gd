extends RefCounted
## Генератор «рисунков» на дороге: ряды и дуги монет, группы врагов, сундуки, разломы, боссы.
## Расписание идёт по пройденной дистанции, чтобы плотность не зависела от скорости.

var layer: Node2D
var next_at: float = 700.0
var boss_next: float = 32000.0
var _last_d: float = 0.0
var _bonus_acc: float = 0.0


func _init(l: Node2D) -> void:
	layer = l


func _ground_y() -> float:
	return Game.ROAD_Y + 6.0


func _x0() -> float:
	return Game.view_size.x + 80.0


func update(dt: float) -> void:
	var d: float = Game.distance
	if d < _last_d - 1.0:
		next_at = d + 600.0
		boss_next = d + 32000.0
	_last_d = d
	if Game.bonus_active:
		_bonus(dt)
		return
	var boss_alive: bool = layer.has_kind("boss")
	if d >= boss_next:
		if not boss_alive:
			spawn_boss()
			boss_next = d + 36000.0
		else:
			boss_next = d + 3000.0
	if d >= next_at:
		_pattern(boss_alive)
		next_at = d + (randf_range(700.0, 1100.0) if boss_alive else randf_range(360.0, 800.0))


func _pattern(boss_alive: bool) -> void:
	var table: Array = [
		[18.0, "coin_row"], [18.0, "coin_arc"], [12.0, "coin_wave"], [22.0, "ground"], [14.0, "bats"],
		[8.0, "skull"], [10.0, "mixed"], [7.0, "gems"], [3.0 * Eco.chest_weight(), "chest"], [1.6 * Eco.portal_weight(), "portal"],
	]
	if boss_alive:
		table = [[30.0, "coin_row"], [30.0, "coin_arc"], [20.0, "coin_wave"], [20.0, "gems"]]
	var total: float = 0.0
	for r in table:
		total += float(r[0])
	var pick: float = randf() * total
	for r in table:
		pick -= float(r[0])
		if pick <= 0.0:
			call(String(r[1]))
			return
	call("coin_row")


# ---------------------------------------------------------------- рисунки

func coin_row() -> void:
	var n: int = randi_range(5, 10)
	var y: float = Game.ROAD_Y - randf_range(36.0, 60.0)
	for i in range(n):
		layer.spawn("coin", Vector2(_x0() + float(i) * 44.0, y))


func coin_arc() -> void:
	var n: int = randi_range(7, 11)
	var peak: float = randf_range(120.0, 220.0)
	for i in range(n):
		var f: float = float(i) / float(n - 1)
		layer.spawn("coin", Vector2(_x0() + float(i) * 46.0, Game.ROAD_Y - 36.0 - peak * sin(PI * f)))


func coin_wave() -> void:
	var n: int = randi_range(8, 12)
	for i in range(n):
		layer.spawn("coin", Vector2(_x0() + float(i) * 46.0, Game.ROAD_Y - 120.0 - sin(float(i) * 0.7) * 70.0))


func gems() -> void:
	var n: int = randi_range(3, 5)
	var y: float = Game.ROAD_Y - randf_range(60.0, 200.0)
	for i in range(n):
		layer.spawn("gem", Vector2(_x0() + float(i) * 52.0, y))


func ground() -> void:
	var golem: bool = randf() < 0.28 and Eco.zone_number() >= 0
	var n: int = randi_range(1, 2) if golem else randi_range(1, 3)
	for i in range(n):
		layer.spawn_ground("golem" if golem else "worm", _x0() + float(i) * 90.0)


func bats() -> void:
	var n: int = randi_range(2, 4)
	var y: float = randf_range(Game.ROAD_Y - 330.0, Game.ROAD_Y - 190.0)
	for i in range(n):
		layer.spawn("bat", Vector2(_x0() + float(i) * 70.0, y + float(i % 2) * 26.0))


func skull() -> void:
	layer.spawn("skull", Vector2(_x0(), randf_range(Game.ROAD_Y - 300.0, Game.ROAD_Y - 200.0)))


func mixed() -> void:
	var x: float = _x0()
	layer.spawn_ground("worm", x)
	layer.spawn_ground("worm", x + 90.0)
	for i in range(5):
		var f: float = float(i) / 4.0
		layer.spawn("coin", Vector2(x - 40.0 + float(i) * 50.0, Game.ROAD_Y - 150.0 - 70.0 * sin(PI * f)))


func chest() -> void:
	layer.spawn("chest", Vector2(_x0(), randf_range(Game.ROAD_Y - 330.0, Game.ROAD_Y - 220.0)))


func portal() -> void:
	layer.spawn("portal", Vector2(_x0(), Game.ROAD_Y - 130.0))


func spawn_boss() -> void:
	var e: RefCounted = layer.spawn("boss", Vector2(Game.view_size.x + 220.0, Game.ROAD_Y - 118.0), Eco.zone_number() % 4)
	e.max_hp = Eco.hit_damage() * (60.0 + float(Eco.zone_number()) * 6.0)
	e.hp = e.max_hp
	e.base_y = e.pos.y
	e.life = 34.0
	layer.boss_started(e)


# ---------------------------------------------------------------- бонус-уровень (разлом)

func _bonus(dt: float) -> void:
	if Game.bonus_kind == "gallery":
		_gallery(dt)
		return
	_bonus_acc += dt
	if _bonus_acc < 0.3:
		return
	_bonus_acc = 0.0
	var y0: float = randf_range(Game.ROAD_Y - 330.0, Game.ROAD_Y - 80.0)
	var shape: int = randi_range(0, 3)
	for i in range(4):
		if shape == 0:
			layer.spawn("coin", Vector2(_x0(), y0 + float(i) * 44.0 - 60.0))
		elif shape == 1:
			layer.spawn("coin", Vector2(_x0() + float(i) * 44.0, y0))
		elif shape == 2:
			layer.spawn("coin", Vector2(_x0() + float(i) * 40.0, y0 - float(i) * 36.0))
		else:
			layer.spawn("gem" if i == 1 else "coin", Vector2(_x0() + float(i) * 44.0, y0 + sin(float(i)) * 40.0))


## Мини-игра «Тир»: летит рой летучих мышей, каждая стоит ×4 монет. Стреляйте тапом или клавишей.
func _gallery(dt: float) -> void:
	_bonus_acc += dt
	if _bonus_acc < 0.38:
		return
	_bonus_acc = 0.0
	var b: RefCounted = layer.spawn("bat", Vector2(_x0(), randf_range(Game.ROAD_Y - 340.0, Game.ROAD_Y - 120.0)))
	b.tag = "gallery"
	b.base_y = b.pos.y
